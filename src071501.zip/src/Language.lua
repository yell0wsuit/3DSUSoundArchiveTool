
local Language={
    updater={
        title_need_update="更新",
        title_fail="更新失敗",
        title_check_fail="検査更新失敗",
        msg_download_info_fail="ファイルのダウンロードに失敗しました、再ダウンロードしますか？",
        no_loacl_Manifest="ローカル更新のための配置ファイルが存在しません。",
        remote_Manifest_fail="更新ファイルのダウンロードに失敗しました。通信環境の良い場所で再度お試しください。",
        str_server="%dサーバー",
        title_server_stop="メンテナンス",
        msg_server_stop="サーバーメンテナンス中です。詳細はお知らせをご確認ください。",
        title_server_list_not_get="ネットワーク異常が検出されました。",
        msg_server_list_not_get="サーバーリストの取得に失敗しました。再取得しますか？",
        title_info_not_get="ネットワーク異常が発生しています",
        msg_info_not_get="更新ファイルのダウンロードに失敗しました。リトライしますか？",
        update_cpp="ゲームアプリをストアで更新する必要があります。",
        msg_download_err="ダウンロード失敗",
        msg_unzip_err="リソースの解凍に失敗",
        download_site_1="ダウンロード1",
        download_site_2="ダウンロード2",
        decompressing="解凍中",
        sdk_login_error = "ストアのログイン情報の取得に失敗しました。リトライしますか？",
    },

    loginui={
        login_info_err="ログイン情報請求に失敗",
        login_server_connect_err="ログインサーバーへの接続は失敗しました。",
        login_fail_title="ログイン失敗",
        login_check_fail="ログイン認証に失敗",
        server_info_miss="サーバー情報を取得できませんでした。",
        server_full="サーバーが混雑しており、新アカウントが作成できませんでした。",
        do_not_sync = "非同期",
        do_not_sync_table = "情報の同期に失敗しました。cmd5:%s\nsmd5:%s\n",
        do_not_sync_fighting = "コードの同期に失敗しました。cmd5:%s\nsmd5:%s",
    },
    ButtonTalk = {
        "スタッフのモチベーション管理は大切です。彼らの気持ちを確認してみましょう。",
        "お客様にレストラン評価10点をいただきました！この調子でがんばってください！",
        "満足いただけていないお客様がいらっしゃいます。改善できるところを見つけましょう。",
        "やる気が６０を下回っているスタッフがいます。スキルが発動ないので回復させましょう。",
        "レベルアップできる裝飾品があります。ここをタップしても移動できますよ！"
    },
    
    roleui = {
        success = "成功です。やりましたね！",
        please_input_name = "名前を入力してください。",
        change_name_failed="オーナー様のお名前変更に失敗しました。ピンクダイヤが足りません。",
        change_name_success = "お名前の変更に成功しました。バッチリです！",
        please_choose_headui = "アバターアイコンを選択してください。",
        change_headui_success = "アバターアイコンの変更に成功しました。",
        titile_change_account = "アカウントの切り替えを行います",
        msg_change_account = "アカウント切り替えますか？",
        head_buff_desc = "バフ効果：%s",
        head_always_have = "永久",
        head_not_unlock = "未解放",
        judge_not = "なし",

    }, 
    chapter = {
        is_Onchapter_open = "【%s】でお店を新開業しますか？",
        open_people = "%d-%d人",
        open_people_time = "%d秒",
        get_suan_tips = "酸味嗜好%d—%d，料理でこの条件を満たすと顧客数量が%d%sに増加します。重ね掛け可能。",
        get_tian_tips = "甘味嗜好%d—%d，料理でこの条件を満たすと顧客数量が%d%sに増加します。重ね掛け可能。",
        get_la_tips   = "辛味嗜好%d—%d，料理でこの条件を満たすと顧客数量が%d%sに増加します。重ね掛け可能。",
        get_xian_tips = "塩味嗜好%d—%d，料理でこの条件を満たすと顧客数量が%d%sに増加します。重ね掛け可能。",
        get_fresh_tips = "鮮度嗜好%d—%d，料理でこの条件を満たすと顧客数量が%d%sに増加します。重ね掛け可能。",
        guke_find_time = "顧客生成時間",
        guke_num = "顧客人数",
        guke_have_gold = "顧客保有コスト",
        open_is_ok = "経営スタイルを変更！さあお客さまをお迎えしましょう！",
    },
    goldui={
        check_open_str = "ゴールドが足りません。購入しますか？",
        yes_btn_name = "ゴールドを購入に移動",
        no_btn_name = "キャンセル"
    },

    petManage = {
        on_was_job = "既に該当職種を担当しています。",
        manage_not_leave = "レジ担当を外すことはできません。",
        need_one_manage = "レジ担当は１名のみ設定できます。必ず指定してくださいね",
        need_one_fuwu = "配膳担当が少なくとも１名必要です。",
        need_one_cook = "キッチン担当が少なくとも１名必要です。",
        manager_not_change = "レジ担当を変えることができません。",
        not_enough_cook = "キッチンが足りません。キッチン担当に変更できませんでした",
        not_look_me_pet = "自分のスタッフではないので、詳細を確認できません。",
        not_enough_cook = "キッチンが足りません。キッチン担当に変更できませんでした",
        is_put_manager = "[%s]をレジ担当に任命しますか？",
        is_put_cooker = "[%s]をキッチン担当に任命しますか？",
        is_put_fuwu = "[%s]を配膳担当に任命しますか？",
        pet_out_team = "[%s]は間もなく離脱します",
        appointment = "[%s]を[%s]に任命しますか？",
    },

    jianbao = {
        {"センスもあってまた来たくなる居心地です！","お客様はレストランの居心地に比較的に満足しています。","お客様は居心地に満足していません。"},  -- 环境
        {"景観がよく、雰囲気抜群のレストランに大満足！","お客様は景観に満足しています。","お客様はレストランの景観に満足していません。"},          -- 舒适
        {"電光石火！瞬く間にお料理が振舞われました。","調理時間はまだまだ改善が必要ですね。","随分待ってましたが、料理はまだ来ません。"},        -- 时间
        -- 色、香、味、量、型
        {"あざやかな色どりに、目を奪われます。","よい見栄えのお料理です。ですがまだまだ進歩の余地がありますね。","お料理は色どりを添えましょう。"},
        {"とってもよい香り。食欲が止まりません。","香ばしい香りでお客様は満足。でももっと高めることができるはずです。","香り高い料理でお客様を引き付けましょう！"},
        {"ここにしかない最高の味わいですね。","料理のお味にお客様も満足のご様子。もっと精進しましょう。","まだまだですね。もっとお客様の舌を満足させる味わいを追求しましょう。"},
        {"食いしん坊でも満腹になる最高のレストラン！","素材をふんだんに使ったお料理ですね。あと少しでお客様も大満足です。","お客様はボリュームにご満足いただけていないようです。"},
        {"きめ細やかな盛り付け。大変素晴らしいですね。","スタイリッシュな盛り付けですね、お客様をもっと満足させましょう！","盛り付け次第でお料理はもっと美味しくなりますよ。"},
    },
    
    vipui={
        vip_tip_str="%d個ピンクダイヤをさらに課金して、VIP%dになります。",
        vip_level_str="VIP%d特権",
        pay_ext_get_one="%d個ピンクダイヤが付与されます。上限一回まで。",
        pay_ext_get="%d個ピンクダイヤが付与されます。",
        vip_has_got_first_reward="受領済み",
        vip_double_diamond="割引",
        VIP_tip="%dダイヤモンドをすぐ受領しますか。毎日%dダイヤモンドを受領します。",
        month_card_tip="今日受領可能%dダイヤモンド",
        pay_success="購入成功",
        check_open_str="ピンクダイヤが足りません。購入しますか？",
        vip_gukeTime_5min = "次のVIP顧客到来まであと5分です。",
        vip_gukeTime_1h = "次のVIP顧客到来まであと1時間です。"
    },

    storeui={
        not_open_vipstore = "VIP 1に達するとVIPショップが開放されます。",
    },

    chatui = {
        chat_talk_level = "レストランレベル3に到達で【世界チャット】で発言可能です",
        chat_time = "%d秒後、続けて発言できます。",
        not_nil_sendmessage = "空メールの送信はできません。",
        check_talk_person = "フレンドを選択してください。",
        cd_chat = "次の発言まで少しお待ち下さい。",
        yes_cd_chat = "%d個ピンクダイヤを消費して発言しますか？",
        success_report_chat = "ユーザー通報しました。",
        not_report_chat = "ロック権限ががありません。",
        status_not_report_chat = "他のユーザーに通報されました。利用が１日禁止されています。",
        status_palyer_mute = "該当ユーザーはチャットが禁止されています。",
        not_vippalyer_mute = "VIP2以上のユーザーを通報することはできません。",
        call_share = "おめでとうございます。<c=255，255，0>%s</c>を獲得しました。",
        user_mute="該当ユーザーは通報されています。",
        report_times_max = "他ユーザーを5回通報できます。現在、上限に達しています。",
        not_nil_name = "ユーザ―名を空欄にすることはできません。",
        not_add_self = "自分を通報することはできません。",
        online_can_chat = "両方のユーザーがオンラインの場合、チャットできます。",
        most_mark_fifty = "最大50名のユーザーを記録します",
        most_blacklist_fifty = "ブラックリスト人数が上限の50人に達しています。",
        input_player_name = "ニックネーム入力",
        have_name = "既にリストに入っています。",
        hint_max_length = "入力文字を150以内にしてください。",
    },
    
    tipui={
        reward_num_str="X%d",
        tishi="提示",
        tip_nums_type={
            [8] = "日",
        },
    },

    err={
        title_NOT_SYNCHRONOUS="データ異常",
        msg_NOT_SYNCHRONOUS="ゲームを再起動してください！",
        title_reconnect_failed="再接続失敗",
        msg_reconnect_failed="リトライに失敗しました。タイトル画面に戻ります。",
    },
    
    EndGameName = "アンジュ",
    EndGameMsg = "おい下僕、もうお休みするのね？寂しくなるのね。（再タップしてアプリを終了します。）",

    mailui = {
        mail_from = "解放:%s",
        to_mail = "送信者：%s",
        remian_days = "残り%d日",
    },
    
    activityui={
        download_json_fail="%sダウンロードに失敗",
        download_lua_fail="スクリプトファイル%sが存在しません。",
        day_sign_double = "VIP%d二倍",
        file_download_fail = "ファイルダウンロードに失敗",

        gift_code_err="交換コードエラー。使用済み、或いは交換期限切れです。",
        month_card = {
            mCard_type = {[1] = "SVIP", [2] = "VIP"},
            mCard_get_string = "購入%s毎日受領：",
            mCard_remain_string = "%s残り受領可能回数：%d回",
        },
        descript_activity_string = "イベント時間：%d.%02d.%02d-%d.%02d.%02d",
        descript_activity_day_open = "イベント時間：本日解放",

        daily_vip_gift_activity={
            has_got="ギフトセット受領済み",
            not_vip="VIPユーザでないため、課金バックを受領できません。",
        },
        vip_level_gift_activity={
            vip_level_x_only="VIP %d 限定ギフトセット",
        },        
        diamond_consume_title = "%d個ピンクダイヤを累計消費します。",
        vip_sign_not_reach = "単一購入条件が未達成です。ログインボーナスは未開放です。",

        activity_closed = "イベント終了",

        paysDesc = {
            [1] = "レストランEXPとプレイヤーEXPを入手して一気にレストランを拡大しましょう！装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル2→レベル3に、店構えは7*7→8*8。プレイヤーEXPはゴールド獲得上限をアップできます。受領後は自動的に装飾倉庫に入れられます。",
            [2] = "ひろ～いお店はみんなの憧れ！レストランEXPとプレイヤーEXPを入手してさらにレストランを拡大しましょう！装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル3→レベル4に、店構えは8*8→9*9。プレイヤーEXPはゴールド獲得上限をアップできます。受領後は自動的に装飾倉庫に入れられます。",
            [3] = "もう少しお店が広かったら。そんな要望にお応えします！経営熱心なオーナーさまのためにご用意しました。装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル4→レベル5に、店構えは9*9→10*10。プレイヤーEXPはゴールド獲得上限をアップできます。受領後は自動的に装飾倉庫に入れられます。",
            [4] = "経営は順調ですか？他のオーナー様たちと差をつけるチャンスです！装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル5→レベル6に、店構えは10*10→11*11。床飾り【くったり犬】はレストランのステータスをアップできます。受領後は自動的に装飾倉庫に入れられます。",
            [5] = "いよいよ人気のレストランの仲間入り！広いお店と床飾り【夢の石像】でお客様をわしづかみに！装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル6→レベル7に、店構えは11*11→12*12。床飾り【夢の石像】はレストランのステータスをアップでき、しかも【レベルアップ可能】。受領後は自動的に装飾倉庫に入れられます。",
            [6] = "レストラン経営の上級者に贈る最高の逸品。さらに【URアンジュ】をスタッフに加えませんか？装飾は受領後に装飾倉庫に送られます。",--獲得したレストランEXPでレベル7→レベル8に、店構えは12*12→13*13。【アンジュ】は得意職種がレジ担当のURスタッフです。受領後は自動的に装飾倉庫に入れられます。"
        },

        activity_SpecialOffer={
            offer_discount = "%d割",
        },

        activity_Chapter = {
            isAct_Open_chapter = "時限セクションイベント中 【%s】で開店しますか?",
            arrive_ct_level = "レストランレベル%dに達することが必要です。",
            not_chapter_table = "セクションidが%dのセクションリストがありません。",
        },

        activity_PropExchange = {
            exchange_not_num = "交換回数は上限に達しています。",
            exchange_times = "%d回",
        },

        activity_Public = {
            not_pay_toTime = "βテスト期間未課金",
            get_reward_again = "キャッシュバック奨励は受領済みです。",
        },

        activity_Specials = {
            buy_max_num = "購入上限",
            buy_not_OnTime = "購入時間範囲内にありません。",
        },

        activity_Share = {
            share_max_num = "シェア回数が上限に達しています。",
        },

        activity_LimitMission = {
            month_day = "%d月%d日",
        },
        
        rank_reward_desc = "金曜21:00の集計後に、収入ランキングに応じてメールで賞品を付与します。がんばりましょう！",
        rank_str = "ランキング %d",
        rank_str_str = "ランキング %d-%d",

        activity_TotalPay = {
            pay_total_title = "累積課金",
        },

        activity_TotalConsume = {
            consume_total_title = "累積消費",
            go_to_persent_title = "ショップ画面に移動しますか？",
        },
        
        activity_TimeRecruit = {
            month_day = "%d月%d日",
        },

        activity_MarketDiscount = {
            month_day = "%d月%d日",
        },

        activity_AssignChapter = {
            warn_same_chapter = "該当経営セクションは指定セクションです。",
            set_chapter = "設定【%s】",
            over_title_chapter = "未受領の賞品はイベント終了前に受領してください。",
        },
    },
    
    setui={
        item_name={
            music="BGM",
            sound="効果音声",
            push_lunch="ランチ(12時体力推送)",
            push_super="ディナー(18時に体力ブッシュ)",
        }
    },

    sevendayui = {
        time_string_with_day = "%d日%02d:%02d:%02d",
        charge_tip_string = "累計課金が%d個ピンクダイヤ（%d/%d）",
    },
    
    need_update="更新内容があります（%.2f%s）。すぐにダウンロードしますか？",
    not_enough_metarial = "材料が足りません。",
    not_open_store = "ショッピンクセンターモールまだ未開放です",
    not_achieve = "準備中です。",
    title_not_open = "未開放",
    not_open = "準備中です。ご期待ください。",
    role_level_up_enegry="体力：%d=>%d",
    week_day_name={"月曜日","火曜日","水曜日","木曜日","金曜日","土曜日","日曜日"},

    not_enough_gold="ゴールドが足りません。",
    not_enough_diamond="ピンクダイヤが足りません。",
    not_enough_money = "購入のためのアイテムが足りません。",
    not_enough_ctlevel="レストランレベルが足りません。",
    not_enough_playlevel="ユーザーレベルが足りません。",
    not_enough_furniture_coin = "装飾コインが足りません。",

    ctlevel_less_than = "レストランレベル≤%d",
    playlevel_less_than = "ユーザーレベル≤%d",
    new_handing = "現在、チュートリアルを進行中です。",

    wait_guke_find = "お客様はもうすぐ到来されます。しばらくお待ちください。",
    open_lose = "開店に失敗しました。",
    is_on_open = "既に営業状態です。",

    get_succeed = "受領に成功しました。",
    not_reward_get = "受領できる報酬はありません。",
    need_two_level = "もう少しでレベル2に到達ですよ。もう少しお待ちください！",
    current_own="現在所有%d",
    not_reach_level="レベルは\n%dに達しています。",
    pay_not_oepn="未開放",
    title_kick_off="ログイン異常",
    msg_kick_off="本アカウントは他の端末にログイン状態になっています。",
    exit_tip_str="もう一回Backキーをクリックするとアプリが終了します。",
    string_none = "なし",
    start_game_str = "ゲームスタート",
    Version_str="バージョン：",
    clean_title="警告",
    clean_content="すべてのキャッシュファイルをクリアします。この機能は、すべてのアップデートファイルが再度ダウンロードされます。",
    next_level_need = "%d級にレベルアップ報酬入手可能",
    saber_time_tip = "タイム限定：%02d:%02d:%02d",

    bagui={
        have_num="保有:%d",
        use_num="使用:%d",
        not_select_item="選択中アイテムがありません。",
        get_item_success = "受領成功",
    },

    adorn = {
        put_true_position = "正しい位置にアイテムを配置してください",
        not_have_adorn = "該当商品はまだ保有していません。",
        save_succeed = "正常に保存しました。",
        only_floor_wall = "床と壁紙のみ一括設置ができます。 id:",
        maxn_nums = "数は上限に達しています。",
        go_to_set = "配置で操作する必要があります。",
        is_clear_adorn = "内装の配置をリセットしますか？",
        is_clear_floor = "床の配置をリセットしますか？",
        is_clear_wall = "壁の配置をリセットしますか？",
        is_clear_adorn_deco = "全ての配置をリセットしますか？",
        maxn_nums_floor = "床数は上限に達しています。~ Max:",
        adorn_place_fail = "装飾品の設置が正しくありません。他の装飾品と重なっていないかご確認ください。",
        unknown_adron = "未知の商品",
        not_go_to_door = "入口にドアの設置が必要です。ご確認くださいませ。",
        least_one_chairs = "少なくともテーブルをひとつ配置する必要があります。",
        least_one_kitchens = "少なくともキッチンをひとつ配置する必要があります。",
        only_one_cashier = "少なくともレジをひとつ配置する必要があります。",
        not_road_door = "配膳スタッフの移動経路・待機場所を確保してください。",
        not_road_chairs = "テーブルやキッチンなどで、配膳スタッフの移動経路・待機場所が確保されていません。",
        not_road_door_cashier = "装飾やレジなどで、配膳スタッフの移動経路・待機場所が確保されていません。",
        not_road_door_kitchen = "装飾やキッチンなどで、配膳スタッフの移動経路・待機場所が確保されていません。",
        not_road_door_chair = "装飾やテーブルなどで、配膳スタッフの移動経路・待機場所が確保されていません。",
        maxn_nums_adorn = "装飾の数量が上限に達しました。Max:",
        not_kitchen = "キッチンが足りないため、キッチン担当になれません。 ",
    },

    furnitureui={
        max_buy_times = "購入可能上限に達しています。",
        not_save_furniture = "格納が必要な裝飾はありません。",
        input_number_fail = "数値を正しく入力してください。",
        map_have_number_furniture = "店内に既に%d個該当の裝飾があります。",
        not_reach_level = "%d級に達してません、該当商品の購入はできません。",
        not_reach_level_preview = "レベル%dに達していないため、メイン画面に置いてプレビューすることができません。",
        speed_prop_save = "カートに入れている装飾品を購入しますか？",
        close_prop_layer = "配置中の装飾の購入/保存はお忘れずに。もうレストランに戻りますか？",
        attribute_desc = {
            [1] = "環境%s%d",
            [2] = "居心地%s%d",
            [3] = "料理作成スピード%s%d%%",
            [4] = "顧客数%s%d%%",
            [5] = "顧客の料理待ち時間%s%d%%",
            [11] = "和食メニューを販売した時、%d%%ゴールドの追加報酬を獲得できます。",
            [12] = "洋食メニューを販売した時、%d%%ゴールドの追加報酬を獲得できます。",
            [13] = "エスニックメニューを販売した時、%d%%ゴールドの追加報酬を獲得できます。",
            [14] = "スイーツメニューを販売した時、%d%%ゴールドの追加報酬を獲得できます。",
            [15] = "ドリンクメニューを販売した時、%d%%ゴールドの追加報酬を獲得できます。",
            add = "增加",
            minus = "減少",
            fanwei_greater_zero = "周囲%d枠に効果があります。",
            fanwei_zero = "周囲の属性に効果がありません。",
        },
        not_ct_level = "レストランレベルは%s級に達していません。",
        item_max_level = "該当アイテムは既に最大レベルです。",
        furniture_coin_pink_diamond = "装飾コインが不足です。ピンクダイヤを使用しますか？",
        not_prop_skip = {
            [2] = "ゴールドが足りません。ショップに移動します？",
            [3] = "ピンクダイヤが足りません。ショップに移動します？",
            [4] = "裝飾コインが足りません。ショップに移動します？",
        },
        not_level = "レベルが足りません",
        not_corgi_skip = "アクアコインが足りません。ショップに移動します？",
        not_friend_skip = "フレンドポイントが足りません。ショップに移動します？",
    },

    menuui={
        menu_not = "該当レシピを所持していません。",
        menu_success_compound = "レシピ合成に成功",
        menu_fail_compound = "レシピ合成に失敗",
        menu_success_unlock = "アンロック成功",
        menu_fail_unlock = "アンロック失敗",
        not_enought_chip = "アンロックには「レシピの欠片」が足りません。",
        is_consume_chip_compound_menu = "レシピの欠片を消費してメニューを合成しますか？",
        max_unlock = "最大値まで解放",
        menu_produce_fail = "レシピ研究に失敗",
        not_enought_gold = "ゴールドが足りません。",
        not_enought_material = "原料が足りません。",
        menu_produce = "レシピ研究",
        is_consume_gold_produce_menu = "ゴールドを消費してメニューを研究しますか？",
        not_unlock_grid = "該当記録枠はまだ未解放です、先に解放するようにしてください。",
        menu_compound = "レシピ合成",
        not_menu_grid = "該当枠はレシピ研究を記録存していません。",
        menu_produce_success = "正常に記録しました。",
        not_select_grid = "記録枠を選択していません。",
        menu_alert = "提示",
        sure_add_menu_name = "料理「%s」を追加しますか。",
        sure_down_menu_nam = "メニューを撤去しますか。《%s》",
        select_material_type={
            [1] = "材料品質を選択してください。",
            [2] = "調味料の品質を選択してください。"
        },
        text_grid = "%s  枠%d",
        not_produce_material = "この原材料を持っていません。",
        is_consume_prop_unlock = "%sx%dを消費して解放しますか？",
        is_consume_prop_unlock_grid = "[%s]x%dを消費してレシビ記録枠を解放しますか？",
        is_learn_menu = "習得しますか[%s]",
        to_spices = "最大4種類の調味料を選択してください。",
        field_menu_name = "ここをタップして料理の名前を変更しましょう。",
        menu_making_time = "%s秒",
        give_up_menu = "保存せずに終了すると、レシピ開発経験値も獲得できません。よろしいですか？",
        replace_menu_name = "選択中の料理は今回研究の料理に置換されます。",

        menu_material_num = {
            [1] = "少量",
            [2] = "中量",
            [3] = "大量"
        },
        replace_main_menu = "該当料理は販売中です。交換すると店舗メニューから下げられます。",
        is_save_grid_menu = "該当枠に保存しますか？",
        ct_level_open = "レストランレベル%d級解放",
        not_enought_menu_chip = "レシピの欠片不足",
        max_menu_exp = "レシピ経験値は最大限に達しています。",
        not_last = "最後です。",
        not_front = "最前です。",
        prop_unlock_grid = "X%d解放",
        get_friend_material = "フレンドに応援を要請しますか？",
        material_overdue = "%s食材の使用期限が切れてしまいました。出品できません。",
    },
    petnote={
        notename = "%sのノート",
        need_pet_level = "先にスタッフノートを解放してください。",
        StudySucceed = "習得成功！",
        Studynoteed = "習得済みです",
    },
    petui={
        ownFonts={
            [1] = "全 部",
            [2] = "所 有",
            [3] = "未所有"
        },
        sortFonts={
            [1] = "好感度",
            [2] = "指揮",
            [3] = "能力",
            [4] = "レアリティ",
        },
        skillCircle = {
            [1] = {icon_id = "Skill_hong",careerLimitDesc = "職種はレジ担当の時に有効。"},
            [2] = {icon_id = "Skill_huang",careerLimitDesc = "職種がキッチン担当の時に有効になります。"},
            [3] = {icon_id = "Skill_lan",careerLimitDesc = "職種が配膳担当の時に有効になります。"},
            [4] = {icon_id = "Skill_bai",careerLimitDesc = "任意の担当で発効できます。"}
        },
        skill_is_open = "スキル解放に成功しました",
        reset_succeed = "リセットに成功しました",
        not_enough_pet_badge = "けもみみメダルが足りません。",
        pet_exchange_success = "スタッフ%dを雇用しました！これからよろしくね！",
        is_consume_exchange = "けもみみメダルX%dを消費して[%s]と交換しますか？",
        pet_exchange = "交換",
        not_open_pet_exchange = "まだ交換は開放されていません。",
        not_reach_level = "%d級に到達してません、該当商品購入できません。",
        not_reach_ct_level = "レストランは%d級未満です。該当品物購入できません。",
        not_enough_skill_can = "スキル缶詰が足りません。購入しますか？",
        not_enough_BingGan = "クッキーが足りません。購入しますか？",
        not_find_skill = "未知のスキルです",
        not_open_skill = "まだ解放されていません。",
        prop_not_use = "アイテムが使用できません。",
        not_enought_prop = "ご褒美アイテムが足りません。購入しますか。",
        pet_favour_max = "スタッフ好感度が上限に達しました。アップデートをお待ち下さい",
        fidelity_Max = "好感度最大",
        skin_get_way = {
            [1] = "ショップ購入",
            [2] = "限定イベント",
            [3] = "βテスト限定",
        },
        career = {
            [1] = "レジ",
            [2] = "キッチン",
            [3] = "配膳",
            [4] = "なし"
        },
        pet_skin_buy = "ピンクダイヤx%dを消費して[%s]を購入しますか？",
        manager_leader_not_enough = "レジ担当の指揮値が足りません。レジ担当の指揮値はキッチンスタッフの能力合計値より大きい必要があります",
        not_pet = "未知のスタッフです",
        not_self_pet_change_money = "自分のスタッフではありません。給料の変更はできません",
        too_time_conn = "接続がタイムアウトしました。",
        start_tx_not_find = "星をもらえませんでした",
        not_last = "スタッフはこれで全員です。どんどん増やしてくださいね。",
    },
    informationui = {
        player_id = "id:%s",
        change_name = "名前変更",
        consume_diamond_change_name = "%d個ピンクダイヤを消費します。",
        head_useing = "該当のアバターアイコンは使用中です。",
        head_change = "このアイコンに変更しますか？",
        switch_account = "アカウントの切り替え",
        is_switch_account = "タイトル画面に戻りますか？",
        not_have_head = "該当アイコンは未所有です。",
        useing_always = "永久",
        use_head_overdue = "アイコン使用時間が切れました。",
    },
    persentui = {
        already_sign = "本日のログボは受領済みです。明日またいらしてくださいね。",
        persent_limitation_shop = {
            [1]="本日購入:%s回",
            [2]="今週購入:%s回",
            [3]="30日購入:%s回",
            [4]="7日購入:%s回",
        },
        buy_again_verify = "%sを購入しますか？",
        max_reward_title = "報酬のお届けです。",
        input_libao_code = "交換コードを入力してください。",
    },
    missionui={
        line_mission_receive_nums = "デイリー:(%d/10)",
        max_receive_line_mission = "本日受領したサブクエストは10個に達しました。",
    },
    payui={
        frist_pay_hint = "初回はピンクダイヤ2倍を獲得できます。一回のみですが、購入しますか？",
        pay_success_hint = "購入に成功しました。合計%d個ピンクダイヤを獲得しました。",
        is_goto_pay = "購入しますか？",
        pay_fail = "購入に失敗しました。",
        pay_success = "購入に成功しました。",
    },
    leagueui={
        rank_reward_title = {
            fixed = "ランキング%d位は報酬の獲得が可能です。",
            range = "ランキング%d-%d位ボーナスの獲得が可能です。"
        },
        star_reward_title = {
            fixed = "%d星報酬の獲得が可能です。",
            range = "%d-%d星報酬の獲得が可能です。"
        },
        league_desc = "    ".."コンテストは毎日9時開放、21時前に当日指定料理を何回も提出が可能です。21時に審査を行い、奨励は21時にメールで発送します。【奨励】をクリックして内訳を確認できます。レストランレベル10以上でコンテストに参加できます。※同点数の場合は達成の時間順で格付けます。",
        not_select_menu = "お料理はまだ選択されていません。",
        not_make_menu = "このい料理はまだ出品できません。",
        not_open_league = "開放時間ではありません。お待ち下さい。",
        not_open_service = "サーバーはオープンしていません。",
        rank_front = "前%s",
        not_open_ct_level = "レストランレベルは%d級に達していません。",
        material_overdue  = "%s食材の使用期限切れです。お料理を追加できません。",
        add_own_alert = "リーグ戦に参加しています。繰り返して入力すれば書き換えることができます。",
    },
    not_enough_pink_diamond = "ピンクダイヤが足りません。",
    not_reach_player_level = "レベルが%sに達していません。",
    not_enough_prop = "%sが足りません。",
    not_summon_book = "ガチャ券が足りません。購入しますか？",
    is_summon_one = "ガチャを一回実行しますか？",
    
    rank = {
        up_need_str = {"人気値%s" , "評価ランキング上位%s"},
        on_need_str = "格付けランキング%s",
        down_need_str = "格付けランキング%s",
        not_on_rank = "ランキングに間もなく参加！経営を進めましょう。",
        not_up_str = "ランクアップ条件はありません",
        not_on_str = "リーグ維持条件はありません。",
        not_down_str = "ランクダウンはありません",
        on_rank_forme = "現在評価ランク：%d",
        on_rank_grade = "同段位ランキング：%d",
        on_rank_up = "オーナー様、上位リーグに昇級しました！これからもどんどん上位を目指してください。",
        on_rank_down = "オーナー様、下位リーグに降格してしまいました。次回は昇級しましょうね！",
    },

    friend = {
        find_new_friend = "新しいフレンドを発見しました。",
        new_friend_add = "フレンド申請が来ています。",
        get_friend_point = "フレンドポイントを獲得しました。",
        have_firend_remove = "フレンド解除",
        is_on_friend_home = "フレンドのレストランにいます。",
        friend_not_open = "フレンドはレストランをオープンしていません。",
        give_friend_point = "プレゼント成功！",
        text_nil = "入力がありません。",
        error_id_name = "無効な名前またはIDです。",
        not_add_self = "自分を追加することができません。",
        is_remove_friend = "フレンドを解除しますか？",
        is_add_black = "ブラックリストに追加しますか？",
        need_remove_firend = "解除したいフレンドをチェックしましょう。",
        not_friend_verify = "フレンド申請がありません。",
        seed_max_point = "本日のプレゼント回数が上限に達しています。",
        get_max_point = "本日受領回数が上限に達しています。",
        not_get_point = "プレゼントのあるフレンドはいません。",
        not_seed_friend = "プレゼントできるフレンドがいません。",
        is_not_remove_black = "ブラックリストを解除しますか？",
        friend_max_num = "フレンド人数が最大に達しています。フレンド追加はできません。",
        send_add_to = "申請済みです。承認をお待ちくださいませ。",
        send_add_success = "申請に成功しました。",
        on_black_list_me = "あなたはブラックリストに入っています。申請できません。",
        on_black_list_you = "相手はブラックリストに入っています。申請はできません。",
        is_friend_me = "既にフレンドになっています。メールを送ってみましょう！",
        not_find_friend = "ユーザーデータを見つけられませんでした。",
        is_add_friend = "フレンド追加しますか？",
        add_need_material = "フレンド追加に成功しました。",
        oneMenuBuyOne = "同じ料理は一日一度しか代理販売ができません。",
        MenuTimeOut = "食材の残り時間は12時間未満です。",
        friend_err_adorn = "フレンドレストラン裝飾配置エラー",
    },
    adui = {
        ad_buy_title = "[%s]を購入しますか？",
        not_join_group = "グループに参加していません。",
        buy_time_ad = "%s:00-%s:00期間の広告を購入します。",
        default_ad_context = "私は至って普通のオーナーです。けれども自慢のスタッフとお料理でみなさまをお迎えさせていただきます。",
        ad_buy_success = "購入に成功しました",
        ad_assist_success = "「いいね！」成功",
        ad_sub_rank_title_time = "%s-%sの広告ランキングの順位ボーナスは%s-%s有効になります。",
        ad_sub_rank_self_score = "%d部",
        ad_sub_rank_rank = "第%d位",
        ad_coin_pink_diamond = "広告コインが足りません。ピンクダイヤを使用しますか？",
        not_ad_coin_pay = "広告コイン足りません。購入しますか？",
    },
    marketui={
        is_buy_goods = "%sx%sを購入しますか？",
        refresh_title = "アクアコインx%dを消費して市場のラインナップを更新しますか？",
        lime_day = "%d日",
        not_prop_title = "%s不足",
    },
    guideui = {
        guide_fail = "ソフトリードフローにエラーが出ました~"
    },
    searchpath={
        eat_error = "食事開始後ロジカル異常！お問い合わせよりご連絡してください。ご協力に感謝します。",
        eat_error_title = "食事開始後ロジカル異常！顧客ID:%d！！",
        join_ct_error = "入店処理異常！顧客ID:%d！！",
        customer_join_agin = "重複してレストランに入った顧客がいました！顧客ID:%d！！",
        customer_loss = "喪失顧客 group_id:%d  顧客ID:%d！！",
        customer_join_chair_agin = "顧客がテーブル着席時、重複の顧客ID:%dが出現しました！！",
        invoicing_error = "お会計後処理異常がありました。顧客ID:%d！！",
    },
    tilemap={
        loading_map = "レストランをロード中です。",
        loading_progress = "ロード進捗%d%s",
    },
    mainui = {
        customer_state_change_fail = "顧客状態変更エラー~",
        customer_state_code_fail = "顧客状態 エラーコード：%s お問い合わせよりご連絡ください。",
    },

    error_msg = "エラー",
    system_msg = "システムメッセージ",

    UIFONT={
        Text_lvltip_M = "レシピレベルアップが可能です、各属性の評価がアップ可能です。"
    },
	Japan_Market_Content = {
        android_platform = {
            [1] = {
                title = "前払式支払手段に関する表記",
                content_desc = "1.前払式支払手段発行者の商号及び所在地\n"..
                "  株式会社ケイブ\n"..
                "  〒153-0051　東京都目黒区上目黒二丁目1番1号\n\n"..
                
                "2.支払可能金額\n"..
                "  お客様が購入できる「ピンクダイヤ」の上限額はありません。\n"..
                "   ただし、お客様が16歳以下の場合、一つの利用者IDで購入できる上限は、以下のとおりとします。\n"..
                "    ・利用者が16歳以下の場合、5000円/月とします。\n\n"..

                "3.有効期限\n"..
                "  お客様が購入した「ピンクダイヤ」について、購入日より180日とします｡また、当社は最"..
                "終のアクセスから１年間以上経過している利用者ID並びに利用者IDに紐づく情報をあら"..
                "かじめお客様に通知することなく削除できます。この場合、未使用の「ピンクダイヤ」は失"..
                "効します。同様に、お客様自身により契約が解除された場合は、「ピンクダイヤ」の未使用残"..
                "高は全て失効し、返金を行うことはございません。\n"..
                "   ※規約違反による利用者ID剥奪の場合も同様です。\n\n"..

                "4.使用場所の範囲\n"..
                "  Androidアプリ『けもみみメロメロレシピ』（以下、「本サービス」といいます。）内でのみ使用できます｡\n"..
                "  Googleチェックアウトでの購入、お支払いとなります。お客様のGoogleIDに登録されたクレジットカード、その他Google社の定めるお支払い方法によりお支払い頂けます。\n"..
                "   ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能期間などを確認の上、ご利用ください。\n\n"..

                "5.　支払方法について \n"..
                "  ご利用の端末によって、お支払いの方法が異なります。\n"..
                "  Googleチェックアウトでの購入、お支払いとなります。お客様のGoogleIDに登録されたクレジットカード、その他Google社の定めるお支払い方法によりお支払い頂けます。\n"..
                "  ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能な期間などを確認の上、ご利用ください。\n\n"..
                
                "6. 利用上のご注意\n"..
                "  (1)「ピンクダイヤ」は、本サービス利用者の方にのみ販売しております\n"..
                "  (2)「ピンクダイヤ」を他の会員IDに貸与、譲渡、売買、質入等することはできません。\n"..
                "   (3)原則として、ご購入されました「ピンクダイヤ」の払戻しはできません（詳しくは、利用規約をご覧ください）\n\n"..
                
                "7. 未使用残高の確認方法\n"..
                "  本サービスの画面上にある「ピンクダイヤ」表示から確認してください｡\n\n"..
                
                "8. 利用規約\n"..
                "  本サービス利用規約はこちら。"
            },
            [2] = {
                title = "特定商取引法に関する法律",
                content_desc = "1.　商品価格\n"..
                "  アプリ内「ショップ」の価格欄を参照（表示価格は税込）\n"..
                "  ※購入手続きの際、都度画面に表示致します。\n\n"..
                
                "2.　販売条件\n"..
                "  ご利用のお支払方法により、決済代行会社所定の手続き、限度額が適用となります。\n\n"..
                
                "3.　送料\n"..
                "  商品の特性上、発生しません。\n\n"..
                
                "4.　商品価格以外に必要な料金\n"..
                "  当コンテンツのインターネット接続にかかわる携帯端末利用代金、パケット通信料などの諸費用については、お客様の負担となります。\n"..
                "  ※料金はお客様がご利用の携帯電話事業者等にお問合せください。\n\n"..
                
                "5.　支払方法について \n"..
                "  ご利用の端末によって、お支払いの方法が異なります。\n"..
                "  Googleチェックアウトでの購入、お支払いとなります。お客様のGoogleIDに登録されたクレジットカード、その他Google社の定めるお支払い方法によりお支払い頂けます。\n"..
                "  ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能な期間などを確認の上、ご利用ください。\n\n"..
                
                "6. 支払時期について\n"..
                "  商品購入画面の購入ボタンをおした後\n\n"..
                
                "7. 商品の引き渡し時期\n"..
                "  お支払手続き終了後、すぐにお引渡しいたします。 \n\n"..
                
                "8. 返品に関する特約\n"..
                "  商品の特性上、購入後の返品・交換・キャンセル・返金には応じられません。\n\n"..
                
                "9.ピンクダイヤ・アクアコインの取扱い\n"..
                "  ピンクダイヤ（購入分）とアクアコイン（無料配布分）を所持していた場合、\n"..
                "  ピンクダイヤ（購入分）が優先して消費されます。ピンクダイヤ（購入分）の中での消費は、購入した順番で消費されます。\n\n"..
                
                "10. 対応端末\n"..
                "  対象のアプリが動作するAndroid端末が必要です。\n"..
                "  動作環境はアプリの公式サイトにてご確認ください。\n\n"..
                
                "11.　販売業者名\n"..
                "  株式会社ケイブ\n\n"..
                
                "12.　販売責任者・代表者氏名\n"..
                "  高野　健一\n"..
                
                "13.　所在地\n"..
                "  〒153-0051　東京都目黒区上目黒二丁目1番1号\n"..

                "14.　電話番号\n"..
                "  03-6820-8176（受付時間は10時～18時、土・日・祝を除く）\n\n"..
                
                "15.アプリに関する問い合わせ先"
            }
        },
        ios_platform = {
            [1] = {
                title = "前払式支払手段に関する表記",
                content_desc = "1.前払式支払手段発行者の商号及び所在地\n"..
                "  株式会社ケイブ\n"..
                "  〒153-0051　東京都目黒区上目黒二丁目1番1号\n\n"..
                
                "2.支払可能金額\n"..
                "  お客様が購入できる「ピンクダイヤ」の上限額はありません。\n"..
                "   ただし、お客様が16歳以下の場合、一つの利用者IDで購入できる上限は、以下のとおりとします。\n"..
                "    ・利用者が16歳以下の場合、5000円/月とします。\n\n"..

                "3.有効期限\n"..
                "  お客様が購入した「ピンクダイヤ」について、購入日より180日とします｡また、当社は最"..
                "終のアクセスから１年間以上経過している利用者ID並びに利用者IDに紐づく情報をあら"..
                "かじめお客様に通知することなく削除できます。この場合、未使用の「ピンクダイヤ」は失"..
                "効します。同様に、お客様自身により契約が解除された場合は、「ピンクダイヤ」の未使用残"..
                "高は全て失効し、返金を行うことはございません。\n"..
                "   ※規約違反による利用者ID剥奪の場合も同様です。\n\n"..

                "4.使用場所の範囲\n"..
                "  Androidアプリ『けもみみメロメロレシピ』（以下、「本サービス」といいます。）内でのみ使用できます｡\n"..
                "  Googleチェックアウトでの購入、お支払いとなります。お客様のGoogleIDに登録されたクレジットカード、その他Google社の定めるお支払い方法によりお支払い頂けます。\n"..
                "   ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能期間などを確認の上、ご利用ください。\n\n"..

                "5.　支払方法について \n"..
                "  ご利用の端末によって、お支払いの方法が異なります。\n"..
                "  Googleチェックアウトでの購入、お支払いとなります。お客様のGoogleIDに登録されたクレジットカード、その他Google社の定めるお支払い方法によりお支払い頂けます。\n"..
                "  ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能な期間などを確認の上、ご利用ください。\n\n"..
                
                "6. 利用上のご注意\n"..
                "  (1)「ピンクダイヤ」は、本サービス利用者の方にのみ販売しております\n"..
                "  (2)「ピンクダイヤ」を他の会員IDに貸与、譲渡、売買、質入等することはできません。\n"..
                "   (3)原則として、ご購入されました「ピンクダイヤ」の払戻しはできません（詳しくは、利用規約をご覧ください）\n\n"..
                
                "7. 未使用残高の確認方法\n"..
                "  本サービスの画面上にある「ピンクダイヤ」表示から確認してください｡\n\n"..
                
                "8. 利用規約\n"..
                "  本サービス利用規約はこちら。"
            },
            [2] = {
                title = "特定商取引法に関する法律",
                content_desc = "1.　商品価格\n"..
                "  アプリ内「ショップ」の価格欄を参照（表示価格は税込）\n"..
                "  ※購入手続きの際、都度画面に表示致します。\n\n"..
                
                "2.　販売条件\n"..
                "  ご利用のお支払方法により、決済代行会社所定の手続き、限度額が適用となります。\n\n"..
                
                "3.　送料\n"..
                "  商品の特性上、発生しません。\n\n"..
                
                "4.　商品価格以外に必要な料金\n"..
                "  当コンテンツのインターネット接続にかかわる携帯端末利用代金、パケット通信料などの諸費用については、お客様の負担となります。\n"..
                "  ※料金はお客様がご利用の携帯電話事業者等にお問合せください。\n\n"..
                
                "5.　支払方法について \n"..
                "  ご利用の端末によって、お支払いの方法が異なります。\n"..
                "  App Storeでの購入、お支払いとなります。お客様のAppleIDに登録されたクレジットカード、iTunesカードその他アップル社の定めるお支払い方法によりお支払い頂けます。\n"..
                "  ※各商品ページに記載の商品の販売期間、利用可能期間、ダウンロード可能な期間などを確認の上、ご利用ください。\n\n"..
                
                "6. 支払時期について\n"..
                "  商品購入画面の購入ボタンをおした後\n\n"..
                
                "7. 商品の引き渡し時期\n"..
                "  お支払手続き終了後、すぐにお引渡しいたします。 \n\n"..
                
                "8. 返品に関する特約\n"..
                "  商品の特性上、購入後の返品・交換・キャンセル・返金には応じられません。\n\n"..
                
                "9.ピンクダイヤ・アクアコインの取扱い\n"..
                "  ピンクダイヤ（購入分）とアクアコイン（無料配布分）を所持していた場合、\n"..
                "  ピンクダイヤ（購入分）が優先して消費されます。ピンクダイヤ（購入分）の中での消費は、購入した順番で消費されます。\n\n"..
                
                "10. 対応端末\n"..
                "  対象のアプリが動作するAndroid端末が必要です。\n"..
                "  動作環境はアプリの公式サイトにてご確認ください。\n\n"..
                
                "11.　販売業者名\n"..
                "  株式会社ケイブ\n\n"..
                
                "12.　販売責任者・代表者氏名\n"..
                "  高野　健一\n"..
                
                "13.　所在地\n"..
                "  〒153-0051　東京都目黒区上目黒二丁目1番1号\n"..
                
                "14.　電話番号\n"..
                "  03-6820-8176（受付時間は10時～18時、土・日・祝を除く）\n\n"..
                
                "15.アプリに関する問い合わせ先"
            }
        }
    }
}

return Language
