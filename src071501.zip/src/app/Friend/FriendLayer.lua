
local ImageCheckBox = require("app.public.ImageCheckBox")
local FriendCell = require("app.Friend.FriendCell")
local FriendLayer = class("FriendLayer", FZutil.createUILayer)

local cellSize = {
	width = 140,
	height = 137
}
function FriendLayer:ctor(Home_Self)
	self.HomeScene_Self = Home_Self
    self:setBackGroundColorOpacity(math.floor(0.3*0xff))
	self:enableNodeEvents()
    local friendUI = FZutil.createSceneNode("FriendUI/FriendUI")
	self:addChild(friendUI.root)
	self.friendUI = friendUI
	friendUI.Node_bottom:setPosition(display.cx,-250)
	local ac_key = false
	transition.moveTo(friendUI.Node_bottom,{x=display.cx,y=0,time=0.4,onComplete=function()
		ac_key = true
	end})
	self.scrollViewUI = friendUI.ScrollView_5
	--
	friendUI.Button_guanbi:onTouch(function(e)
		if e.name == "ended" and ac_key then
			ac_key = false
			self:closelayer()
		end
	end)
	--
	self.CellAlls = {{},{},{},{}}--用于保存cell
	-- 对应切页下Node
	self.DownView = { friendUI.FileNode_friendship, friendUI.FileNode_add, friendUI.FileNode_apply, friendUI.FileNode_blacklistdel, friendUI.FileNode_del}
	-- 切页
	local CheckBox_friend = ImageCheckBox.initOneNode(friendUI.Node_bottom,"Image_friend2","Image_friend1")
	local CheckBox_add = ImageCheckBox.initOneNode(friendUI.Node_bottom,"Image_add2","Image_add1")
	local CheckBox_apply = ImageCheckBox.initOneNode(friendUI.Node_bottom,"Image_apply2","Image_apply1")
	local CheckBox_black = ImageCheckBox.initOneNode(friendUI.Node_bottom,"Image_blacklist2","Image_blacklist1")
	local checkBoxs = {CheckBox_friend,CheckBox_add,CheckBox_apply,CheckBox_black}

	local group = ImageCheckBox.initGroup(checkBoxs,function(CheckBox_index)
		self:UpdateFriendLayer(CheckBox_index)
	end)
	-- 红点
	local checkBoxRedPoints = {}
	for _idx,_check_box in ipairs(checkBoxs) do
		local redIconPath = IconPath.getRedPintIcon()
		local redPoint = ccui.ImageView:create(redIconPath)
		local normalImg = _check_box.normal
		local checkSize = normalImg:getContentSize()
		redPoint:setPositionX(checkSize.width)
		normalImg:addChild(redPoint)
		redPoint:setVisible(false)
		table.insert(checkBoxRedPoints,redPoint)
	end
	self.checkBoxRedPoints = checkBoxRedPoints
	-- 初始第一个切页
	ImageCheckBox.setSelectIndex(group,1)
	-- 点击空白将移动切页5转为1
	-- self:addClickEventListener(function(event)
 --        if FriendData.On_FriendLayer_Index == 5 then
 --        	self:UpdateFriendLayer(1)
 --        end
 --   	end)

 	MyApp:pushTopCloseLayer("FriendLayer",function()
 		if ac_key then
 			ac_key = false
 			self:closelayer()
 		end
 	end)
end
function FriendLayer:selectDownView(index)
	for k,view in pairs(self.DownView) do
		if index == k then
			view:show()
		else
			view:hide()
		end
	end
	for k,tab in pairs(self.CellAlls) do
		for i,cell in pairs(tab) do
			cell:hide()
		end
	end
end
function FriendLayer:initFriendCheckBoxUI(CheckBox_index)
	local CheckBox_index = CheckBox_index or self.CheckBox_index
	print("*******哈哈******** "..CheckBox_index)
	self:selectDownView(CheckBox_index)
	if CheckBox_index == 1 then -- 好友详情
		self:UpdataFriendInfoView()
	elseif CheckBox_index == 2 then -- 添加 推荐好友列表
		self:UpdataFriendAddView()
	elseif CheckBox_index == 3 then -- 申请 加我的人列表
		self:UpdataFriendApplyView()
	elseif CheckBox_index == 4 then -- 黑名单
		self:UpdataFriendBlackView()
	elseif CheckBox_index == 5 then -- 按钮显示的删除
		self:UpdataFriendRemoveView()
	end
	self:UpdataScrollView() -- 加载滚动层数据
end
function FriendLayer:UpdataFriendInfoView() -- 好友详情
	-- 加载DownView
	local On_DownView = self.DownView[self.CheckBox_index]
	local Friend_num_txt = On_DownView:getChildByName("Image_frinum"):getChildByName("Text_num1") -- 好友数
	local Get_num_txt = On_DownView:getChildByName("Image_getpresent"):getChildByName("Text_num1")   -- 收礼次数
	local Seed_Num_txt = On_DownView:getChildByName("Image_givepresent"):getChildByName("Text_num1")   -- 送礼次数
	local friend_num = table.nums(FriendData.friend_list)
	Friend_num_txt:setString(friend_num)
	Get_num_txt:setString(FriendData.My_Get_Num)
	Seed_Num_txt:setString(FriendData.My_Seed_Num)
	local Button_receive = On_DownView:getChildByName("Button_receive")
	local receiveBtnNormal = Button_receive:getChildByName("Image_word1")
	local receiveBtnCover = Button_receive:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_receive,receiveBtnNormal,receiveBtnCover,function(e) -- 一键领取
		if e.name == "ended" then
			print("一键领取")
			local Has_Num = 10 - FriendData.My_Get_Num
			if Has_Num<=0 then
				MoveMessage.show(Language.friend.get_max_point)
				return
			end
			local msg_data = {}
			for k,data in pairs(FriendData.friend_list) do
				-- 0没有 1有 2有并且暴击 3有但领取过了
				if (data.is_get_friend_point == 1 or data.is_get_friend_point == 2) and #msg_data<Has_Num then 
					table.insert(msg_data,#msg_data+1,data.player_id)
				end
			end
			if #msg_data>0 then
				NetEngine:sendMessage(game_cmd.CGiveFriendPoint,{friend_ids = msg_data})
			else
				MoveMessage.show(Language.friend.not_get_point)
			end
		end
	end)
	local Button_giveback = On_DownView:getChildByName("Button_giveback")
	local givebackBtnNormal = Button_giveback:getChildByName("Image_word1")
	local givebackBtnCover = Button_giveback:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_giveback,givebackBtnNormal,givebackBtnCover,function(e)-- 一键回赠
		if e.name == "ended" then
			print("一键回赠")
			local Has_Num = 10 - FriendData.My_Seed_Num
			if Has_Num<=0 then
				MoveMessage.show(Language.friend.seed_max_point)
				return
			end
			local msg_data = {}
			for k,data in pairs(FriendData.friend_list) do
				if data.is_send_friend_point == 0 and #msg_data<Has_Num then -- 0没有 1有
					table.insert(msg_data,#msg_data+1,data.player_id)
				end
			end
			if #msg_data>0 then
				NetEngine:sendMessage(game_cmd.CSendFriendPoint,{friend_ids = msg_data})
			else
				MoveMessage.show(Language.friend.not_seed_friend)
			end
		end
	end)
	local Button_removeList = On_DownView:getChildByName("Button_add")
	local removeBtnNormal = Button_removeList:getChildByName("Image_word1")
	local removeBtnCover = Button_removeList:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_removeList,removeBtnNormal,removeBtnCover,function(e)-- 批量删除
		if e.name == "ended" then
			FriendData.Local_Remove_Friend_Tab = {}
			self:UpdateFriendLayer(5)
		end
	end)
end
local touch_time_key = false -- 10s计时刷新推荐列表
function FriendLayer:UpdataFriendAddView() -- 添加
	local CheckBox_index = self.CheckBox_index
	local On_DownView = self.DownView[CheckBox_index]
	-- 加载DownView
	local TextField_UI = On_DownView:getChildByName("TextField_1")
    TextField_UI:setMaxLengthEnabled(true)
	local Button_add = On_DownView:getChildByName("Button_add")
	local addBtnNormal = Button_add:getChildByName("Image_word1")
	local addBtnCover = Button_add:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_add,addBtnNormal,addBtnCover,function(e)	-- 输入名字或ID 添加好友
		if e.name == "ended" then
            local NameStr = TextField_UI:getString()
            local msg = self:getStrBool(NameStr)
            if msg then
            	NetEngine:sendMessage(game_cmd.CSearchFriend,msg)
            end
			print("添加好友")
		end
	end)
	local Button_change = On_DownView:getChildByName("Button_change")
	local wordTxt = Button_change:getChildByName("Image_word1")
	local wordTxt2 = Button_change:getChildByName("Image_word2")
	local Text_time = Button_change:getChildByName("Text_time")
	local Text_timebg = Button_change:getChildByName("Text_timebg")
	if not touch_time_key then
		wordTxt:setPositionY(23)
		wordTxt2:setPositionY(23)
		Text_time:hide()
		Text_timebg:hide()
	end

	local changeBtnNormal = Button_change:getChildByName("Image_word1")
	local changeBtnCover = Button_change:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_change,changeBtnNormal,changeBtnCover,function(e)	-- 换一批 推荐好友
		if e.name == "ended" then
			Button_change:stopAllActions()
			Button_change:setTouchEnabled(false)
			Button_change:setBright(false)
			wordTxt:setPositionY(30)
			wordTxt2:setPositionY(30)
			Text_time:show()
			Text_timebg:show()
			touch_time_key = true
			local index = 10
	        Text_time:setString(string.format("%d秒", index))
			local function ForCallfunc()
	        performWithDelay(Button_change,function ()
	        		index = index - 1
	        		Text_time:setString(string.format("%d秒", index))
	                if index<=0 then
	                	touch_time_key = false
	                    Button_change:setTouchEnabled(true)
						Button_change:setBright(true)
						wordTxt:setPositionY(23)
						wordTxt2:setPositionY(23)
						Text_time:hide()
						Text_timebg:hide()
	                else
	                    ForCallfunc()
	                end
	            end,1)
	        end
	        ForCallfunc()
			NetEngine:sendMessage(game_cmd.CGetRecommendFriends)
		end
	end)
	local Button_applyall = On_DownView:getChildByName("Button_applyall")
	local applyallBtnNoraml = Button_applyall:getChildByName("Image_word1")
	local applyallBtnCover = Button_applyall:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_applyall,applyallBtnNoraml,applyallBtnCover,function(e)	-- 一键添加
		if e.name == "ended" then
			if FriendData:checkFriendNumMax() then
				MoveMessage.show(Language.friend.friend_max_num)
				return 
			end
			local msg_data = {}
			for k,data in pairs(FriendData.add_list) do
				table.insert(msg_data,#msg_data+1,data.player_id)
			end
			if #msg_data>0 then
				NetEngine:sendMessage(game_cmd.CAddFriend,{player_id = msg_data})
			end
		end
	end)
end
function FriendLayer:UpdataFriendApplyView() -- 申请
	local On_DownView = self.DownView[self.CheckBox_index]
	local Button_sure = On_DownView:getChildByName("Button_sure") -- 一键同意
	local Button_reject = On_DownView:getChildByName("Button_reject") -- 一键拒绝
	local function TouchCallFunc(is_not)
		local isnot = 1 -- 同意
		if is_not then
			isnot = 2 -- 拒绝
		end
		local msg_data = {}
		for k,data in pairs(FriendData.verify_list) do
			local verify_data = {player_id = data.player_id, state = isnot}
			table.insert(msg_data,#msg_data+1,verify_data)
		end
		if #msg_data>0 then
			NetEngine:sendMessage(game_cmd.CVerifyFriends,{verify_datas = msg_data})
		else
			MoveMessage.show(Language.friend.not_friend_verify)
		end
	end

	local sureBtnNormal = Button_sure:getChildByName("Image_word1")
	local sureBtnCover = Button_sure:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_sure,sureBtnNormal,sureBtnCover,function(e)	-- 一键同意
		if e.name == "ended" then
			if FriendData:checkFriendNumMax() then
				MoveMessage.show(Language.friend.friend_max_num)
				return 
			end
			TouchCallFunc()
		end
	end)

	local rejectBtnNormal = Button_reject:getChildByName("Image_word1")
	local rejectBtnCover = Button_reject:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_reject,rejectBtnNormal,rejectBtnCover,function(e)	--一键拒绝
		if e.name == "ended" then
			TouchCallFunc(true)
		end
	end)
end
function FriendLayer:UpdataFriendBlackView() -- 黑名单
	local On_DownView = self.DownView[self.CheckBox_index]
	local Button_out = On_DownView:getChildByName("Button_out") -- 一键移除
	local outBtnNormal = Button_out:getChildByName("Image_word1")
	local outBtnCover = Button_out:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_out,outBtnNormal,outBtnCover,function(e)	-- 一键移除
		if e.name == "ended" then
			local msg_data = {}
			for k,data in pairs(FriendData.black_list) do
				local blackdata = {player_id = data.player_id}
				table.insert(msg_data,#msg_data+1,blackdata)
			end
			NetEngine:sendMessage(game_cmd.CDelBlackList,{black_datas = msg_data})
		end
	end)
	--
	local TextField_UI = On_DownView:getChildByName("TextField_1")
    TextField_UI:setMaxLengthEnabled(true)
	local Button_add = On_DownView:getChildByName("Button_add")
	local addBtnNormal = Button_add:getChildByName("Image_word1")
	local addBtnCover = Button_add:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_add,addBtnNormal,addBtnCover,function(e)	-- 输入名字或ID 添加黑名单
		if e.name == "ended" then
            local NameStr = TextField_UI:getString()
            local msg = self:getStrBool(NameStr)
            if msg then
				NetEngine:sendMessage(game_cmd.CAddBlackList,{black_datas = {msg}})
            end
			print("添加黑名单")
		end
	end)
end
function FriendLayer:UpdataFriendRemoveView() -- 删除好友
	local On_DownView = self.DownView[self.CheckBox_index]
	local Button_remove = On_DownView:getChildByName("Button_giveback") -- 删除好友
	local removeBtnNormal = Button_remove:getChildByName("Image_word1")
	local removeBtnCover = Button_remove:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_remove,removeBtnNormal,removeBtnCover,function(e)
		if e.name == "ended" then
			-- 选中要删除的好友 ID 数组
			local msg_data = {}
			local msg_black = {}
			for k,id in pairs(FriendData.Local_Remove_Friend_Tab) do
				local blackdata = {player_id = id}
				table.insert(msg_data,#msg_data+1,id)
				table.insert(msg_black,#msg_black+1,blackdata)
			end
			if #msg_data>0 then
				Alert:show("", Language.friend.is_remove_friend, Alert.TYPE_YES_NO, function(tag)
                    if tag then
                        Alert:show("", Language.friend.is_add_black, Alert.TYPE_YES_NO, function(tag)
		                    if tag then
								NetEngine:sendMessage(game_cmd.CAddBlackList,{black_datas = msg_black})
		                    else
								NetEngine:sendMessage(game_cmd.CDelFriends,{player_ids = msg_data})
		                    end
		                end)
                    end
                end)
			else
				MoveMessage.show(Language.friend.need_remove_firend)
			end
		end
	end)
	local Button_back = On_DownView:getChildByName("Button_back") -- 退出批量删除切页5
	local backBtnNormal = Button_back:getChildByName("Image_word1")
	local backBtnCover = Button_back:getChildByName("Image_word2")
	FZutil.onButtonTwoImagTouch(Button_back,backBtnNormal,backBtnCover,function(e)
		if e.name == "ended" then
			self:UpdateFriendLayer(1)
		end
	end)
end
function FriendLayer:UpdataScrollView()
	-- 加载 self.scrollViewUI
	local ScrollView = self.scrollViewUI
	local CheckBox_index = self.CheckBox_index
	local cellType_index = self.CheckBox_index
	if CheckBox_index == 5 then
		CheckBox_index = 1
	end
	local DataType = {
		FriendData.friend_list, -- 好友列表
		FriendData.add_list,
		FriendData.verify_list,
		FriendData.black_list,
	}
	local SViewData = DataType[CheckBox_index]
	local max_num = table.nums(SViewData)
	local cell_num = table.nums(self.CellAlls[CheckBox_index])
	print("** 好友界面Cell数据num: **"..max_num)
	if cell_num > max_num then
    	for i=cell_num,max_num+1,-1 do
    		local cellRoot = self.CellAlls[CheckBox_index][i]
    		cellRoot:removeSelf()
    		table.remove(self.CellAlls[CheckBox_index],i)
    	end
    end
	if SViewData and table.nums(SViewData)>0 then
    	local scrollContentSize = ScrollView:getContentSize()
        local cellW = cellSize.width
        if max_num*cellW>scrollContentSize.width then
            scrollContentSize.width = cellW * max_num
        end

        ScrollView:setInnerContainerSize(scrollContentSize)
    	for k,Data in pairs(SViewData) do
        	local cellRoot = self.CellAlls[CheckBox_index][k]
			if not cellRoot then
				cellRoot = FriendCell.create()
				self.CellAlls[CheckBox_index][k] = cellRoot
				ScrollView:addChild(cellRoot)
			end
			if k%2 == 0 then
				cellRoot:setBgVisible(2)
			else
				cellRoot:setBgVisible(1)
			end
			cellRoot:show()
			cellRoot:init(Data,cellType_index)
            cellRoot:setPosition(k*cellW - cellW/2, scrollContentSize.height/2)
        end
    end
end
function FriendLayer:UpdateFriendLayer(check_index)
	self.CheckBox_index = check_index or self.CheckBox_index
	FriendData.On_FriendLayer_Index = check_index or self.CheckBox_index
	self:initFriendCheckBoxUI()
	self:checkRedPoint()
	if check_index and check_index == 1 then -- 刷新红点
		self:checkRedPointChat()
	end
end
function FriendLayer:checkRedPoint()
	local id_tab = FriendData:checkFirendPoint()
	if FriendData.On_FriendLayer_Index == 1 then
		if #self.CellAlls[1]>0 then
			for k,cellRoot in pairs(self.CellAlls[1]) do
				local id = cellRoot:getCellPlayerID()
				cellRoot:setRedPointVisible(id_tab[id])
			end
		end
	end
	local get_vis = false
	if id_tab and table.nums(id_tab)>0 then -- 检查有没有可以领取的友情点
		get_vis = true 
	else 	-- 检查有没有好友发送消息
		for k,v in pairs(FriendData.friend_list) do
			local id = v.player_id
			if not FriendData.OnChatFriendID or (FriendData.OnChatFriendID and FriendData.OnChatFriendID ~= id) then
				if DyChat:CheckRedPoint(id) then
					get_vis = true
					break
				end
			end
		end
	end
	self.checkBoxRedPoints[1]:setVisible(get_vis)
	self.checkBoxRedPoints[3]:setVisible(table.nums(FriendData.verify_list)>0) -- 是否有加自己的人
end
function FriendLayer:checkRedPointChat()
	if FriendData.On_FriendLayer_Index == 1 then
		if #self.CellAlls[1]>0 then
			for k,cellRoot in pairs(self.CellAlls[1]) do
				local id = cellRoot:getCellPlayerID()
				if not FriendData.OnChatFriendID or (FriendData.OnChatFriendID and FriendData.OnChatFriendID ~= id) then
					if DyChat:CheckRedPoint(id) then
						cellRoot:setChatPointVisible(true)
					else
						cellRoot:setChatPointVisible(false)
					end
				else
					cellRoot:setChatPointVisible(false)
				end
			end
		end
	end
end
function FriendLayer:getStrBool(str)
    local l = #(string.gsub(str, "[\128-\191]" , ""))
    if l==0 then
        MoveMessage.show(Language.friend.text_nil)
        return
    elseif l>10 then
        MoveMessage.show(Language.friend.error_id_name)
        return 
    else
        for i=1,l do
            local n = string.byte(str,i)
            if n<48 or n>57 then
                if str == RoleData.player_info.name then
                    MoveMessage.show(Language.friend.not_add_self)
                    return
                end
                return {name = str}
            end
        end
        if str == tostring(RoleData.player_info.player_id) then
            MoveMessage.show(Language.friend.not_add_self)
            return
        end
        return {player_id = str}
    end
    return
end
function FriendLayer:closelayer()
	transition.moveTo(self.friendUI.Node_bottom,{x=display.cx,y=-250,time=0.4,onComplete=function()
		if FriendData.Own_MapAdorn then
			self.HomeScene_Self:setUpBtnFriend(true)
		end
		self:removeSelf()
	end})
end
function FriendLayer:onEnter()
	FzSound.clearMapScaleSound(2)
    FzEventCenter:RegisterEvent(FzEvent.checkFriendPoint, self, self.checkRedPoint)
    FzEventCenter:RegisterEvent(FzEvent.CheckRedPointChat, self, self.checkRedPointChat)
    FzEventCenter:RegisterEvent(FzEvent.updateFriendLayer, self, self.UpdateFriendLayer)
    FzEventCenter:RegisterEvent(FzEvent.removeFriendLayer, self, self.closelayer)
    if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        SDKCenter:setUserInfo( "", "", 14)
    end
end

function FriendLayer:onExit()
	FzSound.clearMapScaleSound(1)
    FzEventCenter:RemoveEvent(FzEvent.checkFriendPoint,self)
    FzEventCenter:RemoveEvent(FzEvent.CheckRedPointChat,self)
    FzEventCenter:RemoveEvent(FzEvent.updateFriendLayer,self)
    FzEventCenter:RemoveEvent(FzEvent.removeFriendLayer,self)
    touch_time_key = false
	self.CellAlls = nil
	self.DownView = nil
	FriendData.On_FriendLayer_Index = 0

	MyApp:popTopCloseLayer("FriendLayer")
end

return FriendLayer