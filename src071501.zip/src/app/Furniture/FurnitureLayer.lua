local FZutil = require("app.FZutil")
local FzCheckBoxGroup = require("app.FzWidget.FzCheckBoxGroup")
local ItemNuberLayer = require("app.Furniture.ItemNuberLayer")
local UpgradeLayer = require("app.Furniture.UpgradeLayer")
local SellLayer = require("app.Furniture.SellLayer")

local tipName={
	"goumai",
	"cangku",
	"shoucang",
	"gouwuche"
}

local contentName = {
	"zhuti",
	"diban",
	"zhuoyi",
	"shouyintai",
	"zaotai",
	"qiang",
	"qiangshi",
	"dishi",
	"men"
}

local cellSize = {
	width = 256,
	hight = 457
}

local temeCellSize = {
	width = 389,
	hight = 457
}

local moveTime = 0.5
local maxIndex = 5

local Begin_Top_X = 0
local Begin_Top_Y = 0

local Begin_Down_X = 0
local Begin_Down_Y = 0
local topH = 80
local centerH = 562
local checkBoxH = 99

local shopCarAnimationTime = 0.6
local shopCarAnimationScale = 0.1
local shieldCheckBox = 3    				--屏蔽切页(1:购买;2:仓库;3:收藏,4:购物车)

--日服闪烁提示购买金币、装饰币不足
local japanTitleImgeName={
	"furniture_wordnomoney1",
	"furniture_wordnomoney2",
	"furniture_wordnomoney3"
}

local function getNameStrSub(nameStr)
	local startIndex = string.find(nameStr, "·")
	local nameSubStr = nameStr
	if startIndex then
		nameSubStr = string.sub(nameStr,1,startIndex-1)
	end
	return nameSubStr
end

local function getThemeImg(themeType)
	local filepath = string.format("UI/Icon/theme/%d.png",themeType)
	if IconPath.checkFile(filepath) then
		return filepath
	end
	return ""
end

local function getCellPos(index)
	return cellSize.width*(index-1)+cellSize.width/2,240
end

local function getTemeCellPos(index)
	return temeCellSize.width*(index-1)+temeCellSize.width/2,240
end


local FurnitureLayer = class("FurnitureLayer", FZutil.createUILayer)

--@param _furnitureId int 装饰id
--@param _guideType int 顶部切页(1:购买;2:仓库;3:收藏,4:购物车)
function FurnitureLayer:ctor(_furnitureId,_guideType)
	self:enableNodeEvents()
	self.guideFurnitureId = _furnitureId
	local selectFurnitureType = 1
	if _furnitureId then
		local furncfg = ConfigData.st_res_furniture[_furnitureId]
		selectFurnitureType = furncfg.furniture_type + 1 				--+1  是因为checkbox加了主题
	end
	local furnitureUI = FZutil.createSceneNode("FurnitureUI/furnitureScene")
	self.furnitureUI = furnitureUI
	self:addChild(furnitureUI.root)
	self.NoMoneyTip = FZutil.createMap(furnitureUI.FileNode_moneytip)
	local actPool = cc.Sequence:create(cc.FadeTo:create(0.5, 40),cc.FadeTo:create(0.5, 255))--
	self.NoMoneyTip.root:runAction(cc.RepeatForever:create(actPool))

	TopCurrencyNode:initCurrencyNode(furnitureUI.FileNode_currency,TopCurrencyNode.ADROND)
	CTGuideManage:initGuideOnFurnitureLayer(furnitureUI,self)

	furnitureUI.ScrollView_1:hide()
	local itemScrollView = furnitureUI.ScrollView_2
	itemScrollView:setClippingEnabled(true)
	itemScrollView:removeAllChildren()
	itemScrollView:hide()
	self.itemScrollView = itemScrollView

	local shopCarItemScrollView = furnitureUI.ScrollView_3
	shopCarItemScrollView:setClippingEnabled(true)
	shopCarItemScrollView:setBounceEnabled(true)
	shopCarItemScrollView:removeAllChildren()
	shopCarItemScrollView:hide()
	self.shopCarItemScrollView = shopCarItemScrollView

	local topNode = furnitureUI.Node_top
	Begin_Top_X,Begin_Top_Y = topNode:getPosition()
	topNode:setPositionY(Begin_Top_Y+topH)

	local centerNode = furnitureUI.Node_center
	centerNode:setPosition(0, 0)
	Begin_Down_X,Begin_Down_Y = centerNode:getPosition()
	centerNode:setPositionY(Begin_Down_Y-centerH)

	--购买/仓库/收藏
	self.saveTipIndex = 0
	self.saveContentIndex = 0
	local tipCheckBox = {}
	for i,v in ipairs(tipName) do
		local name = "CheckBox_"..v
		tipCheckBox[i] = furnitureUI[name]
	end
	local tipGroup = FzCheckBoxGroup.new(tipCheckBox)
	tipGroup:initFonts({
		{furnitureUI.Image_goumai2,furnitureUI.Image_goumai1},
		{furnitureUI.Image_cangku2,furnitureUI.Image_cangku1},
		{furnitureUI.Image_shoucang2,furnitureUI.Image_shoucang1},
		{furnitureUI.Image_gouwuche2,furnitureUI.Image_gouwuche1},
	})
	tipGroup:addTo(furnitureUI.root)
	tipGroup:addSubChangeCallback(function(index)
		if shieldCheckBox == index then
			tipCheckBox[index]:setSelected(false)
			if self.saveTipIndex ~= 0 then
				tipCheckBox[self.saveTipIndex]:setSelected(true)
				tipGroup:setSelectFonts(self.saveTipIndex)
				self:updateLeftCheckBox( index )
			end
			MoveMessage.show(Language.not_open)
			return
		end

		if self.saveTipIndex ~= index then
			furnitureUI.ScrollView_1:setVisible(index~=4)
			furnitureUI.ScrollView_2:setVisible(index~=4)
			furnitureUI.ScrollView_3:setVisible(index==4)
			FurnitureData:resetSavePre()
			-- furnitureUI.Button_3:setVisible(tipName[index]=="gouwuche")
			self.saveTipIndex = index
			local contentSelect = selectFurnitureType or 1
			if contentSelect == 1 and index ~= 1 then
				contentSelect = 2
			end
			self.contentGroup:setSelect(contentSelect)
			if selectFurnitureType then
				if selectFurnitureType > 4 then
					local inner = furnitureUI.ScrollView_1:getInnerContainer()
					local innerPosy = inner:getPositionY()
					local guidePosy = innerPosy + (selectFurnitureType-4)*checkBoxH
					if guidePosy > 0 then
						guidePosy = 0
					end
					inner:setPositionY(guidePosy)
				end
				selectFurnitureType = nil
			end
		end
		self:updateLeftCheckBox( index )
	end)
	--底板/收银/桌椅。。。。
	local contentCheckBox = {}
	for i,v in ipairs(contentName) do
		local name = "CheckBox_"..v
		contentCheckBox[i] = furnitureUI[name]
	end
	self.contentCheckBox = contentCheckBox

	local contentGroup = FzCheckBoxGroup.new(contentCheckBox)
	contentGroup:initFonts({
		{furnitureUI.Image_zhuti2,furnitureUI.Image_zhuti1},
		{furnitureUI.Image_diban2,furnitureUI.Image_diban1},
		{furnitureUI.Image_zhuoyi2,furnitureUI.Image_zhuoyi1},
		{furnitureUI.Image_shouyintai2,furnitureUI.Image_shouyintai1},
		{furnitureUI.Image_zaotai2,furnitureUI.Image_zaotai1},
		{furnitureUI.Image_qiang2,furnitureUI.Image_qiang1},
		{furnitureUI.Image_qiangshi2,furnitureUI.Image_qiangshi1},
		{furnitureUI.Image_dishi2,furnitureUI.Image_dishi1},
		{furnitureUI.Image_men2,furnitureUI.Image_men1},
	})
	contentGroup:setUnSelected( 1 )
	self.contentGroup = contentGroup
	contentGroup:addTo(furnitureUI.root)
	contentGroup:addSubChangeCallback(function(index)
		self:contentGroupCallfunc(index)
	end)

	local closeSelf = function(secondClose)
		Alert:show("",Language.furnitureui.close_prop_layer,Alert.TYPE_YES_NO,function(ret)
            if ret then
                CTAdornData:SavePreviewData(false) -- 保存(true) 或 取消(false) 
				FurnitureData:clearShopCarData()
				transition.moveTo(topNode,{x=Begin_Top_X,y=Begin_Top_Y+topH,time=moveTime})
				transition.moveTo(centerNode,{x=Begin_Down_X,y=Begin_Down_Y-centerH,time=moveTime,onComplete=function()
					FzEventCenter:DispichEvent(FzEvent.resumeEventListener)
					FzEventCenter:DispichEvent(FzEvent.closeFurnitureLayer)
					TileMapListener:setTouchListener(false)
					TileMapListener:setTouchListenerOnMain(false)

					if secondClose then
						secondClose(true)
					end
				end})
			else
				if secondClose then
					secondClose(false)
				end
            end
        end)
        return true
	end
	MyApp:pushTopCloseLayer("FurnitureLayer",closeSelf)
	furnitureUI.Button_guanbi:onTouch(function(e)
		if e.name == "ended" then
			closeSelf()
			-- MyApp:popTopCloseLayer()
		end
	end)

	--保存(清空购物车)
	furnitureUI.Button_3:onTouch(function(e)
		if e.name == "ended" then
			Alert:show("",Language.furnitureui.speed_prop_save,Alert.TYPE_YES_NO,function(ret)
				if ret then
					self:SaveBtnCallfunc() -- 保存按钮响应
				end
			end)
		end
	end)

	furnitureUI.Button_down:onTouch(function(e)
		if e.name == "ended" then
			self:enterPreViewState()
		end
	end)

	self.cells = {}			--用于保存cell
	self.shopCarCells = {} 	--用于保存购物车cell
	self.temeCells = {}		--用于保存主题cell

	tipGroup:setSelect(_guideType or 1)
	self:updateTotalCostShow()

	FzEventCenter:DispichEvent(FzEvent.pauseEventListener)

	transition.moveTo(topNode,{x=Begin_Top_X,y=Begin_Top_Y,time=moveTime})
	transition.moveTo(centerNode,{x=Begin_Down_X,y=Begin_Down_Y,time=moveTime})
	

	--隐藏收藏切页
	local moveX = 120
	for _check_index,_check_box in ipairs(tipCheckBox) do
		if _check_index == shieldCheckBox then
			_check_box:hide()
		elseif _check_index > shieldCheckBox then
			local selfPosx = _check_box:getPositionX()
			_check_box:setPositionX(selfPosx-moveX)
		end
	end

	FZutil.displayAdaptation(furnitureUI.Node_center)
end

function FurnitureLayer:contentGroupCallfunc(index)
	self.saveContentIndex = index
	self:hideContentCells(index)
	if tipName[self.saveTipIndex]=="goumai" then 		--商店
		if FurnitureData:isShopData( self.saveTipIndex ) then
			self:updateGouMaiScrollView(self.saveTipIndex,index,true)
		else
			if index==Define.Shop_Type.Adorn_Type then
				NetEngine:sendMessage(game_cmd.CGetShopData,{shop_id=index})
			end
		end
	elseif tipName[self.saveTipIndex]=="cangku" then
		self:updateCangKuScrollView(self.saveTipIndex,index,true)
	elseif tipName[self.saveTipIndex]=="shoucang" then
		self:updateShouCangScrollView(self.saveTipIndex,index,true)
	elseif tipName[self.saveTipIndex]=="gouwuche" then
		self:updateGouWuCheScrollView(self.saveTipIndex,index,true)
	end
end

function FurnitureLayer:updateLeftCheckBox( index )
	local moveSpace = 0
	local isHideFrist = true
	for _i,_check in ipairs(self.contentCheckBox) do
		if _i == 1 then
			if _check:isVisible() then
				if index == 1  then
					break
				else
					_check:hide()
					moveSpace = 107
				end
			else
				if index == 1 then
					_check:show()
					moveSpace = -107
				else
					isHideFrist = false
				end			
			end
		else
			if isHideFrist then
				transition.moveBy(_check, {x=0,y=moveSpace,time=0})
			else
				break
			end
		end
	end
end

function FurnitureLayer:SaveBtnCallfunc() -- 保存按钮响应  可以用在装扮界面保存了
	--0:可以购买  1:可以购买  2:金币不足  3:粉钻不足  4:装饰币不足  5:等级不够 6:通过粉钻可以购买  7:玩家等级不够
	local saveRet,pinkDiaNums = FurnitureData:isClearShopCar()

	local saveCallback = function(ret)
		CTGuideManage:CheckSaveGuide(ret)
		if ret==0 or ret==1 then
			local ShopMsg,Seed_Msg_Data = CTAdornData:SavePreviewData(true) -- 保存(true) 或 取消(false)
			if not ShopMsg and not Seed_Msg_Data then
				return
			end
			local isNull = true
			for _prod_type,_data in pairs(FurnitureData.shopCarData) do
			  	isNull = false
			  	break
			end  
			if isNull==false or ShopMsg or Seed_Msg_Data then
				self.Seed_Msg_Data = Seed_Msg_Data
				local shopMsg = FurnitureData:updateShopCarData( ShopMsg )
				self.ShopMsg = shopMsg
				self:clearGouWuChe()
			else
				MoveMessage.show(Language.furnitureui.not_save_furniture)
			end
		elseif ret == 5 then
			MoveMessage.show(Language.furnitureui.not_level)
		elseif ret == 7 then
			MoveMessage.show(Language.not_enough_playlevel)
		else
			FastSkipHelper.skipLB(Language.furnitureui.not_prop_skip[ret],DyPersent.LB_PINK)
		end
	end

	if saveRet == 6 then
		local msgStr = Language.furnitureui.furniture_coin_pink_diamond
		if pinkDiaNums then
			msgStr = string.format("%s"..Language.informationui.consume_diamond_change_name.."。",msgStr,pinkDiaNums)
		end 
		Alert:show("",msgStr, Alert.TYPE_YES_NO,function(res)
			if res then
				saveCallback(0)
			end
		end)
	else
		saveCallback(saveRet)
	end
	
end
--总消费
function FurnitureLayer:updateTotalCostShow()
	local sumJinbi,sumZhuangShibi,sumFenZuan = FurnitureData:totalCost()
	self.furnitureUI.Image_moneybg:getChildByName("Text_1"):setString(sumJinbi)
	self.furnitureUI.Image_moneybg:getChildByName("Text_pink"):setString(sumFenZuan)
	self.furnitureUI.Image_moneybg:getChildByName("Text_blue"):setString(sumZhuangShibi)
    -- local titleMsg = ""
    -- local japanImgName = nil
    local titleIndex = 0
    if RoleData.player_info.gold<sumJinbi then
        -- titleMsg = Language.not_enough_gold
        -- japanImgName = "furniture_wordnomoney1"
        titleIndex = 1
    end
    if RoleData.player_info.adorn_coin<sumZhuangShibi then
    	-- titleMsg = Language.not_enough_furniture_coin
    	-- japanImgName = japanImgName.."furniture_wordnomoney2"
    	if titleIndex == 0 then
    		titleIndex = 2
    	else
    		titleIndex = 3
    	end
    end

    local japanImgName = japanTitleImgeName[titleIndex]
    self:japanUpdateTitle(japanImgName)
    self.NoMoneyTip.root:setVisible(japanImgName~=nil)
end

function FurnitureLayer:hideContentCells(content_type)
	if content_type == 1 then
		for i,_cell in ipairs(self.cells) do
			if _cell.root:isVisible() == false then 		--用于判断是否是已经隐藏状态
				break
			end
			_cell.root:hide()
		end
	else
		for i,_cell in ipairs(self.temeCells) do
			if _cell.root:isVisible() == false then 		--用于判断是否是已经隐藏状态
				break
			end
			_cell.root:hide()
		end
	end
end

--购买商店
function FurnitureLayer:updateGouMaiScrollView(tipType,contentType,isLeft)
	if contentType == 1 then  --主题
		if not self.fristThemeType or isLeft then
			self:setTemeCells(tipType,contentType,isLeft)
		else
			local shopData = FurnitureData:getSortCommodityDataFromThemeType(tipType,self.fristThemeType)
			self:updateItemScrollView(tipType,shopData,isLeft)
		end
	else
		local shopData = FurnitureData:getSortCommodityDataFromType(tipType,contentType-1)
		self:updateItemScrollView(tipType,shopData,isLeft)
	end
	
end

--主题
function FurnitureLayer:setTemeCells(tipType,contentType,isLeft)
	local temeData = FurnitureData:getTemeFurnitureData()

	local scrollView = self.itemScrollView
	local scrollContentSize = scrollView:getContentSize()
	local scrollInnerContainertWidth = 0

	local cellCount = table.maxn(temeData)
	local index = 1
	for k,_cellData in pairs(temeData) do
		local cellMap = self.temeCells[index]
		if cellMap then
			cellMap.root:show()
		else
			cellMap = FZutil.createCellNode("FurnitureUI/Node_furnituretheme")
			self:setTemeCellData(cellMap,_cellData,tipType,isLeft)
			local posX,posY = getTemeCellPos(index)
			cellMap.root:setPosition(posX,posY)
			scrollView:addChild(cellMap.root)
			table.insert(self.temeCells, cellMap)
		end
		scrollInnerContainertWidth = scrollInnerContainertWidth+temeCellSize.width
		index = index + 1
	end
	-- for i=1,cellCount do
	-- 	local _cellData = temeData[i]
	-- 	local cellMap = self.temeCells[i]
	-- 	if cellMap then
	-- 		cellMap.root:show()
	-- 	else
	-- 		cellMap = FZutil.createCellNode("FurnitureUI/Node_furnituretheme")
	-- 		self:setTemeCellData(cellMap,_cellData,tipType,isLeft)
	-- 		local posX,posY = getTemeCellPos(i)
	-- 		cellMap.root:setPosition(posX,posY)
	-- 		scrollView:addChild(cellMap.root)
	-- 		table.insert(self.temeCells, cellMap)
	-- 	end
		
	-- 	scrollInnerContainertWidth = scrollInnerContainertWidth+temeCellSize.width
	-- end
	
	local cellsLen = table.maxn(self.temeCells)
	while cellCount<cellsLen do
		self.temeCells[cellCount+1].root:hide()
		cellCount = cellCount+1
	end

	scrollView:setInnerContainerSize(cc.size(scrollInnerContainertWidth, scrollContentSize.height))

	if isLeft then
		scrollView:jumpToLeft()
	end

end

function FurnitureLayer:setTemeCellData(temeCell,temeData,tipType,isLeft)
	local fristTemeData = temeData[1]						--读取主题数据的第一条作为信息

	local nameStr = getNameStrSub(fristTemeData.furniture_name)
	temeCell.Text_name:setString(nameStr)
	temeCell.Image_bg:loadTexture(getThemeImg(fristTemeData.theme_type))

	temeCell.Image_bg:setTouchEnabled(true)
	temeCell.Image_bg:onTouch(function(e)
		if e.name == "ended" then
			for _i,_cell in ipairs(self.temeCells) do
				_cell.root:hide()
			end

			local fristThemeType = fristTemeData.theme_type
			self.fristThemeType = fristThemeType
			local shopData = FurnitureData:getSortCommodityDataFromThemeType(tipType,fristTemeData.theme_type)
			self:updateItemScrollView(tipType,shopData,isLeft)
		end
	end)
end

--仓库
function FurnitureLayer:updateCangKuScrollView(tipType,contentType,isLeft)
	local bagData = {}
	local res = CTAdornData:getSortAdornData( contentType-1 )
	for _propId,_data in pairs(res) do
		for __level,___data in pairs(_data) do
			local nums = table.nums(___data)
			if nums>0 then
				local furniturecfg = ConfigData.st_res_furniture[_propId]
				local tempData = clone(furniturecfg)
				tempData.number = nums
				tempData.level = ___data[1].level
				table.insert(bagData,tempData)				
			end
		end
	end
	table.sort(bagData,function(bag1,bag2)
		if bag1.furniture_id==bag2.furniture_id then
			return bag1.level<bag2.level
		end
		return bag1.furniture_id<bag2.furniture_id
	end)
	self:updateItemScrollView(tipType,bagData,isLeft)
end

--收藏
function FurnitureLayer:updateShouCangScrollView(tipType,contentType,isLeft)
	local furniture_Type = FurnitureData.furnitureType[contentName[contentType-1]]
	local cangKuData = FurnitureData.cangKu[contentType]
	self:updateItemScrollView(tipType,cangKuData or {},isLeft)
end

--购物车
function FurnitureLayer:updateGouWuCheScrollView( tipType,contentType ,isLeft)
	local shopCarData = FurnitureData:getSortShopCarDataFromType()
	self:updateItemScrollView(tipType,shopCarData,isLeft)
end

function FurnitureLayer:updateItemScrollView(tipType,furnitureData,isLeft)
	local scrollView = nil
	local cells = {}
	if tipType == 4 then
		scrollView = self.shopCarItemScrollView
		cells = self.shopCarCells
	else
		scrollView = self.itemScrollView
		cells = self.cells
	end
	local scrollContentSize = scrollView:getContentSize()
	local scrollInnerContainertWidth = 0

	local guideIndex = 0
	local cellCount = table.maxn(furnitureData)
	for i=1,cellCount do
		local isGuide = false
		local _cellData = furnitureData[i]
		local cellMap = cells[i]
		if cellMap then
			cellMap.root:show()
			isGuide = self:makeItemCell(tipType,_cellData,cellMap)
		else
			isGuide,cellMap = self:makeItemCell(tipType,_cellData,cellMap)
			cellMap.root:retain()
			local posX,posY = getCellPos(i)
			cellMap.root:setPosition(posX,posY)
			scrollView:addChild(cellMap.root)
			table.insert(cells, cellMap)
		end
		if isGuide then
			guideIndex = i
			self.guideIndex = i
		end
		scrollInnerContainertWidth = scrollInnerContainertWidth+cellSize.width
	end
	
	local cellsLen = table.maxn(cells)
	while cellCount<cellsLen do
		cells[cellCount+1].root:hide()
		cellCount = cellCount+1
	end

	scrollView:setInnerContainerSize(cc.size(scrollInnerContainertWidth, scrollContentSize.height))

	if isLeft then
		scrollView:jumpToLeft()
	end
	
	if guideIndex~=0 then
		local inner = scrollView:getInnerContainer()
		local guidePosx = guideIndex * cellSize.width
		if guidePosx > scrollContentSize.width then
			guidePosx = -(guidePosx - scrollContentSize.width)
		else
			guidePosx = 0
		end
		inner:setPositionX(guidePosx)
		self.guideFurnitureId = nil
	end
end

function FurnitureLayer:makeItemCell(tip_Type,cell_Data,cell_Map)
	local isGuide = false
	if not cell_Map then
		cell_Map = FZutil.createCellNode("FurnitureUI/Node_item")
	end
	self.preCellMap = nil
	local item_Data = {}
	local shopData = nil
	
	if tipName[tip_Type]=="goumai" or tipName[tip_Type]=="gouwuche"then
		shopData = ConfigData.st_shop[1][cell_Data.goods_id]
		local furnitureId = shopData["item_id"]
		item_Data = ConfigData.st_res_furniture[furnitureId]
		self:shopItemCell(cell_Map,shopData,shopData.res_level)
	else
		item_Data = cell_Data
	end

	cell_Map.Image_quality:loadTexture(IconPath.getQualityImage(item_Data.furniture_quality))

	local level = item_Data.level or item_Data.start_level or 1
	cell_Map.Text_name:setString(item_Data.furniture_name)
	local guigeText = item_Data.furniture_wide .. "x" .. item_Data.furniture_long
	cell_Map.Text_guige:setString(guigeText)
	cell_Map.Image_zhezhao:hide()

	local furnitureLevelCfg = ConfigData.st_res_furniture_level[item_Data.furniture_id]
	assert(furnitureLevelCfg,"st_res_furniture_level have not "..item_Data.furniture_id)
		
	if item_Data.furniture_id == self.guideFurnitureId then
		isGuide = true
	end

	local furniture_level_cfg = furnitureLevelCfg[level]
	local shuxingImage = cell_Map["Image_shuxing"..1]

	--属性/辐射
	for i=1,3 do
		local attribute = furniture_level_cfg["attribute"..i]
		local shuxingImage = cell_Map["Image_shuxing"..i]
		local atlasJia = cell_Map["AtlasLabel_jia"..i]
		local atlasJian = cell_Map["AtlasLabel_jian"..i]
		local fanweiText = cell_Map["Text_fanwei"..i]
		shuxingImage:setVisible(attribute~=0)
		atlasJia:setVisible(attribute~=0)
		atlasJian:setVisible(attribute~=0)
		cell_Map["Image_fanwei"..i]:setVisible(attribute~=0)
		fanweiText:setVisible(attribute~=0)
		if attribute ~= 0 then
			shuxingImage:loadTexture(IconPath.getFurnitureSX(attribute))
			local attr_value = furniture_level_cfg["attribute"..i.."_value"]
			local upImage = shuxingImage:getChildByName("Image_up")

			local itemDesc = Language.furnitureui.attribute_desc[attribute]
			if attribute > 10 then
				itemDesc = string.format(itemDesc,math.abs(attr_value))
			else
				local operatorDesc = Language.furnitureui.attribute_desc.add
				if attr_value<0 then
					operatorDesc = Language.furnitureui.attribute_desc.minus
				end
				itemDesc = string.format(itemDesc,operatorDesc,math.abs(attr_value))
			end

			atlasJia:setVisible(attr_value>=0)
			atlasJian:setVisible(attr_value<0)
			atlasJia:setString("/"..math.abs(attr_value))
			atlasJian:setString("."..math.abs(attr_value))
			local fanweiV = furniture_level_cfg["attribute"..i.."_range"]
			fanweiText:setString(fanweiV)
			local fanweiDesc = Language.furnitureui.attribute_desc.fanwei_zero
			if fanweiV > 0 then
				fanweiDesc = string.format(Language.furnitureui.attribute_desc.fanwei_greater_zero,fanweiV)
			end

			TipNodeHelper:registItemTip(shuxingImage,{tipType = Define.Reward_Type.RW_ADORN,desc=itemDesc})
			TipNodeHelper:registItemTip(cell_Map["Image_fanwei"..i],{tipType = Define.Reward_Type.RW_ADORN,desc=fanweiDesc})
		end
	end

	cell_Map.Image_lvbg:setVisible(tipName[tip_Type]=="goumai")
	cell_Map.Button_buy:setVisible(tipName[tip_Type]=="goumai")
	cell_Map.Button_lvlup:setVisible(tipName[tip_Type]=="cangku")
	cell_Map.Button_buyNum:setVisible(tipName[tip_Type]=="gouwuche" or tipName[tip_Type]=="cangku")
	
	local buyNums = 0
	if tipName[tip_Type]=="gouwuche" or tipName[tip_Type]=="cangku" then
		buyNums = cell_Data.number or 1
		cell_Map.Text_buyNum:setString(buyNums)
	end


	local furnitureImage = cell_Map.Image_furniture
	local pathStr = IconPath.getDecorationItem(furniture_level_cfg.pic_id)
	furnitureImage:loadTexture(pathStr)
	local isEnabled = false
	if (tipName[tip_Type]=="goumai" or tipName[tip_Type]=="cangku") then
		isEnabled = true
	end
	furnitureImage:setTouchEnabled(true)
	--选择预览
	local function LookCallfunc()
		if tipName[tip_Type]=="goumai" then
			self.preCellMap = cell_Map
			if RoleData.player_info.level < shopData.player_level then
				MoveMessage.show(string.format(Language.playlevel_less_than, shopData.player_level))
			elseif RoleData.player_info.ct_level<shopData.res_level then
			 	MoveMessage.show(string.format(Language.furnitureui.not_reach_level_preview, shopData.res_level))
			else
				if shopData and cell_Data.buy_num >= shopData.times then
					MoveMessage.show(Language.furnitureui.max_buy_times)
				else
					local _type = item_Data.furniture_type
					local item_id = item_Data.furniture_id
					local bagId,bagLevel = CTAdornData:getMaxRemoveBagId( _type,item_id )
					if not bagId then
						local _shopData = cell_Data
						_shopData.config_id = item_Data.furniture_id
						FurnitureData:addShopCarData( _shopData )
						self:updateTotalCostShow()
						FurnitureData:setSavePre(_type,item_id,item_Data.start_level)
					else
						FurnitureData:setSavePre(_type,item_id,bagLevel,bagId)
					end
					
					self:enterPreViewState()
					-- 预览装饰添加到地图上
					print("预览装饰添加到地图上")
					FzEventCenter:DispichEvent(FzEvent.AddPreviewNode)
				end
			end 
		elseif tipName[tip_Type]=="cangku" then
			self.preCellMap = cell_Map
			local _tyep = item_Data.furniture_type
			local item_id = item_Data.furniture_id
			local _id = CTAdornData:getRemoveBagId(_tyep,item_id,level)
			FurnitureData:setSavePre(_tyep,item_id,level,_id)
			self:enterPreViewState()
			-- 预览装饰添加到地图上
			print("预览装饰添加到地图上")
			FzEventCenter:DispichEvent(FzEvent.AddPreviewNode)
		end
	end
	cell_Map.TouchLookFunc = LookCallfunc
	furnitureImage:onTouch(function( e )
		if e.name == "ended" then
			LookCallfunc()
		end
	end)

	local function TouchBuyFunc()
		if shopData then
			if cell_Data.buy_num >= shopData.times then
				MoveMessage.show(Language.furnitureui.max_buy_times)
			elseif RoleData.player_info.level < shopData.player_level then
				MoveMessage.show(string.format(Language.playlevel_less_than, shopData.player_level))
			elseif RoleData.player_info.ct_level<shopData.res_level then
				MoveMessage.show(Language.furnitureui.not_ct_level,shopData.res_level)
			else
				local have_num = CTAdornData:getAdornNumForType(item_Data.furniture_id,item_Data.furniture_type)
				local shopCarNums = FurnitureData:getShopCarNumber(cell_Data)
				if item_Data.max_num <= have_num+shopCarNums then
        			Alert:show("",Language.adorn.maxn_nums_adorn..item_Data.max_num)
        			return
    			end
    			local imag_posx,imag_posy = furnitureImage:getPosition()
    			local imag_word_pos = furnitureImage:getParent():convertToWorldSpace({x=imag_posx,y=imag_posy})
    			self:addShopCarAnimation(furniture_level_cfg.pic_id,imag_word_pos)
				FurnitureData:addShopCarData( cell_Data )
				self:updateTotalCostShow()
			end				
		end
	end
	cell_Map.TouchBuyFunc = TouchBuyFunc
	cell_Map.Button_buy:onTouch(function(e)
		if e.name == "ended" then
			TouchBuyFunc()
		end
	end)

	--升级
	cell_Map.Button_lvlup:onTouch(function(e)
		if e.name == "ended" then
			-- self:cellLevelUpEvent(cell_Data,cell_Map)
			self:sellFurniture(cell_Data)
		end
	end)

	--删除购物车数量
	local isSellout = tipName[tip_Type]=="gouwuche" and true or false
	cell_Map.Button_sellout:setVisible(isSellout)
	cell_Map.Button_sellout:onTouch(function(e)
		if e.name == "ended" then
			local _shopData = cell_Data
			_shopData.config_id = item_Data.furniture_id
			local itelLayer = ItemNuberLayer.new(_shopData)
			itelLayer:setPosition(display.center)
			self:addChild(itelLayer)
		end
	end)

	return isGuide,cell_Map
end

--购买装饰加入购物车的动画
function FurnitureLayer:addShopCarAnimation(imag_id,imag_pos)
	local gouwuchePosx,gouwuchePosy = self.furnitureUI.Image_4:getPosition()
	local imag_to_pos = self.furnitureUI.Image_moneybg:convertToWorldSpace({x=gouwuchePosx,y=gouwuchePosy})
	local pathStr = IconPath.getDecorationItem(imag_id)
	local imgAni = ccui.ImageView:create()
	imgAni:loadTexture(pathStr)
	imgAni:setPosition(imag_pos.x,imag_pos.y)
	self:addChild(imgAni)
	transition.moveTo(imgAni, {x=imag_to_pos.x,y=imag_to_pos.y,time=shopCarAnimationTime})
	transition.scaleTo(imgAni, {scale=shopCarAnimationScale,time=shopCarAnimationTime,onComplete=function()
		imgAni:removeSelf()
	end})
end

function FurnitureLayer:clearGouWuChe()
	local clearData = FurnitureData:getClearShopCarData()
	self.clearData = clearData
	self:sendGouWuMessage()
end

--发送购买协议
function FurnitureLayer:sendGouWuMessage()
	local msgData = {}
	local clearData = FurnitureData.shopCarData or {}
	
	for _index,_item_data in pairs(self.clearData) do
		local itemNums = _item_data.number
		local itemData = _item_data[1]
		while itemNums>0 do
			table.insert(msgData,{
				shop_id = 1,
				index = itemData.index,
				buy_num = 1,
			})
			itemNums = itemNums-1
		end
	end
	for _type,_type_data in pairs(self.ShopMsg) do
		for _index,_item_data in pairs(_type_data) do
			table.insert(msgData,{
				shop_id = 1,
				index = _item_data.index,
				buy_num = 1,
				m = _item_data.m,
				n = _item_data.n,
				direction = _item_data.direction,
				state = _item_data.state
			})
			FurnitureData.shopCarData[_type][_item_data.config_id].number = FurnitureData.shopCarData[_type][_item_data.config_id].number+1
		end
	end

	if #msgData>0 then
		if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	        SDKCenter:setUserInfo( "", "", 21)
	    end
		NetEngine:sendMessage(game_cmd.CShopping,{buy_items=msgData})
	else
		self:BuySuccess()
	end
end
function FurnitureLayer:BuySuccess()
	if self.Seed_Msg_Data and table.nums(self.Seed_Msg_Data)>0 then
		NetEngine:sendMessage(game_cmd.CSetAdorns,{ cell_adorn_datas = self.Seed_Msg_Data })
		self.Seed_Msg_Data = nil
	else
		CTAdornData:CleanLocalData() -- 保存成功后清理 临时表
	end
end

function FurnitureLayer:shopItemCell(cell_Map,cell_Data,start_level)
	cell_Map.Text_lvbg:setString("限制 "..start_level)
	if RoleData.player_info.ct_level<start_level then
		cell_Map.Text_lvbg:enableOutline(cc.c4b(255, 0, 0,255),1)
	else
		cell_Map.Text_lvbg:enableOutline(cc.c4b(179, 82, 24,255),1)
	end
	
	cell_Map.Button_buy:getChildByName("Image_gold"):loadTexture(IconPath.getPropIcon(cell_Data.price_type))
	cell_Map.Button_buy:getChildByName("Text_num"):setString(cell_Data.price)
end

function FurnitureLayer:sellFurniture(cell_Data)
	local sellLayer = SellLayer.new({
		type = cell_Data.furniture_type,
		itemId = cell_Data.furniture_id,
		level = cell_Data.level,
		maxNums = cell_Data.number
	})
	self:addChild(sellLayer)
end

--刷新回调
function FurnitureLayer:updateTipContent()
	if self then
		local isShow = self:isVisible()
		if isShow then
			if tipName[self.saveTipIndex] == "goumai" then
				self:updateGouMaiScrollView(self.saveTipIndex,self.saveContentIndex)
				self:updateTotalCostShow()
			elseif tipName[self.saveTipIndex] == "cangku" then
				self:updateCangKuScrollView(self.saveTipIndex,self.saveContentIndex)
			elseif tipName[self.saveTipIndex] == "shoucang" then
				self:updateShouCangScrollView(self.saveTipIndex,self.saveContentIndex)
			elseif tipName[self.saveTipIndex] == "gouwuche" then
				self:updateGouWuCheScrollView(self.saveTipIndex,self.saveContentIndex)
				self:updateTotalCostShow()
			end
		else
			self:updateTotalCostShow()
		end
	end
end

function FurnitureLayer:enterPreViewState()
	self.furnitureUI.Node_top:stopAllActions()
	self.furnitureUI.Node_center:stopAllActions()
	transition.moveTo(self.furnitureUI.Node_top,{x=Begin_Top_X,y=Begin_Top_Y+80,time=moveTime})
	transition.moveTo(self.furnitureUI.Node_center,{x=Begin_Down_X,y=Begin_Down_Y-650,time=moveTime,onComplete=function()
		FzEventCenter:DispichEvent(FzEvent.showPreViewLayer,{1,2,3})
		self:hide()
		FzEventCenter:DispichEvent(FzEvent.OpenDressUpLayerForFurniture)
	end})
end
function FurnitureLayer:exitPreViewState()
	self:show()
	self.furnitureUI.Node_top:stopAllActions()
	self.furnitureUI.Node_center:stopAllActions()
	transition.moveTo(self.furnitureUI.Node_top,{x=Begin_Top_X,y=Begin_Top_Y,time=moveTime})
	transition.moveTo(self.furnitureUI.Node_center,{x=Begin_Down_X,y=Begin_Down_Y,time=moveTime})
end

function FurnitureLayer:shopBuySuccess()
	if self then
		self:BuySuccess()
		self.clearData = {}
		FurnitureData:clearShopCarData()
		self:updateTipContent()
	end
end

function FurnitureLayer:saleAdornUpdateUI(_clearBagData)
	if self then
		CTAdornData:saleClearBagData(_clearBagData.type,_clearBagData.id,_clearBagData.level,_clearBagData.onlyIds)
		self:updateTipContent()
	end
end
function FurnitureLayer:CheckGuide()
	return self.cells[self.guideIndex] -- cell_Map.Image_furniture
end
function FurnitureLayer:getGuideNeed(_type)
	if _type == 1 then
		return self.cells[1]
	end
end
---------------------------------Japan-------------------------------------------

function FurnitureLayer:japanUpdateTitle(img_name)
	if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
    	if img_name then
    		local filepath = string.format("UI/japanUI/word/%s.png",img_name) 
    		if IconPath.checkFile(filepath) then
    			self.NoMoneyTip.Image_1_0:loadTexture(filepath)
    		end
    	end
    end
end

--------------------------------------------------------------------------------

function FurnitureLayer:onEnter()
	FzEventCenter:RegisterEvent(FzEvent.shopBuySuccess,self,self.shopBuySuccess)
	FzEventCenter:RegisterEvent(FzEvent.updateTipContent,self,self.updateTipContent)
	FzEventCenter:RegisterEvent(FzEvent.SaveBtnCallfunc,self,self.SaveBtnCallfunc)
	FzEventCenter:RegisterEvent(FzEvent.updateGouMaiScrollView,self,self.updateGouMaiScrollView)
   	TileMapListener:setTouchListener(true) -- 设置装饰可以移动
    TileMapListener:setTouchListenerOnMain(true)
    TileMapListener:setTouchOneByOne(true)
    TileMapListener:resumeEventListener()
	FzSound.ChangeMusic(FzSound.music.bgm_furniture)
	FzSound.clearMapScaleSound(2)
	if CTTileData.CircleNode then
		CTTileData.CircleNode:Clean()
	end
	if CTTileData.CirclePerson then
		CTTileData.CirclePerson:Clean()
	end
	if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        SDKCenter:setUserInfo( "", "", 35)
    end
end

function FurnitureLayer:onExit()
	FzEventCenter:RemoveEvent(FzEvent.shopBuySuccess,self)
	FzEventCenter:RemoveEvent(FzEvent.updateTipContent,self)
	FzEventCenter:RemoveEvent(FzEvent.SaveBtnCallfunc,self)
	FzEventCenter:RemoveEvent(FzEvent.updateGouMaiScrollView,self)
    TileMapListener:pauseEventListener()
	FzSound.clearMapScaleSound(1)
	FzEventCenter:DispichEvent(FzEvent.setMainMissionVisible,true) -- 显示主界面任务cell

	MyApp:popTopCloseLayer("FurnitureLayer")
end

return FurnitureLayer
