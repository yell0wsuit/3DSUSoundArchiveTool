local UpgradeLayer = require("app.Furniture.UpgradeLayer")
local CTPropNode = require("app.CTAdorn.CTPropNode")
local CTWallNode = require("app.CTAdorn.CTWallNode")
local CTWallProp = require("app.CTAdorn.CTWallProp")
local CTFloorNode = require("app.CTAdorn.CTFloorNode")
local CTChangeCircle=class("CTChangeCircle",function ()
    return cc.Node:create()
end)
function CTChangeCircle:ctor(TileMapUI)
    self:enableNodeEvents()
    self.TileMapUI = TileMapUI
    local layerCircle = FZutil.createUILayer()
    layerCircle:setContentSize(display.width*8,display.height*8)
    layerCircle:setBackGroundColorOpacity(math.floor(0*0xff))
    layerCircle:setPosition(-display.cx*3, -display.cy*3)
    
    self:addChild(layerCircle,1)
    local uimap = FZutil.createSceneNode("MainUI/Node_preview")
    self:addChild(uimap.root,2)
    self.uimap = uimap
    self.AdornNode = nil
    local MoveButton  = uimap.Button_move           -- 确认放置
    local AttriButton = uimap.Button_attribute      -- 一键铺满按钮
    local UplevelButton = uimap.Button_uplvl        -- 升级按钮
    local ChangeButton = uimap.Button_turn          -- 转向按钮
    local RemoveButton = uimap.Button_cancel        -- 移除按钮
    local SureButton = uimap.Button_sure            -- 复制按钮
    local CheckBox_brush = uimap.CheckBox_brush     -- 地板刷 和 墙纸刷
    local Circle_Image = uimap.Image_1
    Circle_Image:setTouchEnabled(true)
    Circle_Image:setSwallowTouches(false)
    ----------------------------------------------------
    Circle_Image:onTouch(function(e)
        if e.name=="began" then
            self.hideLayer = true
        elseif e.name=="moved" then
            self:hide()
        elseif e.name == "cancelled" or e.name == "ended" then
            self.hideLayer = false
            print("=============hideLayer:false")
            self:show()
            ----------------------------刷新 地板 上带红色格子可以放置的装饰 -----------------------------------
            local type_id = self.AdornNode.type_id --  CTAdornData.Brush_ON_OFF and
            if TileMapListener.Touch_Key and self.AdornNode and (type_id == 1 or type_id == 2 or type_id == 3 or type_id == 4 or type_id == 7) then
                local Updata_Z_key = false
                for k,item in pairs(CTTileData.Prop_info) do
                    local key = item.node:CheckOnBrushIndex()
                    if key then
                        Updata_Z_key = true
                    end
                end
                if Updata_Z_key then
                    CTTileData:RefreshAllZorder() -- 刷新地饰Z值
                end
            end
            ----------------------------板刷开启时 最后一个不可放置 则移除它-------------------------------------
            if TileMapListener.Touch_Key and CTAdornData.Brush_ON_OFF and self.AdornNode and self.AdornNode.outMapState and (type_id == 1 or type_id == 5) then
                if self.AdornNode.only_id==nil then
                    local item_type = ConfigData.st_res_furniture[self.AdornNode.prop_id]["furniture_type"]
                    FurnitureData:removeShopCarData(item_type,self.AdornNode.prop_id) 
                end
                self.AdornNode:removeProp() -- 将自己的装饰放回仓库
                self.AdornNode = nil
                self:Clean()
                FzEventCenter:DispichEvent(FzEvent.UpdataDressUpLayer)
                FzEventCenter:DispichEvent(FzEvent.UpdataThemeUIView)
            else
                self:setCirclePos()
            end
        end
    end)
    layerCircle:onTouch(function(e)
        if e.name=="began" and not self.hideLayer then
            print("layerCircle ended ")
            if TileMapListener:getTouchListenerOnMain() then -- 为了防止 在主界面打开圆圈界面 而 改变 TileMapListener:setTouchListener()里面的值
                TileMapListener:setTouchListener(true)
            end
            uimap.root:show()
            self.upgradeui:hide()
            self:DisposeLastAdornNode()
            self:Clean()
            audio.playSound(FzSound.sounds.sound_putdown,false)
        end
    end)
    ---------------------------------------------------
    ChangeButton:setSwallowTouches(true)             -- 转向按钮
    ChangeButton:onTouch(function(e)
        if e.name=="ended" and self.AdornNode and self:CheckOnNotAdorn() then
            self.AdornNode:changeMyFix()
            self:setCirclePos()
            audio.playSound(FzSound.sounds.sound_turn,false)
        end
    end)
    RemoveButton:setSwallowTouches(true)             -- 移除按钮
    RemoveButton:onTouch(function(e)
        if e.name=="ended" then
            self:TouchForRemove()
        end
    end)
    SureButton:setSwallowTouches(true)              -- 复制按钮
    SureButton:onTouch(function(e)
        if e.name == "ended" and self:CheckOnNotAdorn() then
            local outMapState = self.AdornNode.outMapState
            if outMapState then
                MoveMessage.show(Language.adorn.put_true_position)
                return 
            end
            self:AddOnLastAdorn()
            audio.playSound(FzSound.sounds.sound_copy,false)
            FzEventCenter:DispichEvent(FzEvent.UpdataDressUpLayer)
        end
    end)
    
    UplevelButton:setSwallowTouches(true)           -- 升级按钮
    UplevelButton:onTouch(function(e)     
        if e.name == "ended" then
            self:TouchForUpLevel()
        end
    end)
    AttriButton:onTouch(function(e)                 -- 一键铺满
        if e.name == "ended" and self:CheckOnNotAdorn() then
            self:TouchOneForAll()
        end
    end)
    MoveButton:onTouch(function(e)                  -- 确认放置
        if e.name == "ended" then
            print("Touch MoveButton End~")
            if TileMapListener:getTouchListenerOnMain() then -- 为了防止 在主界面打开圆圈界面 而 改变 TileMapListener:setTouchListener()里面的值
                TileMapListener:setTouchListener(true)
            end
            uimap.root:show()
            self.upgradeui:hide()
            self:DisposeLastAdornNode()
            self:Clean()
            audio.playSound(FzSound.sounds.sound_putdown,false)
        end
    end)
    CheckBox_brush:setSelected(CTAdornData.Brush_ON_OFF)
    CheckBox_brush:onEvent(function(event)          -- 地板刷 和 墙纸刷
        if event.name == "selected" then
            print("选中！")
            CTAdornData.Brush_ON_OFF = true
        elseif event.name == "unselected" then
            print("取消选中！")
            CTAdornData.Brush_ON_OFF = nil
        end
    end) 

    self.ChangeButton  = ChangeButton
    self.RemoveButton  = RemoveButton
    self.SureButton    = SureButton
    self.UplevelButton = UplevelButton
    self.AttriButton   = AttriButton
    self.MoveButton    = MoveButton
    self.CheckBox_brush= CheckBox_brush

    -------------------------------------------------升级界面-----------------------------------
    local upgradeui = UpgradeLayer.new()
    self:addChild(upgradeui,3)
    self.upgradeui = upgradeui
    upgradeui:hide()
end
function CTChangeCircle:getButtonUI(index)
    if index and index == 3 then
        return self.ChangeButton
    elseif index and index == 4 then
        return self.RemoveButton
    end
    if index == 1 then
        return self.AttriButton
    else
        return self.UplevelButton
    end
end
function CTChangeCircle:TouchOneForAll()
    if not self.AdornNode then
        self:Clean()
        return
    end
    local prop_id = self.AdornNode.prop_id
    local prop_type = self.AdornNode.type_id
    local level = self.AdornNode.level
    if prop_type == 1 then -- 地板
        CTTileData:OneForAllTitle(prop_id,level,self.AdornNode)
    elseif prop_type == 5 then
        CTWallData:OneForAllWall(prop_id,level,self.AdornNode)
    else
        Alert:show("",Language.adorn.only_floor_wall..prop_id.." type_id:"..prop_type.." level:"..level)
    end
    self:DisposeLastAdornNode()
    self:Clean()
    FzEventCenter:DispichEvent(FzEvent.UpdataDressUpLayer)
    FzEventCenter:DispichEvent(FzEvent.UpdataThemeUIView)
    local filepath="res/cocos/TX/TX_overspread/TX_overspread.ExportJson"
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(filepath)
    local TX_node=ccs.Armature:create("TX_overspread")
    TX_node:setPosition(display.center)
    local Animate_Tx = TX_node:getAnimation()
    Animate_Tx:play("TX_overspread")
    display.getRunningScene():addChild(TX_node)
    local function AnimationEvent(armature,movementType,movementID) 
        local id = movementID 
        if movementType == ccs.MovementEventType.loopComplete then 
            if id == "TX_overspread" then 
                TX_node:removeSelf()
                TX_node = nil
            end 
        end 
    end 
    Animate_Tx:setMovementEventCallFunc(AnimationEvent)
    audio.playSound(FzSound.sounds.sound_full,false)
end
function CTChangeCircle:TouchForUpLevel()
    if self and self.AdornNode and self.AdornNode.only_id then
        if TileMapListener:getTouchListenerOnMain() then -- 为了防止 在主界面打开圆圈界面 而 改变 TileMapListener:setTouchListener()里面的值
            TileMapListener:setTouchListener(false)
        end
        self.uimap.root:hide()
        self.upgradeui:HideTx()
        self.upgradeui:show()
        local pos = self:convertToNodeSpace({x=display.cx,y=display.cy})
        self.upgradeui:setPosition(pos.x,pos.y)
        self:updateUpgradeUI()
    else
        MoveMessage.show(Language.adorn.not_have_adorn)
    end
end
function CTChangeCircle:TouchForRemove()
    if not (self.AdornNode and self:CheckOnNotAdorn()) then
        return
    end
    if self.AdornNode.only_id==nil then
        print("self.AdornNode.prop_id : "..self.AdornNode.prop_id)
        local item_type = ConfigData.st_res_furniture[self.AdornNode.prop_id]["furniture_type"]
        FurnitureData:removeShopCarData(item_type,self.AdornNode.prop_id) 
    end
    self.AdornNode:removeProp() -- 将自己的装饰放回仓库
    self.AdornNode = nil
    self:Clean()
    FzEventCenter:DispichEvent(FzEvent.UpdataDressUpLayer)
    FzEventCenter:DispichEvent(FzEvent.UpdataThemeUIView)
    audio.playSound(FzSound.sounds.sound_delete_adorn,false)
end
function CTChangeCircle:Clean()
    if self.upgradeui:isVisible() then
        self.upgradeui:hide()
        if TileMapListener:getTouchListenerOnMain() then -- 为了防止 在主界面打开圆圈界面 而 改变 TileMapListener:setTouchListener()里面的值
            TileMapListener:setTouchListener(true)
        end
    end
    self:hide()
    if self.AdornNode then
        local prop_id = self.AdornNode.prop_id
        local prop_type = ConfigData.st_res_furniture[prop_id].furniture_type
        if prop_type <= 8 then
            self.AdornNode:hideJudgeLayer()
        end
    end
    self.AdornNode = nil
    TileMapListener:CleanTouchNode()
end
function CTChangeCircle:DisposeLastAdornNode()  -- 处理上一个摆放不规则的 装饰物（现只用于可以转向的装饰物）
    if self.AdornNode and tolua.isnull(self.AdornNode) then
        assert(false,"发现一个丢失在二次元的装饰物品~~")
        self.AdornNode = nil
        return
    end
    if self.AdornNode then
        local prop_id = self.AdornNode.prop_id
        local prop_type = ConfigData.st_res_furniture[prop_id].furniture_type
        if prop_type == 2 or prop_type == 3 or prop_type == 4 or prop_type == 7 then
            -- 桌椅 收银 灶台 装饰物（地饰）
            -- if self.AdornNode.outMapState then
            --     print("上个装饰 处于 不可放置状态~")
            --     self.AdornNode:restoreMyFix()   -- 设置为上一个可以放置的位置
            -- end
            -- self.AdornNode:hideJudgeLayer()     -- 上一个不可放置的装饰 可能是不同的方向的不同资源 需要再次隐藏
            -------------------------------------------------
            if not self.AdornNode.outMapState then
                self.AdornNode:hideJudgeLayer()     -- 这里是装饰可放置隐藏（弃用移动后不可放置还原上个位置）
            end
            -------------------------------------------------
        elseif prop_type <=8 then
            -- self.AdornNode:hideJudgeLayer()
            if not self.AdornNode.outMapState then
                self.AdornNode:hideJudgeLayer()     -- 这里是装饰可放置隐藏（弃用移动后不可放置还原上个位置）
            end
        end
    end
    self.AdornNode = nil
end
function CTChangeCircle:SetAdornCircle(node) -- 给选中的装饰添加 圆圈界面
    if node and tolua.isnull(node) then
        assert(false,"给二次元的装饰物品添加 Circle 界面~~")
        node = nil
        return
    end
    self.uimap.root:show()
    self.ChangeButton:show()
    self.RemoveButton:show()
    self.SureButton:show()
    self.MoveButton:show()
    self.AttriButton:hide() -- 一键铺满 墙纸和地板
    self.CheckBox_brush:hide() -- 板刷 墙纸和地板
    if not TileMapListener:getTouchListenerOnMain() then
        self.AttriButton:setBright(false)
        self.ChangeButton:setBright(false)
        self.RemoveButton:setBright(false)
        self.SureButton:setBright(false)
    else
        self.AttriButton:setBright(true)
        self.ChangeButton:setBright(true)
        self.RemoveButton:setBright(true)
        self.SureButton:setBright(true)
    end
    if not node then return end
    self.Tile_width,self.Tile_height = CTTileData.TileSize.width,CTTileData.TileSize.height
    self.AdornNode = node
    self:show()
    self:setCirclePos()
end
function CTChangeCircle:setCirclePos()
    local node = self.AdornNode
    if not node then
        return
    end
    local x,y = node:getPosition()
    self:setPosition(node:getPosition())
    local prop_id = node.prop_id
    local st_info = ConfigData.st_res_furniture[prop_id]
    local prop_type = st_info.furniture_type
    local fixsss = node.fix or 1
    local idss = node.only_id or 1
    local mmm,nnn = node.Origin_Point.m, node.Origin_Point.n or -1,-1
    print(mmm,nnn)
    print("SetAdornCircle  prop_id:"..prop_id.." id:"..idss.." prop_type:"..prop_type.." level:"..node.level.." fix:"..fixsss.." Z_Order:"..node:getLocalZOrder())
    if prop_type == 2 or prop_type == 3 or prop_type == 4 or prop_type == 7 then -- 桌椅 收银 灶台 装饰物（地饰）
        local size = node.Prop_Size 
        local Tile_M, Tile_N = size.m,size.n
        local width = CTTileData.TileSize.width
        local height = CTTileData.TileSize.height
        local pos_x,pos_y = 0,0
        if Tile_M == Tile_N then
            pos_y =  Tile_M *height
        else
            local Max_tile = math.max(Tile_M, Tile_N)
            local Min_tile = math.min(Tile_M, Tile_N)
            pos_x = (Tile_M - Tile_N)*width/2
            pos_y = Min_tile*height + (Max_tile - Min_tile)*height/2 
        end
        self:setPosition(x+pos_x/2,y-pos_y/2) 
    elseif prop_type == 8 then -- 门
        self.ChangeButton:hide()
        self.SureButton:hide()
        local width = CTTileData.TileSize.width
        local height = CTTileData.TileSize.height
        local x,y = node:getPosition()
        self:setPosition(x+width/3,y+2*height)
    elseif prop_type == 5 then -- 壁纸
        self.ChangeButton:hide()
        self:setPosition(x + node.BoxSize.width/2,y + node.BoxSize.height/2)
        self.AttriButton:show()
        self.CheckBox_brush:setSelected(CTAdornData.Brush_ON_OFF)
        self.CheckBox_brush:show()
    elseif prop_type == 6 then -- 窗 灯 画（壁饰）
        self.ChangeButton:hide()
    elseif prop_type == 1 then -- 地板
        local width = CTTileData.TileSize.width
        local height = CTTileData.TileSize.height
        local x,y = node:getPosition()
        self:setPosition(x+width/2,y+height/2)
        self.ChangeButton:hide()
        self.AttriButton:show()
        self.CheckBox_brush:setSelected(CTAdornData.Brush_ON_OFF)
        self.CheckBox_brush:show()
    end
    if not node.only_id then
        self.UplevelButton:hide()
    else
        self.UplevelButton:show()
    end
    node:showJudgeLayer()
end

function CTChangeCircle:updateUpgradeUI()
    if self and self.upgradeui then
        local isShow = self.upgradeui:isVisible()
        if isShow then
            local upgradeData = {furnit_id = self.AdornNode.prop_id, level = self.AdornNode.level,only_id = self.AdornNode.only_id}
            self.upgradeui:setScale(1/MainMapListener:getMapScale())
            self.upgradeui:updateUpgradeUI(upgradeData)
        end
    end
end
function CTChangeCircle:AddOnLastAdorn() -- 点击勾后出现一个 一模一样的装饰
    local AdornNode = self.AdornNode
    local level = AdornNode.level
    local only_id = AdornNode.only_id
    local prop_id = AdornNode.prop_id
    local fix = AdornNode.fix or 1
    local Origin_Point = AdornNode.Origin_Point
    local st_info = ConfigData.st_res_furniture[prop_id]
    local start_level = st_info.start_level
    local prop_type = st_info.furniture_type
    -- local id = CTAdornData:getRemoveBagId( prop_type,prop_id,level )
    local id, adorn_level = CTAdornData:getBagAdornData(prop_type,prop_id) -- 返回的是动态id
    if not id then --  and level==start_level
        local have_num = CTAdornData:getAdornNumForType(prop_id,prop_type)
        if st_info.max_num <= have_num then
            Alert:show("",st_info.furniture_name..Language.adorn.maxn_nums..st_info.max_num)
            return
        end
        local shop_Data = FurnitureData:getShopDataFromFurniture(1, prop_type, prop_id)
        if not shop_Data then
            assert(false,"什么鬼商店里都找不到的东西！！！prop_id "..prop_id.." prop_type:"..prop_type)
        end
        adorn_level = start_level
        shop_Data.m,shop_Data.n,shop_Data.direction,shop_Data.state = m,n,fix,1
        FurnitureData:addShopCarData( shop_Data )
        FzEventCenter:DispichEvent(FzEvent.UpdataDressUpLayer)
    end
    --------------------------------------------
    self:DisposeLastAdornNode()
    self:Clean()
    --------------------------------------------
    local Local_Data = {
        id = id,
        config_id = prop_id,
        level = adorn_level,
        m = Origin_Point.m,
        n = Origin_Point.n,
        direction = fix,
        state = 2
    }
    if prop_type == 2 or prop_type == 3 or prop_type == 4 or prop_type == 7 then -- 桌椅 收银 灶台 装饰物（地饰）
        local prop_node = CTPropNode.new(Local_Data,prop_type)
        self.TileMapUI:addChild(prop_node)
        CTAdornData:AddLocalData(prop_node)
        prop_node:addCircleNode()
    elseif prop_type == 5 then -- 壁纸
        local wall_node = CTWallNode.new(Local_Data,prop_type)
        self.TileMapUI:addChild(wall_node)
        CTAdornData:AddLocalData(wall_node)
        wall_node:addCircleNode()
    elseif prop_type == 6 then -- 窗 灯 画（壁饰）
        local wall_prop = CTWallProp.new(Local_Data,prop_type)
        self.TileMapUI:addChild(wall_prop)
        CTAdornData:AddLocalData(wall_prop)
        wall_prop:addCircleNode()
    elseif prop_type == 1 then -- 地板
        local floor_node = CTFloorNode.new(Local_Data,prop_type)
        self.TileMapUI:addChild(floor_node)
        CTAdornData:AddLocalData(floor_node)
        floor_node:addCircleNode()
    end
end
function CTChangeCircle:CheckOnNotAdorn()
    local key = TileMapListener:getTouchListenerOnMain()
    if not key then
        Alert:show("", Language.adorn.go_to_set, Alert.TYPE_YES_NO, function(tag)
            if tag then
                self:Clean()
                FastSkipHelper:skipView(FastSkipHelper.UI_ID_CHAPTER)
            end
        end)
    end
    return key
end
function CTChangeCircle:getTileMapUI()
    return self.TileMapUI
end
function CTChangeCircle:CheckGuide()
    return self.upgradeui:CheckGuide()
end
function CTChangeCircle:onEnter()
    FzEventCenter:RegisterEvent(FzEvent.updateUpgradeUI ,self,self.updateUpgradeUI)
end

function CTChangeCircle:onExit()
    FzEventCenter:RemoveEvent(FzEvent.updateUpgradeUI,self)
end

return CTChangeCircle