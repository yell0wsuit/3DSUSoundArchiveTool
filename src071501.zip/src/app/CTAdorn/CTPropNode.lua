local FZutil = require("app.FZutil")
local CTPropNode=class("CTPropNode",function ()
	return cc.Node:create()
end)
local Tile_width = 80
local Tile_height = 40
--[[
    id = 3; //动态ID
    required int32 config_id = 5; // 静态ID
    required int32 level = 6; // 等级
    optional int32 m = 8; // 代表格子位置
    optional int32 n = 9;
    optional int32 direction = 4;// 1 0度， 2 旋转90度， 3 旋转180， 4 旋转270度
    optional int32 state = 7; // 1 放置在格子上 2从格子上取下
]]
function CTPropNode:addTextZ()
    if not self:getChildByName("mytxt") then
        local Text_area = ccui.Text:create()
        Text_area:setFontName(FZutil.getFontString())
        Text_area:setFontSize(16)
        Text_area:setName("mytxt")
        Text_area:setColor(cc.c3b(255,0,0))
        self:addChild(Text_area,9)
        self.Text_area = Text_area
    end
end
function CTPropNode:ctor(data,type_id)
    self:setLocalZOrder(555)
    self.type_id = type_id
    self.prop_id = data.config_id
    self.only_id = data.id -- 唯一ID
    self.state = data.state -- 1 在地图 2 不在地图
    self.level = data.level -- 
    self.fs_level = data.level
    -- self:addTextZ()
    ------------------------------------------------------
    Tile_width = CTTileData.TileSize.width
    Tile_height = CTTileData.TileSize.height
    self.outMapState = false -- true 说明所在位置不可放置
    self.OutLayer_Key = 3
    self.on_state = nil
    self:createPopNode(self.prop_id)
    local point = {m = data.m, n = data.n}
    local fix = data.direction
    self:setPropNodeFix(point,fix)
    CTTileData:AddPropNode(self)
    self:getSitDownPos()
    self.OnMapState = {point = self.Origin_Point ,fix = self.fix}
    -- performWithDelay(self,function ()
    --     self:ShowWrapNature()
    -- end,2)
    self:setErrorTip(false)
    -- performWithDelay(self,function ()
    --     if self.size_type == 1 then
    --         local point = self:getSitPosToMap(1)
    --         print("1人桌 桌椅位置 m:"..point.m.." n:"..point.n)
    --     elseif self.size_type == 2 then
    --         for i=1,2 do
    --             local point = self:getSitPosToMap(i)
    --             print("2人桌 桌椅位置 index:"..i.."  m:"..point.m.." n:"..point.n)
    --         end
    --     elseif self.size_type == 4 then
    --         for i=1,4 do
    --             local point = self:getSitPosToMap(i)
    --             print("4人桌 桌椅位置 index:"..i.."  m:"..point.m.." n:"..point.n)
    --         end
    --     elseif self.size_type == 8 then
    --         for i=1,8 do
    --             local point = self:getSitPosToMap(i)
    --             print("8人桌 桌椅位置 index:"..i.."  m:"..point.m.." n:"..point.n)
    --         end
    --     end
    -- end,10)
end
function CTPropNode:createPopNode(prop_id)
    local Node_Fix_Array = CTPropPath.CreateProp(prop_id)
    self.Node_Fix_Array = Node_Fix_Array
    local num = #Node_Fix_Array
    local Fix_Num_Tab = {}
    for i=1,num do
        if i<num then
            table.insert(Fix_Num_Tab,i,i+1)
        else
            table.insert(Fix_Num_Tab,i,1)
        end
    end
    self.Fix_Num_Tab = Fix_Num_Tab
end
function CTPropNode:setPropNodeFix(point,fix)
    if self.uimap then
        self.uimap.root:removeSelf()
        self.uimap = nil
    end
    local PropData = self.Node_Fix_Array[fix]
    if not PropData then
        assert(false," not PropData ")
    end
    self.fix = fix
    self.uimap = FZutil.createSceneNode(PropData.uimapStr)
    self:addChild(self.uimap.root)
    self:initPropListener()              --初始化装饰的触摸响应
    self:initPropRect(point,PropData.OverTurn,PropData.size)
    self:initImagePath(PropData.size)
    if self.only_id then
        CTAdornData:AddLocalData(self)
    end
    -- print("方向 "..fix)
end
function CTPropNode:setNodeState(on_state)
    print("CTPropNode on_state :"..on_state)
    for k,data in pairs(self.Origin_Rect) do
        CTTileData.TileMapData[data.m][data.n].index = on_state
    end
    self:UpdataGirdNature(on_state)
end
function CTPropNode:UpdataGirdNature(on_state,fs_level) -- 刷新格子辐射范围
    local level = fs_level or self.level
    local levelTab = ConfigData.st_res_furniture_level[self.prop_id]
    if not levelTab then
        return
    end
    local maxLevel = levelTab[table.maxn(levelTab)].furniture_lvl
    if level > maxLevel then
        level = maxLevel
    end
    local st_data = levelTab[level]
    local function updataNature(state)
        local factor = 1
        if state == 0 then

            factor = -1
        elseif state == 1 then
            factor = 1
        end
        local Nature_Type1 = st_data.attribute1
        local Nature_Num1 = tonumber(st_data.attribute1_value)*factor
        local FanWei1 = st_data.attribute1_range

        local Nature_Type2 = st_data.attribute2
        local Nature_Num2 = tonumber(st_data.attribute2_value)*factor
        local FanWei2 = st_data.attribute2_range

        local Nature_Type3 = st_data.attribute3
        local Nature_Num3 = tonumber(st_data.attribute3_value)*factor
        local FanWei3 = st_data.attribute3_range
        -- 格子只显示 环境和舒适 属性
        if Nature_Type1==1 or Nature_Type1==2 or Nature_Type2==1 or Nature_Type2==2 or Nature_Type3==1 or Nature_Type3==2 then
            local FanWei_Max = math.max(FanWei1, FanWei2, FanWei3)
            local p_m ,p_n = self.Origin_Point.m, self.Origin_Point.n
            local size_m ,size_n = self.Prop_Size.m ,self.Prop_Size.n
            local op_m = p_m + size_m - 1 -- -1因为size_m包含p_m
            local op_n = p_n + size_n - 1
            local max_m,min_m = op_m+FanWei_Max,p_m-FanWei_Max
            if max_m>CTTileData.Tile_M then
                max_m = CTTileData.Tile_M
            end
            if min_m<1 then
                min_m = 1
            end
            local max_n,min_n = op_n+FanWei_Max,p_n-FanWei_Max
            if max_n>CTTileData.Tile_N then
                max_n = CTTileData.Tile_N
            end
            if min_n<1 then
                min_n = 1
            end
            for m = max_m, min_m , -1 do
                for n = max_n, min_n, -1 do
                    local Nature_Gird = CTTileData.TileMapData[m][n].Nature_Gird
                    local Ss_Txt = Nature_Gird:getChildByName("SS")
                    local Hj_Txt = Nature_Gird:getChildByName("HJ")
                    if m>op_m or m<p_m or n>op_n or n<p_n then -- 辐射位置
                        local fs_num = math.max((m-op_m),(p_m-m),(n-op_n),(p_n-n))
                        if FanWei1~=0 and fs_num <= FanWei1 then
                            if Nature_Type1 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num1
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type1 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num1
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                        if FanWei2~=0 and fs_num <= FanWei2 then
                            if Nature_Type2 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num2
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type2 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num2
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                        if FanWei3~=0 and fs_num <= FanWei3 then
                            if Nature_Type3 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num3
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type3 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num3
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                    else -- 自己的位置
                        if FanWei1 == 0 then
                            if Nature_Type1 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num1
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type1 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num1
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                        if FanWei2 == 0 then
                            if Nature_Type2 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num2
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type2 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num2
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                        if FanWei3 == 0 then
                            if Nature_Type3 == 1 then
                                Nature_Gird.HJ_num = Nature_Gird.HJ_num + Nature_Num3
                                Hj_Txt:setString(Nature_Gird.HJ_num)
                            elseif Nature_Type3 == 2 then
                                Nature_Gird.SS_num = Nature_Gird.SS_num + Nature_Num3
                                Ss_Txt:setString(Nature_Gird.SS_num)
                            end
                        end
                    end 
                end
            end
        end
    end
    if on_state == 0 and self.on_state == 1 then
        -- print("*清空* 所在格子 辐射 范围属性") 
        updataNature(on_state)
    elseif (self.on_state == 0 or not self.on_state) and on_state == 1 then
        -- print("*计算* 所在格子 辐射 范围属性") 
        updataNature(on_state)
    end
    self.on_state = on_state
end
function CTPropNode:ShowWrapNature()
    local Tile_M = CTTileData.Tile_M
    local Tile_N = CTTileData.Tile_N
    for i,point in ipairs(self.Origin_Wrap) do
        local m,n = point.m,point.n
        if not (m<1 or n<1 or m>Tile_M or n>Tile_N) then -- 出界不要
            local z = CTTileData.TileMapData[m][n].z
            local Nature_Gird = CTTileData.TileMapData[m][n].Nature_Gird
            -- Nature_Gird:setLocalZOrder(z)
            Nature_Gird:show()
        end
    end
end
function CTPropNode:getWrapToAbs()
    local SaveWrap = {}
    local Tile_M = CTTileData.Tile_M
    local Tile_N = CTTileData.Tile_N
    local top_m,top_n = self.Origin_Point.m, self.Origin_Point.n
    local size_m,size_n = self.Prop_Size.m,self.Prop_Size.n
    for i,point in ipairs(self.Origin_Wrap) do
        local m,n = point.m,point.n
        if not (m<1 or n<1 or m>Tile_M or n>Tile_N or CTTileData.TileMapData[m][n].index~=0) then -- 出界不要
            if not((m == top_m-1 and n == top_n-1) 
                or (m == top_m+size_m and n == top_n+size_n) 
                or (m == top_m-1 and n == top_n+size_n)
                or (m == top_m+size_m and n == top_n-1))
                then    -- 四个对角点不要
                if self.type_id == 3 then -- 收银台
                    if self.fix == 1 and n == top_n+size_n then  
                        table.insert(SaveWrap, 1, point)
                    elseif self.fix == 2 and m == top_m+size_m then
                        table.insert(SaveWrap, 1, point)
                    elseif self.fix == 3 and n == top_n-1 then
                        table.insert(SaveWrap, 1, point)
                    elseif self.fix == 4 and m == top_m-1 then
                        table.insert(SaveWrap, 1, point)
                    end
                else
                    table.insert(SaveWrap, 1, point)
                end
            end
        end
    end
    return SaveWrap
end
function CTPropNode:getSitPosToMap(index)
    local p_m ,p_n = self.Origin_Point.m, self.Origin_Point.n
    local size_m,size_n = self.Prop_Size.m,self.Prop_Size.n
    local op_m = p_m + size_m - 1 -- -1因为size_m包含p_m
    local op_n = p_n + size_n - 1
    local max, min = math.max(size_m,size_n),math.min(size_m,size_n)
    local Down_Point = {m = op_m, n = op_n}
    -- if self.fix == 1 or self.fix == 3 then
    --     Down_Point = {m = p_m+min-1, n = p_n+max-1}
    -- else
    --     Down_Point = {m = p_m+max-1, n = p_n+min-1}
    -- end
    -- print("顶角坐标 m:"..p_m.." n:"..p_n.." 底角坐标 m:"..Down_Point.m.." n:"..Down_Point.n.."  哈哈 m:"..op_m.." n:"..op_n)
    if self.type_id == 2 then -- 桌椅
        if self.size_type == 1 then
            if self.fix == 1 or self.fix == 2 then
                return self.Origin_Point
            else
                return Down_Point
            end
        elseif self.size_type == 2 then
            if index == 1 then
                return self.Origin_Point
            else
                return Down_Point
            end
        elseif self.size_type == 4 then
            if index < 3 then
                if self.fix == 1 then
                    return {m = self.Origin_Point.m+index-1 ,n = self.Origin_Point.n}
                else
                    return {m = self.Origin_Point.m,n = self.Origin_Point.n+index-1}
                end
            else
                if self.fix == 1 then
                    return {m = Down_Point.m-4+index ,n = Down_Point.n}
                else
                    return {m = Down_Point.m,n = Down_Point.n-4+index }
                end
            end
        elseif self.size_type == 8 then
            if index < 5 then
                if self.fix == 1 then
                    return {m = self.Origin_Point.m+index-1 ,n = self.Origin_Point.n}
                else
                    return {m = self.Origin_Point.m,n = self.Origin_Point.n+index-1}
                end
            else
                if self.fix == 1 then
                    return {m = Down_Point.m-8+index ,n = Down_Point.n}
                else
                    return {m = Down_Point.m,n = Down_Point.n-8+index }
                end
            end
        end
    end
end
function CTPropNode:getSitDownPos()
    local st_info = ConfigData.st_res_furniture[self.prop_id]
    local size_type = st_info.table_num
    if self.type_id == 2 then -- 桌椅
        self.size_type = size_type
        self.SitTab = {}    
        for i=1,size_type do  -- 一人桌 1 2 4 8 桌
            local pos_node = string.format("pos_node%d", i)
            local pos_menu = string.format("pos_menu%d", i)
            local data = {index = 0,nodeUI = self.uimap[pos_node] , menuUI = self.uimap[pos_menu]}
            table.insert(self.SitTab,i,data)
        end
    elseif self.type_id == 4 then -- 炉灶 1 2 3 小中大
        self.size_type = size_type
        self.SitTab = {}    
        self.SitTab.pos_menu = {}
        local menu_num = 1
        if size_type == 1 then
            menu_num = 1
        elseif size_type == 2 then
            menu_num = 4
        elseif size_type == 3 then
            menu_num = 7
        end
        for i=1,menu_num do
            local data = {index = 0 ,menuUI = self.uimap[string.format("pos_menu%d", i)]}
            table.insert(self.SitTab.pos_menu, 1, data)
        end
        self.SitTab.pos_node = {index = 0 ,nodeUI = self.uimap["pos_node"]}
    elseif self.type_id == 3 then -- 收银台 唯一
        self.size_type = size_type
        self.SitTab = {}    
        self.SitTab.pos_node = {index = 0 ,nodeUI = self.uimap["cash_pos"]}
    end
end

function CTPropNode:changeMyFix() -- 改变方向
    local old_fix = self.fix
    local fix = 1
    for i=1, table.nums(self.Fix_Num_Tab) do
        fix = self.Fix_Num_Tab[old_fix]
        local PropData = self.Node_Fix_Array[fix]
        if self:CheckOnPushAdorn(self.Origin_Point,PropData.size) then
            if not self.outMapState then
                self:setNodeState(0)
            end
            self:setPropNodeFix(self.Origin_Point, fix)
            CTTileData:RefreshAllZorder(self)
            break
        end
        old_fix = fix
    end
end
function CTPropNode:restoreMyFix() -- 设置为可放置的位置和方向（转向后不可放置）
    if self.OnMapState then
        self:setNodeState(0)
        self:setPropNodeFix( self.OnMapState.point, self.OnMapState.fix)
        CTTileData:RefreshAllZorder(self) -- 还原后要重新对它排序
    end
end
function CTPropNode:initPropRect(point,OverTurn,size)
    local uimap = self.uimap
    self.Origin_Point = point or self.Origin_Point -- 为什么不放到ChangeNodeRect中赋值，因为初始位置可能出界。。。
    self.Move_Point = point or self.Origin_Point
    self.Origin_Rect = {}
    self.Origin_Wrap = {}
    self.Move_Rect = {}
    self.Move_Wrap = {}
    
    uimap.prop_layer:setScaleX(OverTurn)
    uimap.judge_layer:setScaleX(OverTurn)
    self.OverTurn = OverTurn
    self.Prop_Size = size
    local state , rect , wrap , outMap = self:getRectAndWrap(point,size)
    local topPoint = {x = CTTileData.TileMapData[point.m][point.n].x,y = CTTileData.TileMapData[point.m][point.n].y}
    local x,y = topPoint.x,topPoint.y
    self:setPosition(x+Tile_width/2,y+Tile_height)
    uimap.prop_layer:setPositionY(0)
    if state and not outMap then
        self.Origin_Rect = rect
        self.Origin_Wrap = wrap
        self.Move_Rect = rect
        self.Move_Wrap = wrap
        self:setNodeState(1) -- 另装饰站位
        self.OnMapState = {point = self.Origin_Point ,fix = self.fix}
        self.outMapState = false
        self:hideJudgeLayer()
    else
        self:showJudgeLayer()
        self.outMapState = true
        self:setLocalZOrder(Define.TileMap_Zorde.Adorn_Erroy)
        transition.moveTo(uimap.prop_layer,{y=uimap.prop_layer:getPositionY()+20,time=0.1})
    end
end
function CTPropNode:CheckOnPushAdorn(point,size)
    local Tile_M,Tile_N = CTTileData.Tile_M ,CTTileData.Tile_N
    local p_m ,p_n = point.m, point.n
    local size_m ,size_n = size.m ,size.n
    local op_m = p_m + size_m - 1 -- -1因为size_m包含p_m
    local op_n = p_n + size_n - 1
    if op_m < 1 or op_m > Tile_M or p_m < 1 or p_m > Tile_M
    or op_n < 1 or op_n > Tile_M or p_n < 1 or p_n > Tile_M
    then
        return false
    end
    return true
end
function CTPropNode:CleanLastNature()
    if not self.Nature_Tab then
        self.Nature_Tab = {}
        return
    end
    for i,data in pairs(self.Nature_Tab) do
        local m,n = data.m,data.n
        local Nature_Gird = CTTileData.TileMapData[m][n].Nature_Gird
        local Ss_Txt = Nature_Gird:getChildByName("SS")
        local Hj_Txt = Nature_Gird:getChildByName("HJ")
        Nature_Gird:hide()
        Ss_Txt:hide()
        Hj_Txt:hide()
    end
    self.Nature_Tab = {}
end
function CTPropNode:getRectAndWrap(point,size)
    local uimap = self.uimap
    local state = true
    local outMap = false
    local rect = {}
    local wrap = {}
    local Tile_M,Tile_N = CTTileData.Tile_M ,CTTileData.Tile_N
    local p_m ,p_n = point.m, point.n
    local size_m ,size_n = size.m ,size.n
    local op_m = p_m + size_m - 1 -- -1因为size_m包含p_m
    local op_n = p_n + size_n - 1
    if op_m < 1 or op_m > Tile_M or p_m < 1 or p_m > Tile_M
    or op_n < 1 or op_n > Tile_M or p_n < 1 or p_n > Tile_M
    then
        outMap = true
        return false , rect , wrap , outMap
    end
    self.personTab = {}
    local wrap_index = 1
    self:CleanLastNature()
    for m = op_m+wrap_index, p_m-wrap_index , -1 do
        for n = op_n+wrap_index, p_n-wrap_index, -1 do
            if m>op_m or m<p_m or n>op_n or n<p_n then
                table.insert(wrap,1,{m = m ,n = n})
            else
                local MapData = CTTileData.TileMapData[m][n]
                local index = MapData.index
                local floor_index = MapData.floor_index
                local color_index = 0  
                if index == 1 or floor_index==0 then
                    color_index = 1
                    state = false
                end
                local x_m ,y_n = 0,0
                if self.OverTurn < 0 then -- 表明翻转过
                    x_m ,y_n = n-p_n+1 , m-p_m+1
                else
                    x_m ,y_n = m-p_m+1 , n-p_n+1
                end
                local UIstr = string.format("judge_%d_%d",x_m,y_n)
                local judgeUI = uimap[UIstr]
                judgeUI:loadTexture(CTPropPath.JudgeTile(color_index),0)
                local Text_HJ = judgeUI:getChildByName("Text_hj")
                local Text_SS = judgeUI:getChildByName("Text_ss")
                if Text_HJ and Text_SS then
                    Text_HJ:hide() 
                    Text_SS:hide() -- cocos 的属性文本 暂时没用到
                    if state then
                        local Nature_Gird = MapData.Nature_Gird
                        local Ss_Txt = Nature_Gird:getChildByName("SS")
                        local Hj_Txt = Nature_Gird:getChildByName("HJ")
                        table.insert(self.Nature_Tab,{m = m, n = n})
                        if not CTTileData.Hj_Look_Key and not CTTileData.Ss_Look_Key then
                            Hj_Txt:hide()
                            Ss_Txt:hide()
                            Nature_Gird:hide()
                        elseif CTTileData.Hj_Look_Key and not CTTileData.Ss_Look_Key then
                            Hj_Txt:show()
                            Ss_Txt:hide()
                            Nature_Gird:show()
                        elseif not CTTileData.Hj_Look_Key and CTTileData.Ss_Look_Key then
                            Ss_Txt:show()
                            Hj_Txt:hide()
                            Nature_Gird:show()
                        else
                            Hj_Txt:show()
                            Ss_Txt:show()
                            Nature_Gird:show()
                        end
                    end
                    -- local scalx = 1
                    -- if judgeUI:getParent():getScaleX()<0 then
                    --     scalx = -1
                    -- end
                    -- Text_HJ:setScaleX(scalx)
                    -- Text_SS:setScaleX(scalx)
                    -- Text_HJ:setString(Nature_Gird.HJ_num)
                    -- Text_SS:setString(Nature_Gird.SS_num)
                end
                table.insert(rect,1,{m = m, n = n, x = MapData.x, y = MapData.y})
                -- table.insert(rect,1,{index = index, m = m ,n = n,x = CTTileData.TileMapData[m][n].x, y = CTTileData.TileMapData[m][n].y})
            end 
        end
    end
    return state , rect , wrap , outMap
end
function CTPropNode:ChangeNodeRect(point,TouchEnd)
    if self.on_state and self.on_state ~= 0 then
        self:setNodeState(0)
    end
    local size = self.Prop_Size
    local uimap = self.uimap
    local state , rect , wrap , outMap  = self:getRectAndWrap(point,size)
    uimap.prop_layer:stopAllActions()
    uimap.prop_layer:setPositionY(0)
    if outMap then
        if point.x then
            -- self:setScale(1.2)
            -- self:setPosition(point.x,point.y+50)
        else
            local m,n = point.m,point.n
            local x,y = CTTileData.TileMapData[m][n].x , CTTileData.TileMapData[m][n].y
            self:setPosition(x+Tile_width/2,y+Tile_height)
            self:setLocalZOrder(Define.TileMap_Zorde.Adorn_Erroy)
            transition.moveTo(uimap.prop_layer,{y=uimap.prop_layer:getPositionY()+20,time=0.1})
        end
        self.OutLayer_Key = 1
        self:setScale(1)
        return false -- 出界
    end
    self:setScale(1)
    ---------------------------------------------------------------------------
    self.Move_Point = {m =point.m,n = point.n}
    self.Move_Rect = rect
    self.Move_Wrap = wrap
    local topPoint = rect[1]
    local x,y = topPoint.x,topPoint.y
    self:setPosition(x+Tile_width/2,y+Tile_height)
    if not state then               -- 不可放置
        self:setLocalZOrder(Define.TileMap_Zorde.Adorn_Erroy)
        transition.moveTo(uimap.prop_layer,{y=uimap.prop_layer:getPositionY()+20,time=0.1})
        self.OutLayer_Key = 1  
    else                            -- 可放置
        self.OutLayer_Key = 0       
    end
end
function CTPropNode:initPropListener()
    local uimap = self.uimap
    for k,propUI in pairs(uimap.judge_layer:getChildren()) do
        self:setPropTouch(propUI)
    end
end
function CTPropNode:setPropTouch(judgeImage)
    local touch_judge = judgeImage
    touch_judge:setTouchEnabled(true)
    touch_judge:onTouch(function(e)
        touch_judge:setSwallowTouches(false) -- 此吞噬 主界面时移动地图需要
        if not TileMapListener.Touch_Key then return end
        if e.name=="began" then
            -- print("CTPropNode Began")
        elseif e.name=="ended" then
            TileMapListener:addNodeTouch(self,self.type_id)
            print("ended 显示转向的界面 CTPropNode"..self.prop_id)
        end
    end,true)
end
function CTPropNode:addCircleNode()
    TileMapListener:addNodeTouch(self,self.type_id)
end
function CTPropNode:hideJudgeLayer()
    if not self.judgeVis and not self.outMapState then
        local uimap = self.uimap
        for k,judgeUI in pairs(uimap.judge_layer:getChildren()) do
            judgeUI:setOpacity(0)
        end
        self.judgeVis = true
    end
end
function CTPropNode:showJudgeLayer()
    if self.judgeVis then
        local uimap = self.uimap
        for k,judgeUI in pairs(uimap.judge_layer:getChildren()) do
            if self.outMapState then
                judgeUI:loadTexture(CTPropPath.JudgeTile(1),0)
            else
                judgeUI:loadTexture(CTPropPath.JudgeTile(0),0)
            end
            judgeUI:setOpacity(255)
        end
        self.judgeVis = false
    end
end
function CTPropNode:CheckOnBrushIndex()
    -- print("哈哈 "..self.OutLayer_Key)
    if self.outMapState and (self.OutLayer_Key == 3 or self.OutLayer_Key == 1) then
        self:ChangeNodeRect(self.Origin_Point)
        if self.OutLayer_Key == 0 then
            -- print("呵呵呵 "..self.OutLayer_Key)
            self.outMapState = false
            self:setNodeState(1)
            self:hideJudgeLayer()
            self.OutLayer_Key = 3
            return true
        end
    end
end
function CTPropNode:CheckOnFloorIndex(key)
    local uimap = self.uimap
    if not key then
        for k,data in pairs(self.Origin_Rect) do
            local floor_index = CTTileData.TileMapData[data.m][data.n].floor_index
            if floor_index == 0 then
                self.outMapState = true
                self:showJudgeLayer()
                uimap.prop_layer:setPositionY(0)
                transition.moveTo(uimap.prop_layer,{y=uimap.prop_layer:getPositionY()+20,time=0.1})
                self:setNodeState(0)
                return
            end
        end
    else
        for k,data in pairs(self.Origin_Rect) do
            local floor_index = CTTileData.TileMapData[data.m][data.n].floor_index
            if floor_index == 0 then
                self.outMapState = true
                self:showJudgeLayer()
                uimap.prop_layer:setPositionY(0)
                transition.moveTo(uimap.prop_layer,{y=uimap.prop_layer:getPositionY()+20,time=0.1})
                return
            end
        end
        self.outMapState = false
        self:hideJudgeLayer()
        uimap.prop_layer:setPositionY(0)
        self:setNodeState(1)
    end
end
function CTPropNode:removeProp(key)        -- 移除装饰
    self:CleanLastNature()
    CTAdornData:RemoveLocalData(self)
    if not key then
        CTTileData:removePropData(self)
    end
    if not self.outMapState then -- 说明在地图可放置区域
        self:setNodeState(0)
    end
    self:removeSelf()
    self = nil
    CTTileData.CircleNode:hide()
end
-----------在监听后由CTTileData.TouchProp执行------------
function CTPropNode:OutMapPos(p_m,p_n)
    local Tile_M,Tile_N = CTTileData.Tile_M ,CTTileData.Tile_N
    local size = self.Prop_Size
    local size_m ,size_n = size.m ,size.n
    local op_m = p_m + size_m - 1 -- -1因为size_m包含p_m
    local op_n = p_n + size_n - 1
    if p_m<1 then
        p_m = 1
    end
    if op_m>Tile_M then
        p_m = Tile_M - size_m + 1
    end
    if p_n<1 then
        p_n = 1
    end
    if op_n>Tile_N then
        p_n = Tile_N - size_n + 1
    end
    return p_m,p_n
end
function CTPropNode:MoveTouchEvent(move_point)
    local cm,cn = move_point.m,move_point.n
    local m,n = self:OutMapPos(self.Origin_Point.m+cm,self.Origin_Point.n+cn)
    local c_point = {m = m , n = n ,x = move_point.x, y = move_point.y}
    if self.Move_Point and self.Move_Point.m == c_point.m and self.Move_Point.n == c_point.n then
        return true
    end
    if self.only_id then
        CTAdornData:AddLocalData(self)
    end
    self:ChangeNodeRect(c_point)    
    self:setErrorTip(false)
end
function CTPropNode:EndTouchEvent()
    -- print(" end event :"..self.OutLayer_Key)
    if self.OutLayer_Key == 1 then      -- 不可放置（触摸移动后）
        -- self:ChangeNodeRect(self.Origin_Point,"end")
        -- if self.on_state then
        --     self:setNodeState(1)
        -- end
        -- self.Move_Point = self.Origin_Point
        -- self.Move_Rect = self.Origin_Rect
        -- self.Move_Wrap = self.Origin_Wrap
        self.outMapState = true
        self.Origin_Point = self.Move_Point
        self.Origin_Rect = self.Move_Rect
        self.Origin_Wrap = self.Move_Wrap
        -- if not self.Z_Order then
            self.Z_Order = Define.TileMap_Zorde.Adorn_Erroy
        -- end
        self:setLocalZOrder(self.Z_Order)
        print("不可放置···Z:"..self.Z_Order)
        self.OutLayer_Key = 3
    elseif self.OutLayer_Key == 0 then  -- 最终放置
        self.outMapState = false
        self.Origin_Point = self.Move_Point
        self.Origin_Rect = self.Move_Rect
        self.Origin_Wrap = self.Move_Wrap
        self.OnMapState = {point = self.Origin_Point ,fix = self.fix}
        self:setNodeState(1)
        self.OutLayer_Key = 3
        CTTileData:RefreshAllZorder(self)
        print("可放置···Z:"..self.Z_Order)
    end
end
------------------------------------------替换图片资源------------------------------------------
function CTPropNode:initImagePath(size)
    local id = self.prop_id
    local level = self.level
    local fix = self.fix
    local uimap = self.uimap
    local st_info = ConfigData.st_res_furniture[id]
    local size_type = st_info.table_num
    if self.fs_level ~= level and not self.outMapState then -- 升级后 刷新属性格子
        self:UpdataGirdNature(0,self.fs_level)
        self:UpdataGirdNature(1)
        self.fs_level = level
    end
    self:CheckAdornUpLevel()
    if self.type_id == 2 then -- 桌椅
        local pathTab = CTPropPath.TableProp(id,level)
        if not pathTab then
            print("桌子资源没找到 prop_id:"..id.." fix:"..fix.." level:"..level)
            return
        end
        local Has_Hand_key = #pathTab>4
        if size_type == 1 then
            if fix<3 then
                -- self:NewloadTexture(uimap.Image_table,pathTab[1])
                uimap.Image_table:loadTexture(pathTab[1])
                self:NewloadTexture(uimap.Image_chair1_1,pathTab[4])
                if Has_Hand_key then
                    self:NewloadTexture(uimap.Image_chair1_2,pathTab[5])
                    uimap.Image_chair1_2:show() -- 椅子扶手
                else
                    uimap.Image_chair1_2:hide() -- 椅子扶手
                end
            else
                -- self:NewloadTexture(uimap.Image_table,pathTab[1])
                uimap.Image_table:loadTexture(pathTab[1])
                self:NewloadTexture(uimap.Image_chair1_1,pathTab[2])
                self:NewloadTexture(uimap.Image_chair1_2,pathTab[3])
            end
        elseif size_type == 2 then
            if Has_Hand_key then
                self:NewloadTexture(uimap.Image_chair1_2,pathTab[5])
                uimap.Image_chair1_2:show() -- 椅子扶手
            else
                uimap.Image_chair1_2:hide() -- 椅子扶手
            end
            -- self:NewloadTexture(uimap.Image_table,pathTab[1])
            uimap.Image_table:loadTexture(pathTab[1])
            self:NewloadTexture(uimap.Image_chair1_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair2_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair2_2,pathTab[3])
        elseif size_type == 4 then
            if Has_Hand_key then
                self:NewloadTexture(uimap.Image_chair1_2,pathTab[5])
                self:NewloadTexture(uimap.Image_chair2_2,pathTab[5])
                uimap.Image_chair1_2:show() -- 椅子扶手
                uimap.Image_chair2_2:show() -- 椅子扶手
            else
                uimap.Image_chair1_2:hide() -- 椅子扶手
                uimap.Image_chair2_2:hide() -- 椅子扶手
            end
            -- self:NewloadTexture(uimap.Image_table,pathTab[1])
            uimap.Image_table:loadTexture(pathTab[1])
            self:NewloadTexture(uimap.Image_chair1_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair2_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair3_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair3_2,pathTab[3])
            self:NewloadTexture(uimap.Image_chair4_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair4_2,pathTab[3])
        elseif size_type == 8 then
            if Has_Hand_key then
                self:NewloadTexture(uimap.Image_chair1_2,pathTab[5])
                self:NewloadTexture(uimap.Image_chair2_2,pathTab[5])
                self:NewloadTexture(uimap.Image_chair3_2,pathTab[5])
                self:NewloadTexture(uimap.Image_chair4_2,pathTab[5])
                uimap.Image_chair1_2:show() -- 椅子扶手
                uimap.Image_chair2_2:show() -- 椅子扶手
                uimap.Image_chair3_2:show() -- 椅子扶手
                uimap.Image_chair4_2:show() -- 椅子扶手
            else
                uimap.Image_chair1_2:hide() -- 椅子扶手
                uimap.Image_chair2_2:hide() -- 椅子扶手
                uimap.Image_chair3_2:hide() -- 椅子扶手
                uimap.Image_chair4_2:hide() -- 椅子扶手
            end
            -- self:NewloadTexture(uimap.Image_table,pathTab[1])
            uimap.Image_table:loadTexture(pathTab[1])
            self:NewloadTexture(uimap.Image_chair1_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair2_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair3_1,pathTab[4])
            self:NewloadTexture(uimap.Image_chair4_1,pathTab[4])
            -- 下排
            self:NewloadTexture(uimap.Image_chair5_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair5_2,pathTab[3])
            self:NewloadTexture(uimap.Image_chair6_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair6_2,pathTab[3])
            self:NewloadTexture(uimap.Image_chair7_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair7_2,pathTab[3])
            self:NewloadTexture(uimap.Image_chair8_1,pathTab[2])
            self:NewloadTexture(uimap.Image_chair8_2,pathTab[3])
        end
    elseif self.type_id == 4 then -- 炉灶 1 2 3 小中大
        local pathTab = CTPropPath.CookProp(id,level)
        if pathTab then
            self:NewloadTexture(uimap.Image_chair1,pathTab[2])
            self:NewloadTexture(uimap.Image_table,pathTab[1])
        end
    elseif self.type_id == 3 then -- 收银台 唯一
        local path = CTPropPath.CashProp(id,level,fix)
        if path then
            self:NewloadTexture(uimap.Image_table,path)
            uimap.Image_table:setScaleX(1)
        else
            assert(false,"没找到对应的收银台图片资源！id:"..id.." level:"..level.." fix"..fix)
        end
    elseif self.type_id == 7 then -- 地饰
        uimap.Image_table:hide()
        local furniturecfg = ConfigData.st_res_furniture_level[id]
        local furniturelevelcfg = furniturecfg[level]
        local need_animation = furniturelevelcfg.if_animation
        -- if id == 1010712 and level>=15 then
        if tonumber(need_animation) == 1 then
            local animation_id= furniturelevelcfg.model_id
            local jsonPath1 = string.format("UI/decoration/flooring/%d/%d.json",animation_id, animation_id) --"UI/decoration/flooring/101071202/101071202.json"
            local atlasPath1 = string.format("UI/decoration/flooring/%d/%d.atlas",animation_id, animation_id) --"UI/decoration/flooring/101071202/101071202.atlas"
            local mode1 = sp.SkeletonAnimation:create(jsonPath1, atlasPath1)
            local x,y = uimap.Image_table:getPosition()
            if id == 1010712 then   -- 金色柯基 喷泉特效
                if fix == 1 or fix == 2 then
                    mode1:setAnimation(0, "zheng", true)
                else
                    mode1:setAnimation(0, "fan", true)
                end
                mode1:setPosition(x,y+132)
            elseif id == 1030711 then -- 水车
                mode1:setAnimation(0, "shuiche", true)
                mode1:setPosition(x,y+114)
            elseif id == 1030712 then -- 梅
                mode1:setAnimation(0, "103071201", true)
                mode1:setPosition(x,y)
            elseif id == 1040711 then -- 杏树
                mode1:setAnimation(0, "zheng", true)
                mode1:setPosition(x,y)
            elseif id == 1040710 then -- 树下老牛
                mode1:setAnimation(0, "zheng", true)
                mode1:setPosition(x,y)
            elseif id == 1050712 then -- 龙舟
                mode1:setAnimation(0, "zheng", true)
                mode1:setPosition(x,y)
            else
                if st_info.direct>2 then
                    if fix == 1 or fix == 2 then
                        mode1:setAnimation(0, "zheng", true)
                    else
                        mode1:setAnimation(0, "fan", true)
                    end
                    mode1:setPosition(x,y)
                else
                    mode1:setAnimation(0, "zheng", true)
                    mode1:setPosition(x,y)
                end
            end
            uimap.prop_layer:addChild(mode1,1)
            return
        end
        local path = CTPropPath.SevenProp(id,level,fix,self.Prop_Size)
        local hehe = self.Prop_Size.m*self.Prop_Size.n
        if hehe == 3 or hehe == 2 then -- 1x3 or 1x2
            for i=1,hehe do
                local ImageUI = uimap[string.format("Image_%d", i)]
                if ImageUI then
                    ImageUI:hide()
                end
            end
        end
        if id == 1010709 then
            print("哈哈哈 花栏 "..path)
            for i=1,2 do
                local ImageUI = uimap[string.format("Image_%d", i)]
                if fix == 2 or fix == 3 then
                    ImageUI:setScaleX(-1)
                else
                    ImageUI:setScaleX(1)
                end
                ImageUI:show()
                self:NewloadTexture(ImageUI,path)
            end
        else
            if self.Prop_Size.m == 1 and self.Prop_Size.n == 1 and st_info.direct ~= 1 and st_info.pic_num == 1 then
                if fix == 1 or fix == 3 then
                    uimap.Image_table:setScaleX(1)
                else
                    uimap.Image_table:setScaleX(-1)
                end
            end
            -- print("是是水水水水Image_table水水 ScaleX:"..uimap.Image_table:getScaleX())
            -- print("是是火火火火prop_layer 水水 ScaleX:"..uimap.prop_layer:getScaleX())
            uimap.Image_table:show()
            self:NewloadTexture(uimap.Image_table,path)
        end
    end
end
function CTPropNode:NewloadTexture(image,path)
    image:ignoreContentAdaptWithSize(true)
    image:loadTexture(path)
end
function CTPropNode:CheckAdornUpLevel(key)
    if self.only_id and self.only_id>0 and self.prop_id then
        local furniturelevelcfg = ConfigData.st_res_furniture_level[self.prop_id]
        local furniturecfg = ConfigData.st_res_furniture[self.prop_id]
        local prop_type = furniturecfg.furniture_type
        local maxLevel = table.maxn(furniturelevelcfg)
        local upgradeLevel = self.level < maxLevel and self.level+1 or maxLevel
        local nextfurniturelevelcfg = furniturelevelcfg[upgradeLevel]
        if nextfurniturelevelcfg.use_lvl<=RoleData.player_info.ct_level then
            if self.level<maxLevel and not key then -- 可升级
                self:setUpLevelTip()
                return true
            elseif self.UpLevel_TipUI then
                self.UpLevel_TipUI.root:hide()
            end
        elseif self.UpLevel_TipUI then
            self.UpLevel_TipUI.root:hide()
        end
    end
end
function CTPropNode:setUpLevelTip()
    if not self.UpLevel_TipUI then
        local UpLevel_TipUI = FZutil.createCellNode("MainUI/Node_leveltip")
        self:addChild(UpLevel_TipUI.root,5)
        self.UpLevel_TipUI = UpLevel_TipUI
    end
    local Tile_M, Tile_N = self.Prop_Size.m,self.Prop_Size.n
    if self.OverTurn<0 then
        Tile_M, Tile_N = self.Prop_Size.n,self.Prop_Size.m
    end
    local width = CTTileData.TileSize.width
    local height = CTTileData.TileSize.height
    local pos_x,pos_y = 0,0
    if Tile_M == Tile_N then
        pos_y =  Tile_M *height
    else
        local Max_tile = math.max(Tile_M, Tile_N)
        local Min_tile = math.min(Tile_M, Tile_N)
        pos_x = (Tile_M - Tile_N)*width/2
        pos_y = Min_tile*height + (Max_tile - Min_tile)*height/2 
    end
    if self.OverTurn<0 then
        pos_x = -pos_x
    end
    self.UpLevel_TipUI.root:setPosition(pos_x/2,pos_y/4)--,
    local UpLevelKey = cc.UserDefault:getInstance():getBoolForKey("UpLevelKey",true) 
    if UpLevelKey and not FriendData.Own_MapAdorn then
        self.UpLevel_TipUI.root:show()
    else
        self.UpLevel_TipUI.root:hide()
    end
    self.UpLevel_TipUI.Image_1:setTouchEnabled(true)
    self.UpLevel_TipUI.Image_1:onTouch(function(e)
        if e.name=="ended" then
            self:addCircleNode()
        end
    end,true)
end
function CTPropNode:setErrorTip(visb)
    if visb then
        if not self.ErrorTip then
            local ErrorTip = CTPropPath.CreateErrorTip() -- 道路被堵提示
            self:addChild(ErrorTip,9)
            local Tile_M, Tile_N = self.Prop_Size.m,self.Prop_Size.n
            if self.OverTurn<0 then
                Tile_M, Tile_N = self.Prop_Size.n,self.Prop_Size.m
            end
            local width = CTTileData.TileSize.width
            local height = CTTileData.TileSize.height
            local pos_x,pos_y = 0,0
            if Tile_M == Tile_N then
                pos_y =  Tile_M *height
            else
                local Max_tile = math.max(Tile_M, Tile_N)
                local Min_tile = math.min(Tile_M, Tile_N)
                pos_x = (Tile_M - Tile_N)*width/2
                pos_y = Min_tile*height + (Max_tile - Min_tile)*height/2 
            end
            if self.OverTurn<0 then
                pos_x = -pos_x
            end
            ErrorTip:setPosition(pos_x/2,pos_y/4)
            ErrorTip:setTouchEnabled(true)
            ErrorTip:onTouch(function(e)
                if e.name=="ended" then
                    self:addCircleNode()
                end
            end)
            self.ErrorTip = ErrorTip
        else
            self.ErrorTip:show()
        end
    elseif self.ErrorTip then
        self.ErrorTip:hide()
    end
end
return CTPropNode