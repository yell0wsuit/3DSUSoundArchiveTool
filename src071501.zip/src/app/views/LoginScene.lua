local info=require("info")
local json=require("cocos.cocos2d.json")
local ServerListLayer=require("app.Login.ServerListLayer")
-- local ChangeNameLayer = require("app.HeadInformation.ChangeNameLayer")
local CreatePlayerLayer = require("app.Login.CreatePlayerLayer")

local LoginScene = class("LoginScene", cc.load("mvc").ViewBase)
local XMLHR_Status_SUCCESS=200

local function setFateImg(img)
    img:ignoreContentAdaptWithSize(true)
    img:setPositionX(-display.width/2+312/2)
end

function LoginScene:onCreate()
    print("///////////*****************///////////////////111111111")
    local jsonPath = "battle/loading/loading.json"
    local atlasPath = "battle/loading/loading.atlas"
    local mode = sp.SkeletonAnimation:create(jsonPath, atlasPath)
    mode:setPosition(display.center)
    mode:setAnimation(0, "loading", true)
    self:addChild(mode,-1)
    
    -- local sssd = IconPath.loadPetBigModle( 6025 )
    -- self:addChild(sssd,99)
    -- performWithDelay(self,function ( )
    --     sssd:removeSelf()
    -- end,3)
    -- -- 日服
    -- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
    --     local jsonPath = "battle/logo/logo.json"
    --     local atlasPath = "battle/logo/logo.atlas"
    --     local mode = sp.SkeletonAnimation:create(jsonPath, atlasPath)
    --     mode:setPosition(display.center)
    --     mode:setAnimation(0, "logo", true)
    --     self:addChild(mode,-1)
    -- end

    print("///////////*****************///////////////////222222222")

    local filepath="res/cocos/TX/TX_startgame/TX_startgame.ExportJson"
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(filepath)
    local mode2=ccs.Armature:create("TX_startgame")
    mode2:setPosition(display.center)
    mode2:getAnimation():play("TX_startgame")
    self:addChild(mode2)
    self.StartTX = mode2
    self.StartTX:hide()

    local healthbg=FZutil.createSceneNode("LoginUIall/LoginUIView_healthbg")
    self:addChild(healthbg.root)
    healthbg.root:setPosition(display.cx,20)
    --------------------------------------------------------

    ConfigData:init()           --读取json
    ModelsManager:init()        --注册消息
    DyDataManager:init()        --初始化一些数据
    -- 继承系统
    if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        healthbg.login_word2:hide()
        self:initJcUI()
    end
    -- local bg=require("app.Login.BackgroundLayer").create()
    -- self:addChild(bg.root,-2)
    self:initVerision()
end
function LoginScene:initVerision()
    local versionBuf=cc.FileUtils:getInstance():getStringFromFile("project.manifest")
    assert(string.len(versionBuf)>0,"project.manifest，读取失败")
    local versionJson=json.decode(versionBuf)
    assert(versionJson,"project.manifest解析失败")
    local version=versionJson.version
    local txt=string.format(Language.Version_str .. version .. "<" .. info.cpp_version .. ">")
    local ver_label=cc.Label:createWithTTF(txt,Define.DEFAULT_FONT,18)
    self:addChild(ver_label)
    -- ver_label:setColor(cc.c3b(255,255,255))
    ver_label:enableOutline(cc.c4b(80,31,12,255),2)
    ver_label:setPosition(display.width-30,20)
    ver_label:setAnchorPoint(1,0)
    FZutil.setAllTextOutLine(ver_label)
end
function LoginScene:onEnterTransitionFinish()
    RoleData.machine_info = tostring(SDKCenter:getDeviceId())
    print("***** 设备唯一码："..RoleData.machine_info)
    if (info.platform==0 or info.platform==100) and (not FZ_COUNTRY or FZ_COUNTRY ~= "Japan") then
        self:initLoginUI()
    elseif (info.platform==600) or (FZ_COUNTRY and FZ_COUNTRY == "Japan") then
        local user_id = cc.UserDefault:getInstance():getStringForKey("user_id")
        if not user_id or string.len(user_id) == 0 then
            print("user_id 为空")
            RoleData.user_id = ""
        else
            print("user_id 已存在:",user_id)
            RoleData.user_id = user_id
        end
        RoleData.pass_code = math.random(1,999)
        RoleData.platform=info.platform
        RoleData.data_md5=cc.FileUtils:getInstance():getStringFromFile("res/data/md5")
        RoleData.fight_md5=cc.FileUtils:getInstance():getStringFromFile("src/fight/md5")
        self:showServerList()
    else
        -- self:initSDKUI()
        self:openSDKLogin()
        self.SDK_Login_key = false
        local touchLayer = FZutil.createUILayer()
        touchLayer:setBackGroundColorOpacity(math.floor(0*0xff))
        self:addChild(touchLayer,1)
        local touch_one_key = true
        touchLayer:onTouch(function(e)
            if e.name=="began" then
                touch_one_key = false
            elseif e.name=="ended" and not touch_one_key and not self.SDK_Login_key then
                touch_one_key = true
                self:openSDKLogin()
            end
        end)
        self.touchLayer = touchLayer
        self.touchLayer:hide()
        performWithDelay(self, function ()
            if not self.SDK_Login_key and self.touchLayer and not tolua.isnull(self.touchLayer) then
                self.touchLayer:show()
            end
        end,1.5)
    end
end

function LoginScene:openSDKLogin()
    SDKCenter:onSDKLogin()
end

-- function LoginScene:initSDKUI()
--     local gameStar=ccui.Button:create()
--     gameStar:loadTextures("UI/LoginUI/LoginUI_button_begin_normal.png","UI/LoginUI/LoginUI_button_begin_press.png")
--     gameStar:setPosition(display.cx,80)
--     gameStar:setTouchEnabled(true)
--     self:addChild(gameStar)
--     gameStar:onTouch(function( e )
--         if e.name=="ended" then 
--             self:openSDKLogin()
--         end
--     end)
--     self.gameStar=gameStar
-- end

function LoginScene:initLoginUI()
    local loginui=FZutil.createSceneNode("LoginUIall/LoginUIView")
    self:addChild(loginui.root)
    loginui.Node_center:setPosition(display.center)
    
    -- setFateImg(loginui.ProjectNode_bg:getChildByName("Image_baseMap_03"))

    local last_account=cc.UserDefault:getInstance():getStringForKey("last_account")
    if last_account and last_account~="" then
        loginui.TextField_accountInput:setString(last_account)
    end
    
    local text_passward=loginui.TextField_passwordInput
    if device.platform=="windows" then
        text_passward:setPasswordEnabled(false)
        text_passward:setString("0")
    end

    local btn=loginui.Button_login
    btn:onTouch(function(event)
        if event.name== "ended" then
            print("touch~~")
            local current_account=loginui.TextField_accountInput:getString()
            if string.len(current_account)==0 then
                Alert:show("",Language.roleui.please_input_name)
            else
                cc.UserDefault:getInstance():setStringForKey("last_account",current_account)
                RoleData.user_id=current_account
                if device.platform=="windows" then
                    RoleData.platform=tonumber(text_passward:getString()) or 0
                elseif SDKCenter.platform~=0 then  --应用宝平台有玩家选
                    RoleData.platform=SDKCenter.platform
                else
                    RoleData.platform=info.platform
                end
                RoleData.data_md5=cc.FileUtils:getInstance():getStringFromFile("res/data/md5")
                RoleData.fight_md5=cc.FileUtils:getInstance():getStringFromFile("src/fight/md5")
                loginui.root:hide()
                self:showServerList()
            end
        end
    end)
end

function LoginScene:onLoginSuccess()
    ServerTime.reset()
    -- if (OpenConfig.guide and use_guide) then
    --     if not DyTollgate:hasWinFirstNewPlayerTollgate() then
    --         DyTollgate.current_tollgate_id=DyTollgate:getFirstNewPlayerTollgateId()
    --         DyStory:initNewPlayerBattleData(Define.NEWPLAYER_TOLLGATE_01_KEY)
    --         FzEventCenter:DispichEvent(FzEvent.BattleStart)
    --     elseif not DyTollgate:hasWinChapter(Define.NEWPLAYER_CHAPTER_ID) then
    --         self:getApp():enterScene("TollgateScene")
    --     else
    --         self:getApp():enterScene("HomeScene")
    --     end
    -- else
        if DEBUG>=3 then
            assert(NetEngine:checkWaitingCount(),"wait_count not 0",NetEngine:getWatingCmdMapString())
        end
        self:getApp():enterScene("HomeScene")
    -- end
end

function LoginScene:onSDKLoginSuccess()
    self.SDK_Login_key = true
    if self.touchLayer then
        self.touchLayer:hide()
    end
    local orgin_info=require(FzFileUtils.getOriginInfoPath())
    local xhr = cc.XMLHttpRequest:new() -- http请求  
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON -- 响应类型  
    xhr:open("GET", orgin_info.login_server) -- 打开链接  

    -- 状态改变时调用  
    local function onReadyStateChange()  
        -- 显示状态文本  
        local statusString = "Http Status Code:"..xhr.statusText 
        release_print(statusString)
        if xhr.status==XMLHR_Status_SUCCESS then    --成功
            release_print(xhr.response) 
            local ret=json.decode(xhr.response)
            if ret and ret.ip and ret.port then 
                RoleData.login_info=ret
                if self and self.connectLoginServer then 
                    self:connectLoginServer(ret)
                end
            else
                Alert:show("",Language.loginui.server_info_miss)
            end
        else
            Alert:show("",Language.loginui.login_info_err)
        end
    end  

    -- 注册脚本回调方法  
    xhr:registerScriptHandler(onReadyStateChange)  
    xhr:send() -- 发送请求 
end

function LoginScene:connectLoginServer(server_info)
    local NetImpl=require("packages.net.NetImpl")
    local loginNet=NetImpl.new()
    loginNet:registerFailedCallback(function()
        loginNet._waitinglayer:hide()
       Alert:show("",Language.loginui.login_server_connect_err)
    end)
    loginNet:registerConnectedCallback(function()
        loginNet._waitinglayer:hide()
        local msg={}
        msg.user_id=SDKCenter.userItem.user_id
        msg.pf_key=SDKCenter.accessToken
        msg.platform=info.platform
        if info.platform==SDKCenter.platform_enum.efun and device.platform=="android" then
            msg.ext1="fate"
        elseif info.platform==SDKCenter.platform_enum.baidu then 
            msg.ext1="V3_6"
        elseif info.platform==SDKCenter.platform_enum.uc then    
            msg.ext1="v128"
        elseif info.platform==SDKCenter.platform_enum.QQ or info.platform==SDKCenter.platform_enum.WX then 
            msg.ext1=""
            msg.ext2="ysdk"
            msg.platform=SDKCenter.platform
        elseif info.platform==SDKCenter.platform_enum.yijie and device.platform=="android" then
            msg.ext1 = SDKCenter.ChannelInfo.sub_channel
        else
            if SDKCenter.ext1 and SDKCenter.ext1 ~= "" then
                msg.ext1 = SDKCenter.ext1
            end

            if SDKCenter.ext2 and SDKCenter.ext2 ~= "" then
                msg.ext2 = SDKCenter.ext2
            end
        end
        loginNet:sendMessage(game_cmd.CVerify,msg)
    end)
    loginNet:registerCallback(game_cmd.SVerify,function(msg)
       if msg.ret==error_message.SUCCESS then
            RoleData.user_id=msg.user_id
            RoleData.pass_code=msg.pass_code
            RoleData.ext=msg.ext
            if SDKCenter.platform==0 then 
                RoleData.platform=info.platform
            else
                RoleData.platform=SDKCenter.platform
            end
            RoleData.data_md5=cc.FileUtils:getInstance():getStringFromFile("res/data/md5")
            RoleData.fight_md5=cc.FileUtils:getInstance():getStringFromFile("src/fight/md5")
            if self and self.showServerList then 
                self:showServerList()
            end
            self:checkCppVersion()
        else
            Alert:show(Language.loginui.login_fail_title,Language.loginui.login_check_fail)
       end
       loginNet:close() --主动断开登录服务器的socket
    end)
    
    loginNet._waitinglayer:show(WaitingLayer.TYPE_CONNECT_ING)
    loginNet:connect(server_info.ip,server_info.port)
end

function LoginScene:onCreatePlayer() -- 创建角色回调
    if RoleData.is_server_full then 
        Alert:show("",Language.loginui.server_full)
    else
        -- local changeNameLayer = ChangeNameLayer.new(true) -- 不要激活码
        -- self:addChild(changeNameLayer)
        if self and not self:getChildByName("createLayer") then
            local createLayer = CreatePlayerLayer.new() -- 要激活码
            createLayer:setName("createLayer")
            self:addChild(createLayer,999)
        end
    end
end

function LoginScene:onEnter()
    FzEventCenter:RegisterEvent(FzEvent.LoginSuccess,self,self.onLoginSuccess)
    FzEventCenter:RegisterEvent(FzEvent.CreatePlayer,self,self.onCreatePlayer)
    FzEventCenter:RegisterEvent(FzEvent.SDKLoginSuccess,self,self.onSDKLoginSuccess)
    if SDKCenter then
        SDKCenter:setUserInfo( "", "", 7)
    end
end

function LoginScene:onExit()
    FzEventCenter:RemoveEvent(FzEvent.LoginSuccess,self)
    FzEventCenter:RemoveEvent(FzEvent.CreatePlayer,self)
    FzEventCenter:RemoveEvent(FzEvent.SDKLoginSuccess,self)
end

function LoginScene:showServerList()
    -- if self.gameStar then 
    --     self.gameStar:hide()
    -- end
    if self.listLayer then
        self.listLayer:removeSelf()
        self.listLayer = nil
    end
    if self.StartTX then
        self.StartTX:show()
    end
    local listLayer=ServerListLayer.new(self.server_list)
    self:addChild(listLayer)
    self.listLayer = listLayer
end

function LoginScene:setServerList(server_list)
    self.server_list=server_list
end

function LoginScene:checkCppVersion()        --需要更新时return false
    local path=cc.FileUtils:getInstance():getWritablePath().."CTdownloaded/version.manifest"
    local versionBuf=cc.FileUtils:getInstance():getStringFromFile(path)
    assert(string.len(versionBuf)>0,"version.manifest，读取失败")
    local versionJson=json.decode(versionBuf)
    assert(versionJson,"version.manifest解析失败")
    local remote_cpp_version=tonumber(versionJson.cpp_version) or 1
    local local_cpp_version=info.cpp_version or 1
    if remote_cpp_version>local_cpp_version then
        Alert:show("",Language.updater.update_cpp,Alert.TYPE_OK,function()
            SDKCenter:updateClient()
            MyApp:exit()
        end)
        return false
    end
    return true
end

function LoginScene:initJcUI()
    local JC_ButtonUI = FZutil.createCellNode("JapanUI/Node_iniheritanceBtn")
    self:addChild(JC_ButtonUI.root,9)
    JC_ButtonUI.root:setPosition(display.width-110,110)
    local gameJC=JC_ButtonUI.Button_uniqueskill
    gameJC:setTouchEnabled(true)
    gameJC:onTouch(function( e )
        if e.name=="ended" then 
            local jcLayer = FZutil.createUILayer()
            local Jc_UI = FZutil.createSceneNode("JapanUI/Node_iniheritanceUI")
            if Jc_UI.Image_baseMap02 then
                Jc_UI.Image_baseMap02:hide()
            end
            Jc_UI.Image_baseMap04:ignoreContentAdaptWithSize(true)
            jcLayer:addChild(Jc_UI.root,99)
            self:addChild(jcLayer,99)

            Jc_UI.TextField_accountInput:setString("")
            Jc_UI.TextField_accountInput:onEvent(function(e)
                if e.name=="ATTACH_WITH_IME" then
                    Jc_UI.root:stopAllActions()
                    Jc_UI.root:moveTo({y=100,time=1/60})
                elseif e.name=="DETACH_WITH_IME" then
                    Jc_UI.root:stopAllActions()
                    Jc_UI.root:moveTo({y=0,time=1/60})
                end
            end)
            FZutil.onButtonTwoImagTouchNormal(Jc_UI.Button_sure,function(e)
                if e.name == "ended" then
                    local code_str=Jc_UI.TextField_accountInput:getString()
                    if string.len(code_str)>0 then
                        print("code_str",code_str)
                        -- 获取继承信息
                        local orgin_info=require(FzFileUtils.getOriginInfoPath())
                        if not orgin_info or not orgin_info.inherit_code then
                            MoveMessage.show("继承错误!请检查配置信息是否正确!")
                            return
                        end
                        local xhr = cc.XMLHttpRequest:new() -- http请求  
                        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON -- 响应类型  
                        --"http://192.168.1.70/cgi-bin/doge2/inherit_code.py?user_id=1&machine_info=123455 检查"
                        local url_str = string.format("%s?code=%s&machine_info=%s", orgin_info.inherit_code,code_str,RoleData.machine_info)
                        print("inherit_url: "..url_str)
                        xhr:open("GET", url_str) -- 打开链接 + 继承码
                        -- 状态改变时调用  
                        local function onReadyStateChange()  
                            -- 显示状态文本  
                            local statusString = "Http Status Code:"..xhr.statusText 
                            release_print(statusString)
                            if xhr.status==XMLHR_Status_SUCCESS then    --成功
                                release_print(xhr.response) 
                                local ret=json.decode(xhr.response)
                                if ret and ret.user_id and string.len(ret.user_id)>0 and ret.server_id then 
                                    local servers = self.server_list.server
                                    local jc_server_id = ret.server_id
                                    if not servers[jc_server_id] then
                                        Alert:show("","引継失敗!正しい引継ヤードを入力してください")
                                        return
                                    end
                                    Alert:show("","引継成功~")
                                    cc.UserDefault:getInstance():setStringForKey("user_id",ret.user_id)
                                    RoleData.user_id = ret.user_id
                                    cc.UserDefault:getInstance():setIntegerForKey("last_server",ret.server_id)
                                    -- 清除旧player_id
                                    cc.UserDefault:getInstance():setIntegerForKey("player_id",0)
                                    if self and self.showServerList then 
                                        self:showServerList()
                                    end
                                    jcLayer:removeSelf()
                                    jcLayer = nil
                                else
                                    Alert:show("","引継ぎできませんでした。\n引継ぎコードをご確認ください。")
                                end
                            else
                                Alert:show("","引継失敗!正しい引継ヤードを入力してください")
                            end
                        end
                        -- 注册脚本回调方法  
                        xhr:registerScriptHandler(onReadyStateChange)  
                        xhr:send() -- 发送请求 
                    end
                end
            end)

            Jc_UI.Button_cancel:setTouchEnabled(true)
            FZutil.onButtonTwoImagTouchNormal(Jc_UI.Button_cancel,function(e)
                if e.name=="ended" then
                    jcLayer:removeSelf()
                    jcLayer = nil
                end
            end)
        end
    end)
end

return LoginScene