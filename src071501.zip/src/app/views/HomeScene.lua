local FZutil = require("app.FZutil")
local TileMapLayer = require("app.MapTile.TileMapLayer")
local TileMapListener = require("app.MapTile.TileMapListener")
local FurnitureLayer = require("app.Furniture.FurnitureLayer")
local PreviewLayer = require("app.Furniture.PreviewLayer")
local MainMapListener = require("app.MapTile.MainMapListener")
local MenuSceneLayer = require("app.Menu.MenuSceneLayer")
local PetLayer = require("app.Pet.PetLayer")
local PetSummonLayer = require("app.Pet.PetSummonLayer")
local PetManageLayer = require("app.PetManage.PetManageLayer")
local CTDressUpLayer = require("app.CTAdorn.CTDressUpLayer")
local MissionLayer = require("app.Mission.MissionLayer")
local ChapterLayer = require("app.chapter.ChapterLayer")
local InformationLayer = require("app.HeadInformation.InformationLayer")
local PetSceneLayer = require("app.Pet.PetSceneLayer")
local MailListLayer = require("app.Mail.MailListLayer")
local ChatLayer = require("app.Chat.ChatLayer")
local ChatSystemCell = require("app.Chat.ChatSystemCell")
local PersonHotHelp = require("app.public.PersonHotHelp")
local MenuLayer = require("app.Menu.MenuLayer")
local SettingLayer = require("app.Setting.SettingLayer")
local LeagueLayer = require("app.League.LeagueLayer")
local GonggaoLayer = require("app.public.GonggaoLayer")
local CTRankLayer = require("app.CTRank.CTRankLayer")
local ActivityLayer = require("app.Activity.ActivityLayer")
local CTFriendChatLayer = require("app.Friend.CTFriendChatLayer")
local FriendLayer = require("app.Friend.FriendLayer")
local FriendSaleLayer = require("app.Friend.FriendSaleLayer")
local FriendSongLayer = require("app.Friend.FriendSongLayer")

local MainMapLayer = require("app.MapTile.MainMapLayer")
local GukeVipTipLayer = require("app.CTXunLu.GukeVipTipLayer")
local MarketScene = require("app.Market.MarketScene")

local PresentSceneLayer = require("app.Present.PresentSceneLayer")

local AdLayer = require("app.Ad.AdLayer")
-- local ManageNoteLayer = require("app.ManageNote.ManageNoteLayer")
local HelpButtonNode = require("app.JapanUI.HelpButtonNode")

local moveDistance = 150
local moveTime = 0.2
local startChilderCount = 2       --HomeScene没有添加其他系统界面的childerCount
local isCheckActivityTx = false   --是否检查活动特效(上线后默认就有特效，点击后特效没了（有东西可以领还是有特效）)
local localZOrder = 20            --渲染大于剧情默认(10)
local secondMoveing = false        --二级菜单是否正在移动

--二级菜单(1:经营 2:管理)
local RUNTYPE = 1               
local MANADGETYPE = 2
local btnDefaultPosy = 59
local firstBtnDefaultPosy = 21

local HomeScene = class("HomeScene", cc.load("mvc").ViewBase)
function HomeScene:onCreate()
    local mainui=FZutil.createSceneNode("MainUI/MainScene")
    self:addChild(mainui.root,-2)
    self.mainui = mainui
    self.HideAll_Btn = mainui.Node_bottom_middle:getChildByName("Button_down")
    self.ShowAll_Btn = mainui.Node_bottom_middle:getChildByName("Button_up")

    mainui.FileNode_currency.notIgnoreSize = true
    FZutil.ignoreContentSizeImg(mainui.root,"Japan")

    CTGuideManage:initGuideOnHomeScene(mainui,self)
    TopCurrencyNode:initCurrencyNode(mainui.FileNode_currency)  -- 顶部金币等数据刷新
    local x,y = mainui.FileNode_announcement:getPosition()
    mainui.FileNode_announcement:setPosition(display.cx,display.height-70)
    ChatSystemCell:initSystemCell(mainui.FileNode_announcement) -- 系统滚动消息

    if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        local qipao_x = mainui.FileNode_qipao:getPositionX()
        mainui.FileNode_qipao:setPositionX(qipao_x-80)
    end
    CTButtonTalk:initTalkCell(mainui.FileNode_qipao,self)            -- 右下角按钮 评论气泡

    -- 加载地图相关！
    local MapMain = MainMapLayer.new()
    self:addChild(MapMain,-4)
    --[[
    performWithDelay(self,function ()
        local MapMain = MainMapLayer.new()
        display.getRunningScene():addChild(MapMain,-1)
    end, 3)
    ]]
    mainui.Image_4:hide()
    mainui.Image_activity_tip:hide()
    --
    --活动
    local activityTX = self.mainui.Node_top_l:getChildByTag(262)
    self.activityTX = activityTX
    FZutil.onButtonTwoImagTouch(mainui.Button_activity,mainui.Image_activity1,mainui.Image_activity2,function(e)
        if e.name == "ended" then
            -- MoveMessage.show(Language.not_open)
            -- NetEngine:sendMessage(game_cmd.CCheatUpdatePlayer,{type = 1,level = 15 ,exp = 0})
            -- NetEngine:sendMessage(game_cmd.CCheatUpdatePlayer,{type = 2,level = 15 ,exp = 0})
            local guide = RoleData.player_info.guide
            if guide<10000 then
                activityTX:hide()
                MoveMessage.show(Language.need_two_level)
                return
            end
            isCheckActivityTx = true
            local activityLayer = ActivityLayer.new()
            self:addChild(activityLayer,localZOrder)
        end
    end,true)
    --[[
        主界面按钮
    ]]
    local helpBtn = HelpButtonNode.new(DyHelper.HELP_TYPE.MAIN_HOME_HELP,mainui.Button_populartip,self)
    mainui.Button_populartip:onTouch(function(e) -- 人气帮助
        if e.name == "ended" then
            local helplayer = PersonHotHelp.new(self)
            self:addChild(helplayer,localZOrder)
        end
    end)
    --经营
    -- mainui.Button_run:onTouch(function(e)
    --     if e.name == "ended" then
    --         self:SecondMeunShow()
    --     end
    -- end)
    mainui.Button_sign:hide() -- 签到
    -- 经营
    FZutil.onButtonTwoImagTouch(mainui.Button_run,mainui.Image_run1,mainui.Image_run2,function(e)
        if e.name == "ended" then
            -- self:TouchOpenChapter()
            self:ManageBtnTouchFunc(RUNTYPE)
        end
    end,true)
    --充值
    FZutil.onButtonTwoImagTouch(mainui.Button_pay,mainui.Image_pay1,mainui.Image_pay2,function(e)
        if e.name == "ended" then
            local payLayer = PayUIlayer.new()
            self:addChild(payLayer,localZOrder)
        end
    end,true)
    -- 礼包
    local persentBtn = mainui.Node_top_l:getChildByName("Button_present")
    local present1Img = persentBtn:getChildByName("Image_present1")
    local present2Img = persentBtn:getChildByName("Image_present2")
    FZutil.onButtonTwoImagTouch(persentBtn,present1Img,present2Img,function(e)
        if e.name == "ended" then
            local presentLayer = PresentSceneLayer.new()
            self:addChild(presentLayer,localZOrder)
        end
    end,true)
    -- 招聘
    FZutil.onButtonTwoImagTouch(mainui.Button_call,mainui.Image_call1,mainui.Image_call2,function(e)
        if e.name == "ended" then
            local PetSummonLayer = PetSummonLayer.new()
            self:addChild(PetSummonLayer,localZOrder)
        end
    end,true)
    -- 任务
    -- local missionPosx,missionPosy = mainui.Button_mission:getPosition()
    -- local wordPos = mainui.Node_top_r:convertToWorldSpace({x=missionPosx,y=missionPosy})
    -- StoryNode.linePosx = wordPos.x
    -- StoryNode.linePosy = wordPos.y
    FZutil.onButtonTwoImagTouch(mainui.Button_mission,mainui.Image_mission1,mainui.Image_mission2,function(e)
        if e.name == "ended" then
            self:TouchOpenMission()
        end
    end,true)
    --排行
    FZutil.onButtonTwoImagTouch(mainui.Button_rank,mainui.Image_rank1,mainui.Image_rank2,function(e)
        if e.name == "ended" then
            -- MoveMessage.show(Language.not_open)
            local rankLayer = CTRankLayer.new()
            self:addChild(rankLayer,localZOrder)
        end
    end,true)
    -- 邮件
    mainui.Button_mail:onTouch(function (e)
        if e.name == "ended" then
            local mailLayer = MailListLayer.new()
            self:addChild(mailLayer,localZOrder)
        end
    end)
    -- 好友
    mainui.Button_friend:onTouch(function (e)
        if e.name == "ended" then
            local guide = RoleData.player_info.guide
            if guide<10000 then
                MoveMessage.show(Language.need_two_level)
                return
            end
            local friendLayer = FriendLayer.new(self)
            self:addChild(friendLayer,localZOrder)
            self:updateHomeFriendRedPoint()
        end
    end)
    -- 聊天
    self:addChatRedPoint(true) -- 隐藏主界面聊天红点
    local Button_chat = self.mainui.Node_top_r:getChildByName("Button_chat")
    Button_chat:onTouch(function (e) 
        if e.name == "ended" then
            local ChatLayer = ChatLayer.new()
            self:addChild(ChatLayer,localZOrder)
            self:addChatRedPoint(true) -- 隐藏主界面聊天红点
        end
    end)
    --管理
    FZutil.onButtonTwoImagTouch(mainui.Button_manadge,mainui.Image_manadge1,mainui.Image_manadge2,function(e)
        if e.name == "ended" then
            self:ManageBtnTouchFunc()
        end
    end,true)

    --二级菜单
    self.secondMeun={
        [RUNTYPE] = {
            mainui.bottom,
            mainui.Button_jingying,
            mainui.Button_msls,
            mainui.Button_guanggao,
            mainui.Button_note,
			mainui.Button_share
        },
        [MANADGETYPE] = {
            mainui.bottom,
            mainui.Button_operate,
            mainui.Button_employee,
            mainui.Button_decorate,
            mainui.Button_menu,
            mainui.Button_arrange
        }   
    }
    self.secondMenuShowState={
        [RUNTYPE] = false,
        [MANADGETYPE] = false
    }
    local setManageBtnLayer = FZutil.createUILayer() -- 触摸收起下排按钮
    setManageBtnLayer:setBackGroundColorOpacity(math.floor(0*0xff))
    setManageBtnLayer:setSwallowTouches(false)
    self:addChild(setManageBtnLayer,-3)
    setManageBtnLayer:onTouch(function(e)
        if e.name == "ended" then
            for _type,_show_state in ipairs(self.secondMenuShowState) do
                if _show_state then
                    self:ManageBtnTouchFunc(_type)
                    break
                end
            end
        end
    end)

    -- 宠物管理 
    FZutil.onButtonTwoImagTouch(mainui.Button_operate,mainui.Image_operate1,mainui.Image_operate2,function(e)
        if e.name == "ended" then
            self:OpenPetManage()
        end
    end,true)
    -- 装扮
    FZutil.onButtonTwoImagTouch(mainui.Button_arrange,mainui.Image_arrange1,mainui.Image_arrange2,function(e)
        if e.name == "ended" then
            local guide = RoleData.player_info.guide
            if guide < 10000  then
                MoveMessage.show(Language.wait_guke_find)
                return
            end
            self:TouchOpenAdorn()
        end
    end,true)

    --装饰
    FZutil.onButtonTwoImagTouch(mainui.Button_decorate,mainui.Image_decorate1,mainui.Image_decorate2,function(e)
        if e.name == "ended" then
            local guide = RoleData.player_info.guide
            if guide < 10000  then
                MoveMessage.show(Language.wait_guke_find)
                return
            end
            self:TouchOpenDecorate()
        end
    end,true)

    --Button_menu
    FZutil.onButtonTwoImagTouch(mainui.Button_menu,mainui.Image_menu1,mainui.Image_menu2,function(e)
        if e.name == "ended" then
            self:TouchOpenMenu()
        end
    end,true)

    --店员
    FZutil.onButtonTwoImagTouch(mainui.Button_employee,mainui.Image_employee1,mainui.Image_employee2,function(e)
        if e.name == "ended" then
            self:TouchOpenPetScene()
        end
    end,true)

    --设置
    mainui.Button_set:onTouch(function(e)
        if e.name == "ended" then
            local settingLayer = SettingLayer.new()
            self:addChild(settingLayer,localZOrder)
        end
    end)

    self:SecondMeunShow()

    --头像信息查看
    mainui.Image_head:setTouchEnabled(true)
    mainui.Image_head:onTouch(function(e)
        if e.name == "ended" then
            local informationLayer = InformationLayer.new()
            self:addChild(informationLayer,localZOrder)
        end
    end)

    --美食联赛
    FZutil.onButtonTwoImagTouch(mainui.Button_msls,mainui.Image_msls1,mainui.Image_msls2,function(e)
        if e.name == "ended" then
            local leagueLayer = LeagueLayer.new()
            self:addChild(leagueLayer,localZOrder)
        end
    end,true)
    --二级菜单经营
    FZutil.onButtonTwoImagTouch(mainui.Button_jingying,mainui.Image_jingying1,mainui.Image_jingying2,function(e)
        if e.name == "ended" then
            self:TouchOpenChapter()
        end
    end,true)

    --广告
    mainui.Image_guanggao_tip:hide()
    FZutil.onButtonTwoImagTouch(mainui.Button_guanggao,mainui.Image_guanggao1,mainui.Image_guanggao2,function(e)
        if e.name == "ended" then
            local adLayer = AdLayer.new()
            self:addChild(adLayer,localZOrder)
        end
    end,true)
    -- 公告按钮 日服有
    if mainui.Button_gonggao_Jp and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        mainui.Button_gonggao_Jp:show()
        mainui.Button_gonggao_Jp:setPosition(-54.11,-133.66)
        mainui.Button_rank:setPosition(-54.11,-232.41)
        mainui.Button_mission:setPosition(-54.11,-327.34)
        mainui.Button_call:setPosition(-54.11,-424.26)
        
        local gonggao_JpUI = FZutil.createMap(mainui.Button_gonggao_Jp)
        FZutil.onButtonTwoImagTouch(gonggao_JpUI.Button_rank,gonggao_JpUI.Image_rank1,gonggao_JpUI.Image_rank2,function(e)
        if e.name == "ended" then
                local GonggaoLayer = GonggaoLayer.new()
                display.getRunningScene():addChild(GonggaoLayer,99999)
            end
        end,true)
    elseif mainui.Button_gonggao_Jp then
        mainui.Button_gonggao_Jp:hide()
    end
    
	-- 分享
    if mainui.Button_share and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        mainui.Button_share:show()
        FZutil.onButtonTwoImagTouch(mainui.Button_share,mainui.Image_share1,mainui.Image_share2,function(e)
            if e.name == "ended" then
                SDKCenter:onSdkShare() 
                -- local fileName = "shareImage.png"  
                -- local filepath=cc.FileUtils:getInstance():getWritablePath().."/shareImage.png"
                -- if cc.FileUtils:getInstance():isFileExist(filepath) then
                --     local ret=cc.FileUtils:getInstance():removeFile(filepath)
                -- end
                -- -- 移除纹理缓存  
                -- cc.Director:getInstance():getTextureCache():removeTextureForKey(fileName)  
                -- -- self:removeChildByTag(1000)  
                -- -- 截屏  
                -- cc.utils:captureScreen(function(succeed, outputFile)  
                --     if succeed then  
                --     -- local winSize = cc.Director:getInstance():getWinSize()  
                --     -- local sp = cc.Sprite:create(outputFile)  
                --     -- self:addChild(sp, 999, 1000)  
                --     -- sp:setPosition(winSize.width / 2, winSize.height / 2)  
                --     -- sp:setScale(0.5) -- 显示缩放  
                --         print("截屏：",outputFile) 
                --     else  
                --         MoveMessage.show("分かち合い失敗。") 
                --     end  
                -- end, fileName)
            end
        end,true)
    elseif mainui.Button_share then
        mainui.Button_share:hide()
    end
    --经营笔记
    mainui.Button_note:hide()
    -- mainui.Image_note_tip:hide()
    -- FZutil.onButtonTwoImagTouch(mainui.Button_note,mainui.Image_note1,mainui.Image_note2,function(e)
    --     if e.name == "ended" then
    --         print("经营笔记")
    --         local NoteLayer = ManageNoteLayer.new()
    --         self:addChild(NoteLayer,localZOrder)
    --     end
    -- end,true)
    --市场
    FZutil.onButtonTwoImagTouch(mainui.Button_market,mainui.Image_market1,mainui.Image_market2,function(e)
        if e.name == "ended" then
            if ShopData.marketRedPoint then
                ShopData:setMarketRedPoint( false )
                self:updateMarketRedPoint()
            end
            local marketScene = MarketScene.new()
            self:addChild(marketScene,localZOrder)
        end
    end,true)

    -------自己创建了一个 存放 主界面任务tip的Node .. (方便隐藏)
    if not self.MainMissionRoot then -- 
        self.MainMissionRoot = cc.Node:create()
        self.MainMissionRoot:setPosition(display.cx,display.height-120)
        self:addChild(self.MainMissionRoot)
    end
    ------------------------------------------------------------
    self:updatePlayer()
    -- self:addCheatNode() -- 添加作弊
    print("***********HomeScene Create()*************")
    self:updateRedPoint()
    self:updateMainMissionCell()
    self:updataExpTx()
    --
    self:updatePersonHot() -- 刷新人气
    -- 好友相关
    self:setFriendHomeView(false)
    self:updateHomeFriendRedPoint()
    -- 隐藏周围所有按钮（方便截图.....）
    self:initHideAllBtn()
    self:updateMarketRedPoint()

    if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        self:japanInitAssignChapter()
    end
end
function HomeScene:updataExpTx(data_list)
    local function playTX(tx_node,tx_name)
        tx_node:show()
        local Animate_Tx = tx_node:getAnimation()
        Animate_Tx:play(tx_name)
        local function AnimationEvent(armature,movementType,movementID) 
            local id = movementID 
            if movementType == ccs.MovementEventType.loopComplete then 
                if id == tx_name then 
                    tx_node:hide()
                end 
            end 
        end 
        Animate_Tx:setMovementEventCallFunc(AnimationEvent)
    end
    local player_exp_TX = self.mainui.Image_headkuang:getChildByTag(231) -- 玩家经验跳动TX
    local ct_exp_TX = self.mainui.Node_top_l:getChildByTag(232) -- 餐厅经验跳动TX
    if player_exp_TX and ct_exp_TX then
        if data_list then
            if data_list.add_res_exp then
                playTX(ct_exp_TX,"TX_resExp")           -- 播放特效
                TopCurrencyNode:createFreeText(2,data_list.add_res_exp,self.mainui.Text_exp_M,cc.p(5,-10))
            end
            if data_list.add_player_exp then
                playTX(player_exp_TX,"TX_playerExp")    -- 播放特效
                TopCurrencyNode:createFreeText(2,data_list.add_player_exp,self.mainui.Text_playerlvl_M,cc.p(7,-10))
            end
        else
            player_exp_TX:hide()
            ct_exp_TX:hide()
        end
    end
    ---------------------主界面餐厅经验进度条----------------------
    local infoPlayer = RoleData.player_info
    local ctcfg = ConfigData.st_res_lv[infoPlayer.ct_level]
    if not ctcfg then return end
    local next_ct_exp = ctcfg.res_exp
    if infoPlayer.ct_level == Define.Max_CT_Level then
        next_ct_exp = infoPlayer.ct_exp
    end
    self.mainui.LoadingBar_resexp:setPercent(math.floor((infoPlayer.ct_exp/next_ct_exp)*100))
end
function HomeScene:OpenAdornTX()--打开布置 装修的 帷幕特效
    self.HideAll_Btn:hide()
    self.ShowAll_Btn:hide()
    self:setAssignChapterNodeShowState(false)
    print("打开帷幕TX 清除缓存11")
    FZutil.clearCache()
    print("打开帷幕TX 清除缓存22")
    local filepath="res/cocos/TX/weimu02/weimu02.ExportJson"
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(filepath)
    local TX_node=ccs.Armature:create("weimu02")
    TX_node:setPosition(display.cx,display.top-320)
    local Animate_Tx = TX_node:getAnimation()
    Animate_Tx:play("up")
    self:addChild(TX_node,10)
    local function AnimationEvent(armature,movementType,movementID) 
        local id = movementID 
        if movementType == ccs.MovementEventType.loopComplete then 
            if id == "up" then 
                TX_node:removeSelf()
                TX_node = nil
            end 
        end 
    end 
    Animate_Tx:setMovementEventCallFunc(AnimationEvent)
    audio.playSound(FzSound.sounds.soud_WeiMu_Up,false)
end
function HomeScene:TouchOpenAdorn(_furnitureId,_guideType) -- 打开布置界面
    print("打开布置界面",_furnitureId,_guideType)
    self:OpenAdornTX()
    CTSearchCenter:CloseSearchPath()
    if not self.furnitureLayer then
        local furnitureLayer = FurnitureLayer.new(_furnitureId,_guideType)
        self.furnitureLayer = furnitureLayer  
        self:addChild(furnitureLayer)
        self.furnitureLayer:hide()
        self.furnitureLayer:enterPreViewState()
    end
    if not self.DressUpLayer then
        self:onlyShowMap(true)
        CTAdornData:CleanLocalData()
        local DressUpLayer = CTDressUpLayer.new()
        self:addChild(DressUpLayer)
        self.DressUpLayer = DressUpLayer
        self.DressUpLayer:UpdataDressUpLayer()
    end
    self:setMainMissionVisible()
end
function HomeScene:TouchOpenDecorate()
    self:OpenAdornTX()
    if not self.furnitureLayer then
        self:onlyShowMap(true)
        CTAdornData:CleanLocalData()
        local furnitureLayer = FurnitureLayer.new()
        self.furnitureLayer = furnitureLayer
        self:addChild(furnitureLayer)
        CTSearchCenter:CloseSearchPath()
        self:setMainMissionVisible()
        -- 引导必须点此才执行
        CTGuideManage:furnitureCheckGuide(1)
    end
end
function HomeScene:TouchOpenPetScene()
    local petSceneLayer = PetSceneLayer.new()
    self:addChild(petSceneLayer,localZOrder)
end
function HomeScene:TouchOpenMenu(menuId)
    local menuSceneLayer = MenuSceneLayer.new(menuId)
    self:addChild(menuSceneLayer,localZOrder)
end
function HomeScene:TouchOpenMission(mission_index)
    mission_index = mission_index or 1
    local missionLayer = MissionLayer.new(mission_index)
    self:addChild(missionLayer,localZOrder)
end
function HomeScene:TouchOpenChapter()
    local ChapterLayer = ChapterLayer.new()
    self:addChild(ChapterLayer,localZOrder)
end
function HomeScene:OpenPetManage(index)      -- 打开员工管理界面
    if index then
        print("打开员工管理界面 "..index)
    else
        print("打开员工管理界面 0")
    end
    local PetManageLayer = PetManageLayer.new(index)
    self:addChild(PetManageLayer,localZOrder)
end

function HomeScene:ManageBtnTouchFunc(second_type) -- 收缩下排 按钮
    if secondMoveing then
        return
    end
    second_type = second_type or MANADGETYPE
    local isShow = self.secondMenuShowState[second_type]
    if isShow and RoleData.player_info.guide<CTGuideManage.UpLevel_Guide then
        print("引导中 收缩下排 ",isShow,RoleData.player_info.guide,CTGuideManage.UpLevel_Guide)
        return
    end
    self.secondMenuShowState[second_type] = isShow==false and true or false
    self:SecondMeunShow(second_type)
end
function HomeScene:getManageBtnPos(second_type)    -- 获取收缩下排 按钮状态
    second_type = second_type or MANADGETYPE
    return self.secondMenuShowState[second_type]
end
function HomeScene:OpenFurnitureForDressUpLayer() -- 在装扮界面打开装修界面
    if not self.furnitureLayer then
        local furnitureLayer = FurnitureLayer.new()
        self.furnitureLayer = furnitureLayer
        self:addChild(furnitureLayer)
    else
        self:hidePreView()
    end
    FzEventCenter:DispichEvent(FzEvent.updateTipContent) 
end
function HomeScene:OpenDressUpLayerForFurniture() -- 在装修界面打开装扮界面
    if not self.DressUpLayer then
        local DressUpLayer = CTDressUpLayer.new()
        self:addChild(DressUpLayer)
        self.DressUpLayer = DressUpLayer
    else
        self.DressUpLayer:show()
    end
    self.DressUpLayer:UpdataDressUpLayer()
end
--玩家相关信息
function HomeScene:updatePlayer()
    local mainui = self.mainui
    if self then
        local rolePlayerInfoData = RoleData.player_info
       mainui.Image_head:loadTexture(IconPath.PetHeadIcon( rolePlayerInfoData.icon_id ))
       mainui.Text_name:setString(rolePlayerInfoData.name)
       mainui.Text_exp_M:setString(rolePlayerInfoData.ct_level)
       mainui.Text_playerlvl_M:setString(rolePlayerInfoData.level)

        -- 玩家等级这里的底 是一个奖牌  奖牌的资源对应餐厅评级的段位
        local dan = CTRankData.selfDan
        if selfRankData then
           self:setPlayerLvImg(dan)
        else
            self:registerRankEvent()
            self:requestCTRank()
        end
    end
    local Image_mail = mainui.Image_mail
    local has_num = MailData:checkRedPointNum()
    if has_num>0 then
        local mail_num = mainui.mail_num
        Image_mail:show()
        mail_num:setString(has_num)
    else
        Image_mail:hide()
    end
end

--奖牌的资源对应餐厅评级的段位
function HomeScene:setPlayerLvImg( dan )
    local mainui = self.mainui
    mainui.Image_playerlvl:loadTexture(IconPath.PlayerCTRankLevel( dan ))
end

function HomeScene:requestCTRank()
    NetEngine:sendMessage(game_cmd.CGetSelfDan)
    -- NetEngine:sendMessage(game_cmd.CGetSelfRank, {rank_type = CTRankData.RANKTYPE.CT_LEVEL})
end

--自身排行回调
function HomeScene:GetSelfDan( dan )
    -- if self and msg.rank_type == CTRankData.RANKTYPE.CT_LEVEL then
    --     self:setPlayerLvImg( msg )
    -- end
    if self then
        self:setPlayerLvImg( dan )
    end
    --一定要及时移除  主界面一直存在  其它地方也有注册GetSelfRank回调  因为该回调是全局的
    self:removeRankEvent()
end

--注册自身排行回调事件
function HomeScene:registerRankEvent() 
    -- FzEventCenter:RegisterEvent(FzEvent.GetSelfRank,self,self.GetSelfRank)
    FzEventCenter:RegisterEvent(FzEvent.GetSelfDan,self,self.GetSelfDan)
end

--移除自身排行回调事件
function HomeScene:removeRankEvent()
    -- FzEventCenter:RemoveEvent(FzEvent.GetSelfRank,self)
    FzEventCenter:RemoveEvent(FzEvent.GetSelfDan,self)
end


function HomeScene:updatePersonHot() -- 刷新人气
    -- local Person_Hot = CTSearchPath:UpdataPersonHot() or 0
    self.mainui.AtlasLabel_popular:setString(RoleData.player_info.Hot_num)
end

--市场红点
function HomeScene:updateMarketRedPoint()
    self.mainui.Image_market_tip:setVisible(ShopData.marketRedPoint)
end

function HomeScene:addCheatNode()
    --[[
        作弊Node
    ]]
    local cheatNode = ccui.Widget:create()
    cheatNode:setTouchEnabled(true)
    cheatNode:setSwallowTouches(false)
    self:addChild(cheatNode)

    local cheatField1 = ccui.TextField:create("作弊","youyuan.ttf",20)
    cheatField1:setPlaceHolder("类型")
    cheatField1:setPosition(200,20)
    cheatField1:setContentSize(cc.size(30, 20))
    cheatNode:addChild(cheatField1)

    local cheatField2 = ccui.TextField:create("作弊","youyuan.ttf",20)
    cheatField2:setPlaceHolder("id")
    cheatField2:setPosition(300,20)
    cheatField2:setContentSize(cc.size(30, 20))
    cheatNode:addChild(cheatField2)

    local cheatField3 = ccui.TextField:create("作弊","youyuan.ttf",20)
    cheatField3:setPlaceHolder("数量")
    cheatField3:setPosition(400,20)
    cheatField3:setContentSize(cc.size(30, 20))
    cheatNode:addChild(cheatField3)

    local cheatText = ccui.Text:create()
    cheatText:setString("作弊")
    cheatText:setFontSize(20)
    cheatText:setPosition(cc.p(500,20))
    cheatText:setContentSize(cc.size(40, 20))
    cheatNode:addChild(cheatText)

    cheatText:setTouchEnabled(true)
    cheatText:onTouch(function(e)
        if e.name == "ended" then
            local _type = tonumber(cheatField1:getString())
            local _id = tonumber(cheatField2:getString())
            local _num = tonumber(cheatField3:getString())
            if _type and _id and _num and _type>0 and _id>0 then
               NetEngine:sendMessage(game_cmd.CCheatReward,{type=_type,id=_id,num=_num})
            end
        end
    end)
end

function HomeScene:onlyShowMap( siOnlyShowMap )
    self.mainui.Node_bottom_l:setVisible(siOnlyShowMap==false)
    self.mainui.Node_top_l:setVisible(siOnlyShowMap==false)
    self.mainui.Node_bottom_r:setVisible(siOnlyShowMap==false)
    self.mainui.Node_top_r:setVisible(siOnlyShowMap==false)
end
--【【 好友相关
local Hj_Look_Key = nil
local Ss_Look_Key = nil
local Wall_Look_Key = nil
function HomeScene:setOnFriendUI() -- 设置所在好友家的主界面按钮UI
    Hj_Look_Key = true
    Ss_Look_Key = true
    CTTileData.Hj_Look_Key = Hj_Look_Key
    CTTileData.Ss_Look_Key = Ss_Look_Key
    Wall_Look_Key = nil
    -- 顶部UI
    local mainui = self.mainui
    local UpBtn = mainui.Node_bottom_friend:getChildByName("Button_up")
    UpBtn:onTouch(function(e)
        if e.name == "ended" then
            mainui.Node_bottom_friend:setVisible(false)
            local friendLayer = FriendLayer.new(self)
            self:addChild(friendLayer,localZOrder)
        end
    end)
    mainui.Image_headfd:loadTexture(IconPath.PetHeadIcon( FriendData.On_FriendData.icon ))
    local OnFriendData = FriendData.Home_MsgData
    local Name_txt = mainui.Text_namefd
    local Renqi_txt = mainui.AtlasLabel_popularfriend
    local friend_level = mainui.Text_playerlvlfd_M
    local friend_ct_level = mainui.Text_expfd_M

    Name_txt:setString(FriendData.On_FriendData.name)
    Renqi_txt:setString(OnFriendData.moods)
    friend_level:setString(FriendData.On_FriendData.level)
    friend_ct_level:setString(OnFriendData.scene_level)

    --好友 玩家等级这里的底 是一个奖牌  奖牌的资源对应餐厅评级的段位
    mainui.Image_playerlvlfd:loadTexture(IconPath.PlayerCTRankLevel( OnFriendData.dan_rank )) 

    local Remove_btn = mainui.Node_top_friendr:getChildByName("Button_del") -- 删除好友
    local Chat_btn = mainui.Node_top_friendr:getChildByName("Button_chat") -- 聊天
    local friendgold_btn = mainui.Node_top_friendr:getChildByName("Button_friendgold") -- 送友情点
    local back_btn = mainui.Node_top_friendr:getChildByName("Button_visit") -- 回自己家
    Remove_btn:onTouch(function(e) -- 删除好友
        if e.name == "ended" then
            local id = FriendData.On_FriendData.player_id
            Alert:show("", Language.friend.is_remove_friend, Alert.TYPE_YES_NO, function(tag)
                if tag then
                    Alert:show("", Language.friend.is_add_black, Alert.TYPE_YES_NO, function(tag)
                        if tag then
                            NetEngine:sendMessage(game_cmd.CAddBlackList,{black_datas = {{player_id = id}}})
                        else
                            NetEngine:sendMessage(game_cmd.CDelFriends,{player_ids = {id}})
                        end
                    end)
                end
            end)
        end
    end)
    Chat_btn:onTouch(function(e)  -- 聊天
        if e.name == "ended" then
            local friendChatLayer = CTFriendChatLayer.new(FriendData.On_FriendData)
            self:addChild(friendChatLayer,localZOrder)
        end
    end)
    local is_send_friend_point = FriendData.On_FriendData.is_send_friend_point
    friendgold_btn:setTouchEnabled(is_send_friend_point == 0)
    friendgold_btn:setBright(is_send_friend_point == 0)
    friendgold_btn:onTouch(function(e)  -- 送友情点
        if e.name == "ended" then
            local id = FriendData.On_FriendData.player_id
            if FriendData.My_Seed_Num<10 then
                NetEngine:sendMessage(game_cmd.CSendFriendPoint,{friend_ids = {id}})
            else
                MoveMessage.show(Language.friend.seed_max_point)
            end
        end
    end)
    local goBackHome = function()
        CTTileData.Tile_M = FriendData.Own_Tile_M
        CTTileData.Tile_N = FriendData.Own_Tile_N
        CTAdornData.OnMap_Adorn_Data = FriendData.Own_MapAdorn -- 取回自己的装饰信息
        FriendData.Own_Tile_M = nil
        FriendData.Own_Tile_N = nil
        FriendData.Own_MapAdorn = nil
        FriendData.On_FriendData = nil
        FriendData.Home_MsgData = nil
        CTTileData.Hj_Look_Key = nil
        CTTileData.Ss_Look_Key = nil
        FDSearchCenter:CloseSearchPath() -- 关闭好友家寻路
        FzEventCenter:DispichEvent(FzEvent.InitFurniture) -- 重新加载
        self:updatePlayer()
        self:setFriendHomeView(false)
    end
    back_btn:onTouch(function(e)  -- 回自己家
        if e.name == "ended" then
            goBackHome()
        end
    end)
    MyApp:pushTopCloseLayer("FriendHomeLayer",function()
        goBackHome()
        MyApp:popTopCloseLayer("FriendHomeLayer")
    end)
    -- 左下UI
    -- 这里需要进行判断 是否有填坑者 显示头像
    local SalePlayer_Headkuang = mainui.Node_bottomleft_friend:getChildByName("sImage_headkuang")   -- 填坑者头像框
    local SalePlayer_Head = mainui.Node_bottomleft_friend:getChildByName("sImage_saleman")          -- 填坑者头像

    local Msg_SaleData = FriendData.Home_MsgData.food_sale
    if Msg_SaleData and table.nums(Msg_SaleData)>0 and Msg_SaleData.icon then
        SalePlayer_Headkuang:show()
        SalePlayer_Head:show()
        SalePlayer_Head:loadTexture(IconPath.PetHeadIcon( Msg_SaleData.icon ))
    else
        SalePlayer_Headkuang:hide()
        SalePlayer_Head:hide()
    end
    
    local Sale_Btn = mainui.Node_bottomleft_friend:getChildByName("sButton_sale")              -- 代售按钮
    local Song_Btn = mainui.Node_bottomleft_friend:getChildByName("sButton_give")              -- 赠送按钮
    Sale_Btn:onTouch(function(e) -- 代售按钮
        if e.name == "ended" then
            local CashData = FriendData:getFriendTeamData(1)
            if CashData then
                local SaleLayer = FriendSaleLayer.new()
                self:addChild(SaleLayer,localZOrder)
            else
                MoveMessage.show(Language.friend.friend_not_open)
            end
        end
    end)
    Song_Btn:onTouch(function(e) -- 赠送按钮
        if e.name == "ended" then
            local CashData = FriendData:getFriendTeamData(1)
            if CashData then
                local SongLayer = FriendSongLayer.new()
                self:addChild(SongLayer,localZOrder)
            else
                MoveMessage.show(Language.friend.friend_not_open)
            end
        end
    end)
    --- 右边UI 
    local WallEye_CheckBox = mainui.Image_showwall:getChildByName("CheckBox_show")
    local WallTxt_CheckBox = mainui.Image_showwall:getChildByName("CheckBox_word")
	WallEye_CheckBox:ignoreContentAdaptWithSize(true)
    WallTxt_CheckBox:ignoreContentAdaptWithSize(true)
    WallEye_CheckBox:setTouchEnabled(false)
    WallTxt_CheckBox:setTouchEnabled(false)
    if Wall_Look_Key then
        WallEye_CheckBox:setSelected(false)
        WallTxt_CheckBox:setSelected(false)
    else
        WallEye_CheckBox:setSelected(true)
        WallTxt_CheckBox:setSelected(true)
    end
    mainui.Image_showwall:setTouchEnabled(true)
    mainui.Image_showwall:onTouch(function(e)            -- show and hide 前墙
        if e.name == "ended" then
            CTTileData.CircleNode:Clean()
            if Wall_Look_Key then
                CTWallData:SetDownWallLook(false)
                Wall_Look_Key = false
                WallEye_CheckBox:setSelected(true)
                WallTxt_CheckBox:setSelected(true)
            else
                CTWallData:SetDownWallLook(true)
                Wall_Look_Key = true
                WallEye_CheckBox:setSelected(false)
                WallTxt_CheckBox:setSelected(false)
            end
        end
    end)
    local HjNum_CheckBox = mainui.Image_showenvironment:getChildByName("CheckBox_show")
    local HjTxt_CheckBox = mainui.Image_showenvironment:getChildByName("CheckBox_word")
	HjNum_CheckBox:ignoreContentAdaptWithSize(true)
    HjTxt_CheckBox:ignoreContentAdaptWithSize(true)
    HjNum_CheckBox:setTouchEnabled(false)
    HjTxt_CheckBox:setTouchEnabled(false)
    if Hj_Look_Key then
        CTTileData:ShowNatureFor(2)
        HjNum_CheckBox:setSelected(false)
        HjTxt_CheckBox:setSelected(false)
    else
        CTTileData:ShowNatureFor(-2)
        HjNum_CheckBox:setSelected(true)
        HjTxt_CheckBox:setSelected(true)
    end
    mainui.Image_showenvironment:setTouchEnabled(true)
    mainui.Image_showenvironment:onTouch(function(e)     -- show and hide 环境
        if e.name == "ended" then
            if Hj_Look_Key then
                Hj_Look_Key = false
                CTTileData:ShowNatureFor(-2)
                HjNum_CheckBox:setSelected(true)
                HjTxt_CheckBox:setSelected(true)
            else
                Hj_Look_Key = true
                CTTileData:ShowNatureFor(2)
                HjNum_CheckBox:setSelected(false)
                HjTxt_CheckBox:setSelected(false)
            end
            CTTileData.Hj_Look_Key = Hj_Look_Key
        end
    end)
    -----------------------------------------------------
    local SsNum_CheckBox = mainui.Image_showcomfort:getChildByName("CheckBox_show")
    local SsTxt_CheckBox = mainui.Image_showcomfort:getChildByName("CheckBox_word")
	SsNum_CheckBox:ignoreContentAdaptWithSize(true)
    SsTxt_CheckBox:ignoreContentAdaptWithSize(true)
    SsNum_CheckBox:setTouchEnabled(false)
    SsTxt_CheckBox:setTouchEnabled(false)
    if Ss_Look_Key then
        CTTileData:ShowNatureFor(1)
        SsNum_CheckBox:setSelected(false)
        SsTxt_CheckBox:setSelected(false)
    else
        CTTileData:ShowNatureFor(-1)
        SsNum_CheckBox:setSelected(true)
        SsTxt_CheckBox:setSelected(true)
    end
    mainui.Image_showcomfort:setTouchEnabled(true)
    mainui.Image_showcomfort:onTouch(function(e)         -- show and hide 舒适
        if e.name == "ended" then
            if Ss_Look_Key then
                Ss_Look_Key = false
                CTTileData:ShowNatureFor(-1)
                SsNum_CheckBox:setSelected(true)
                SsTxt_CheckBox:setSelected(true)
            else
                Ss_Look_Key = true
                CTTileData:ShowNatureFor(1)
                SsNum_CheckBox:setSelected(false)
                SsTxt_CheckBox:setSelected(false)
            end
            CTTileData.Ss_Look_Key = Ss_Look_Key
        end
    end)
end
function HomeScene:setFriendHomeView(visb)
    -- 好友
    self.mainui.Node_top_friendl:setVisible(visb == true)
    self.mainui.Node_top_friendr:setVisible(visb == true)
    self.mainui.Node_bottom_friend:setVisible(visb == true)
    self.mainui.Node_right_friend:setVisible(visb == true)
    self.mainui.Node_bottomleft_friend:setVisible(visb == true)
    if visb then
        self:setOnFriendUI()
    end
    -- 主界面相关
    self:setMainMissionVisible(visb == false)
    self.mainui.Node_top_l:setVisible(visb == false)
    self.mainui.Node_top_r:setVisible(visb == false)
    self.mainui.Node_bottom_r:setVisible(visb == false)
    self.mainui.Node_bottom_l:setVisible(visb == false)
    self.mainui.Node_bottom_middle:setVisible(visb == false)
end
function HomeScene:setUpBtnFriend(visb)
    self.mainui.Node_bottom_friend:setVisible(visb)
end
--】】好友相关
--二级菜显示
function HomeScene:SecondMeunShow(second_type)
    local show_key = false -- 是否显示 隐藏所有按钮的按钮 的条件！
    secondMoveing = true
    local bottomTime = 0
    if second_type then
        local hideSecondType = second_type == RUNTYPE and MANADGETYPE or RUNTYPE
        local updateMoveTime = moveTime
        if self.secondMenuShowState[hideSecondType] then
            self.secondMenuShowState[hideSecondType] = false
            updateMoveTime = moveTime-moveTime
            for _index,_button in ipairs(self.secondMeun[hideSecondType]) do
                if _index > 1 then
                    local posy = _index == 1 and firstBtnDefaultPosy or btnDefaultPosy
                    transition.moveTo(_button,{time=updateMoveTime,y=posy-moveDistance})
                end
            end
        end
        local isShow = self.secondMenuShowState[second_type]
        for _index,_button in ipairs(self.secondMeun[second_type]) do
            local posy = _index == 1 and firstBtnDefaultPosy or btnDefaultPosy
            -- print("====posy:".._index.." "..posy)
            if isShow then
                transition.moveTo(_button,{time=updateMoveTime,y=posy})
            else
                transition.moveTo(_button,{time=updateMoveTime,y=posy-moveDistance})
                show_key = true
            end
        end
        bottomTime = updateMoveTime
    else
        for _type,_buttons in pairs(self.secondMeun) do
            local isShow = self.secondMenuShowState[_type]
            self.secondMenuShowState[_type] = false
            for _index,_button in ipairs(_buttons) do
                local posy = _index == 1 and firstBtnDefaultPosy or btnDefaultPosy
                if isShow then
                    transition.moveTo(_button,{time=moveTime-moveTime,y=posy})
                else
                    transition.moveTo(_button,{time=moveTime-moveTime,y=posy-moveDistance})
                    show_key = true
                end
            end
        end
    end

    transition.moveBy(self.mainui.bottom,{x=0,y=0,time = bottomTime,onComplete=function()
        secondMoveing = false
    end}) 
    if show_key and not self.furnitureLayer then
        self.HideAll_Btn:show()
        self.ShowAll_Btn:hide()
    else
        self.HideAll_Btn:hide()
        self.ShowAll_Btn:hide()
    end
end

function HomeScene:showPreView()
    if self and self.furnitureLayer then
        self:resumeEventListener()
    end
end

function HomeScene:hidePreView()
    if self and self.furnitureLayer then
        self.furnitureLayer:exitPreViewState()
    end
end

function HomeScene:closeFurnitureLayer()
    if self.furnitureLayer then
        self.furnitureLayer:removeSelf()
        self.furnitureLayer = nil
    end
    if self.DressUpLayer then
        self.DressUpLayer:removeSelf()
        self.DressUpLayer = nil
    end
    self:onlyShowMap(false)
    FzSound.PlayBgmForMain(true)
    if not self:getManageBtnPos() then
        self.HideAll_Btn:show()
        self.ShowAll_Btn:hide()
    else
        self.HideAll_Btn:hide()
        self.ShowAll_Btn:hide()
    end

    self:setAssignChapterNodeShowState(true)
end
function HomeScene:resumeEventListener()
    if self and self.map then
        self.map:resumeEventListener()
    end
    
end
function HomeScene:pauseEventListener()
    if self and self.map then
        self.map:pauseEventListener()
    end
end

--红点
--[[
    @param red_type int 红点类型:(1:任务；2:菜谱；3:礼包；4:活动；5:市场)
    Define.Home_RedPoint_Type = {
        MISSION_REDPOINT = 1,
        MENU_REDPOINT = 2,
        PRESENT_REDPOINT = 3,
        ACTIVITY_REDPOINT = 4,
        MARKET_REDPOINT = 5,
    }
]]
function HomeScene:updateRedPoint(red_type)
    if self then
        local isCheckAll= false
        if red_type == nil then
            isCheckAll = true
            red_type = Define.Home_RedPoint_Type.MISSION_REDPOINT
        end
        if red_type == Define.Home_RedPoint_Type.MISSION_REDPOINT then
            local missionRedPoint = MissionData:checkRedPoint()
            self.mainui.Image_mission_tip:setVisible(missionRedPoint)
            red_type = isCheckAll and Define.Home_RedPoint_Type.MENU_REDPOINT or red_type
        end

        if red_type == Define.Home_RedPoint_Type.MENU_REDPOINT then
            local menuRedPoint = MenuData:checkRedPoint()
            self.mainui.Image_menu_tip:setVisible(menuRedPoint)
            red_type = isCheckAll and Define.Home_RedPoint_Type.PRESENT_REDPOINT or red_type
        end

        if red_type == Define.Home_RedPoint_Type.PRESENT_REDPOINT then
            local presentRedPoint = DyPersent:checkRedPoint()
            self.mainui.Image_present_tip:setVisible(presentRedPoint)
            red_type = isCheckAll and Define.Home_RedPoint_Type.ACTIVITY_REDPOINT or red_type
        end

        if red_type == Define.Home_RedPoint_Type.ACTIVITY_REDPOINT then
            -- self.mainui.Image_activity_tip:setVisible(activityRedPoint)
            if isCheckActivityTx then
                local activityRedPoint = DyActivity:checkRedPoint()
                self.activityTX:setVisible(activityRedPoint)
            end
            red_type = isCheckAll and Define.Home_RedPoint_Type.MARKET_REDPOINT or red_type
        elseif red_type == Define.Home_RedPoint_Type.MARKET_REDPOINT then
             self:updateMarketRedPoint() 
        end
    end
end
function HomeScene:updateHomeFriendRedPoint()
    if self then
        local friend_red_point = self.mainui.Button_friend:getChildByName("Image_friend_tip") -- 好友红点 
        friend_red_point:setVisible(FriendData:checkHomeSceneRedPoint())
        --
        if FriendData.On_FriendData then
            local friendgold_btn = self.mainui.Node_top_friendr:getChildByName("Button_friendgold") -- 送友情点
            local is_send_friend_point = FriendData.On_FriendData.is_send_friend_point
            friendgold_btn:setTouchEnabled(is_send_friend_point == 0)
            friendgold_btn:setBright(is_send_friend_point == 0)
        end
    end
end
function HomeScene:PlayMainSceneBgm()
    local guide = RoleData.player_info.guide
    if guide==0 then
        FzSound.ChangeMusic(FzSound.music.bgm_guide)
    else
        FzSound.PlayBgmForMain(true)
    end
end
-- ************************** -- 
-- **地图加载后回调检查引导** -- 
-- ************************** -- 
function HomeScene:MapEnterFinish() -- 地图加载完成后调用
    if use_guide then
        RoleData.player_info.guide = 10000
    end
    -- startChilderCount = self:getChildrenCount()
    local guide = RoleData.player_info.guide
    if RoleData.First_Login then
        RoleData.First_Login = false
        print("第一次跳转主界面！！！发送开店")
        A_star.Change_Scene_Key = nil
        self.Open_Guide_Level = true
        self:CheckGuideOnHome(true) -- 检查引导
        if guide>=10000 then
            local GonggaoLayer = GonggaoLayer.new()
            display.getRunningScene():addChild(GonggaoLayer,99999)
        end
		print("发送 离线奖励 请求~~~")
        SDKCenter:inHomeScene() -- IOS需要使用,Android没有此接口
        NetEngine:sendMessage(game_cmd.COfflineReward) -- 离线奖励 放最后发
    end
    self:PlayMainSceneBgm() -- 根据新手引导值 
end
-- 进入一个场景后发送的消息放在这个方法里，不然会导致WaitingLayer自动移除变为野指针。。
function HomeScene:onEnterTransitionFinish()
    if self and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        performWithDelay(self, function ()
            -- 点击登入界面，进入loading界面时，播放经理ID的配音
            local petId = PetManagerData:getCashID()
            if petId then
               	FzSound.PlayJapanPetSound(petId,"login")
            end
        end,0.3)
    end
end
function HomeScene:CheckGuideOnHome(First_Login)
    local guide = RoleData.player_info.guide
    local ct_level = RoleData.player_info.ct_level
    if ct_level>1 and guide == CTGuideManage.UpLevel_Guide then
        if not self.Open_Guide_Level then
            MoveMessage.show(Language.new_handing)
            return
        end
        self.Open_Guide_Level = nil
        local story_id = 1002 --新手引导 剧情ID
        local function callfunc() CTGuideManage:checkGuide(First_Login) end
        StoryNode:showStory(story_id,callfunc,99)-- 检查引导
    elseif First_Login then
        CTGuideManage:checkGuide(First_Login)
    elseif not First_Login and ct_level>=3 and ct_level<=5 then -- 升级软引导
        CTGuideManage:checkRuanGuide()
    end
end

function HomeScene:checkStory(param)
    -- if self then
    --     -- local storys = StoryData:getStroyIdScene(StoryData.MAIN_SCENE)
    --     -- if storys[param.story_id] then
    --     --     -- local childs = self:getChildrenCount()
    --     --     -- if childs ~= startChilderCount then         --如果不是在主场景不触发(小人头像也没有感叹号)
    --     --     --     return true
    --     --     -- end
    --     --     if storys[param.story_id].id == param.story_id then
    --     --         if StoryNode.last_npc_id and StoryNode.last_npc_id > 0 then
    --     --         else
    --     --             StoryNode.last_npc_id = param.npc_id
    --     --             StoryData:removeScneStoryById(param.story_id,StoryData.MAIN_SCENE)
    --     --             StoryNode:showStory(param.story_id)
    --     --         end
    --     --     end

    --     --     return true
    --     -- end
    -- end
    return false
end

function HomeScene:updateMainMissionCell(mission_class)
    if self then
        local isAllCheck = mission_class == nil and true or false
        mission_class = mission_class or MissionData.MISSION_TYPE_MAIN
        if mission_class == MissionData.MISSION_TYPE_MAIN then
            local mainMissionData = MissionData.mainMissionData
            local notGetMainData = nil
            if mainMissionData then
                for _index,_mission_data in pairs(mainMissionData) do
                    if _mission_data.is_get == 0 then
                        notGetMainData = _mission_data
                        break
                    end
                end
            end
            if notGetMainData then
                if not self.mainMission then
                    local cell = FZutil.createCellNode("MissionUI/Node_mission_tip")
                    -- cell.root:setPosition(display.cx,display.height-120)
                    -- self:addChild(cell.root)
                    self.MainMissionRoot:addChild(cell.root)

                    cell.Image_bg1:setTouchEnabled(true)
                    cell.Image_bg1:onTouch(function(e)
                        if e.name == "ended" then
                            local guide = RoleData.player_info.guide
                            if guide<CTGuideManage.UpLevel_Guide then
                                return
                            end
                            self:TouchOpenMission()
                        end
                    end)
                    cell.Text_jindu1_M:getVirtualRenderer():setAdditionalKerning(0)
                    cell.Text_gang_M:getVirtualRenderer():setAdditionalKerning(0)
                    cell.Text_jindu2_M:getVirtualRenderer():setAdditionalKerning(0)
                    cell.Image_jumpto1:hide()
                    cell.Image_finish = cell.root:getChildByTag(261)
                    self.mainMission = cell
                end
                local missioncfg = ConfigData.st_mission[notGetMainData.mission_id]
                local plan = MissionData:getFinishPlan(missioncfg.type_id,missioncfg.param2)
                local cur_plan = notGetMainData.cur_plan
                local loadPercent = (cur_plan/plan)*100
                if loadPercent >= 100 and plan == 1 then
                    cur_plan = plan
                end

                self.mainMission.Text_desc:setString(missioncfg.mission_desc)
                self.mainMission.Text_jindu1_M:setString("("..cur_plan)
                self.mainMission.Text_jindu2_M:setString(plan..")")
                local is_finsh = notGetMainData.is_finsh == 1 and true or false
                self.mainMission.Image_jumpto:setVisible(is_finsh==false)
                self.mainMission.Image_finish:setVisible(is_finsh)
                self.mainMission.root:show()
            else
                if self.mainMission then
                    self.mainMission.root:removeSelf()
                    self.mainMission = nil
                end
            end
            mission_class = isAllCheck and MissionData.MISSION_TYPE_ECHIE or MissionData.MISSION_TYPE_MAIN
        end
        
        if mission_class == MissionData.MISSION_TYPE_ECHIE then
            self:updateAchievementMissionCell()
        end
    end
end

function HomeScene:updateAchievementMissionCell()
    local achievementData = MissionData.achievesData
    local notGetAchievementData = nil
    self.notGetAchievementData = nil
    for _index,_achievement_data in pairs(achievementData) do
        if _achievement_data.group_id == 101 then
            for _idx,_mission_data in pairs(_achievement_data.Mission) do
                if not notGetAchievementData then
                    notGetAchievementData = _mission_data
                end
                if notGetAchievementData.is_finsh == 1 then
                    if notGetAchievementData.is_get == 0 then
                        break
                    end
                    notGetAchievementData = nil
                else
                    break
                end
            end
        end 
    end
    self.notGetAchievementData = notGetAchievementData
    
    if notGetAchievementData then
        if not self.achievementMission then
            local cell = FZutil.createCellNode("MissionUI/Node_achievement_tip")
            -- cell.root:setPosition(display.cx+320,display.height-120)
            -- self:addChild(cell.root)
            cell.root:setPositionX(320)
            self.MainMissionRoot:addChild(cell.root)

            cell.Text_achievenum:setLocalZOrder(1)
            local kuangImg = cell.Image_achievementkuang
            local progressTimer = cc.ProgressTimer:create(cc.Sprite:create("UI/missionUI/ZJM_chengjiu01.png"))
            progressTimer:setPosition(kuangImg:getPosition(progressTimer))
            progressTimer:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
            kuangImg:getParent():addChild(progressTimer)
            kuangImg:removeSelf()
            cell.Image_achievementkuang = nil
            cell.Image_achievementkuang = progressTimer

            cell.Image_achievement:setTouchEnabled(true)
            cell.Image_rewardkuang:setTouchEnabled(true)
            cell.Image_achievement:onTouch(function(e)
                if e.name == "ended" then
                    local guide = RoleData.player_info.guide
                    if guide<CTGuideManage.UpLevel_Guide then
                        return
                    end
                    self:TouchOpenMission(MissionData.MISSION_TYPE_ECHIE)
                end
            end)
            cell.Image_rewardkuang:onTouch(function(e)
                if e.name == "ended" then
                    if self.notGetAchievementData then
                        print("获取任务奖励")
                        NetEngine:sendMessage(game_cmd.CGiveMission,{mission_class=self.notGetAchievementData.mission_class,mission_id=self.notGetAchievementData.mission_id})
                    end
                end 
            end)
            self.achievementMission = cell
        end
        self.achievementMission.root:show()
        local is_finsh = notGetAchievementData.is_finsh == 1 and true or false
        self.achievementMission.Image_achievement:setVisible(is_finsh==false)
        self.achievementMission.Image_rewardkuang:setVisible(is_finsh)
        self.achievementMission.TX_menu_clickable:setVisible(is_finsh)
        local missioncfg = ConfigData.st_mission[notGetAchievementData.mission_id]
        if is_finsh then
            local rewardcfg = ConfigData.st_reward[missioncfg.reward_id]
            for _index,_reward_cfg in ipairs(rewardcfg) do
                if _reward_cfg then
                    local reward_data = RewardTip.getRewardConfigData(_reward_cfg.reward_type,_reward_cfg.item_id)
                    self.achievementMission.Image_reward:loadTexture(reward_data.iconImg)
                    self.achievementMission.Text_rewardnum:setString("x".._reward_cfg.number)
                    break
                end
            end
        else
            local plan = missioncfg.param2
            if missioncfg.type_id == 11 then
                plan = 1
            end
            local loadPercent = (notGetAchievementData.cur_plan/plan)*100

            self.achievementMission.Image_achievementkuang:runAction(cc.ProgressTo:create(1, loadPercent))
            self.achievementMission.Text_achievenum:setString("x"..missioncfg.param2)
        end
    else
        if self.achievementMission then
            self.achievementMission.root:removeSelf()
            self.achievementMission = nil
        end
    end
end

function HomeScene:setMainMissionVisible(visb)
    if visb then
        self.MainMissionRoot:show()
    else
        self.MainMissionRoot:hide()
    end
end
-- [[隐藏周围所有按钮（方便截图.....）
function HomeScene:setAllBtnVisible(visb)
    local mainui = self.mainui
    if visb then
        mainui.Node_bottom_l:show() -- 左下角
        mainui.Node_top_l:show() -- 左上
        mainui.Node_bottom_r:show() -- 右下
        mainui.Node_top_r:show() -- 右上
        self.HideAll_Btn:show()
        self.ShowAll_Btn:hide()
    else
        mainui.Node_bottom_l:hide() -- 左下角
        mainui.Node_top_l:hide() -- 左上
        mainui.Node_bottom_r:hide() -- 右下
        mainui.Node_top_r:hide() -- 右上
        self.HideAll_Btn:hide() -- 点击按钮
        self.ShowAll_Btn:show()
    end
    -- self:setMainMissionVisible(visb)
end
function HomeScene:initHideAllBtn()
    self.HideAll_Btn:onTouch(function(e)
        if e.name == "ended" then
            self:setAllBtnVisible(false)
            -- 创建触摸层 显示按钮
            self.HideAll_Btn:hide()
            self.ShowAll_Btn:show()
        end
    end)
    self.ShowAll_Btn:onTouch(function(e)
        if e.name == "ended" then
            self:setAllBtnVisible(true)
            -- 创建触摸层 显示按钮
            self.HideAll_Btn:show()
            self.ShowAll_Btn:hide()
        end
    end)
end
-- ]] 隐藏周围所有按钮（方便截图.....）
-- [[主界面聊天红点
function HomeScene:addChatRedPoint(visb)
    local Button_chat = self.mainui.Node_top_r:getChildByName("Button_chat")
    local redPoint = Button_chat:getChildByName("Image_hongdian")
    if not visb then
        redPoint:show()
    else
        redPoint:hide()
    end
end
--]]主界面聊天红点
-- 主界面 VIP 顾客结算提示
function HomeScene:addGukeVipLayer()
    if self.GukeVipLayer and not tolua.isnull(self.GukeVipLayer) then
        self.GukeVipLayer:removeSelf()
        self.GukeVipLayer = nil
    end
    if self then
        self.GukeVipLayer = GukeVipTipLayer.new()
        self:addChild(self.GukeVipLayer, 10)
    end
end 

-----------------------------限定章节--------------------------------
function HomeScene:japanInitAssignChapter()
    local active_id = DyActivity:isActivityOpen( DyActivity.ASSIGN_CHAPTER )
    if active_id ~= false then
        local assignChapterNode = FZutil.createSceneNode("JapanUI/Node_agg_JP")
        assignChapterNode.root:setPosition(245, display.height-200)
        self.mainui.root:addChild(assignChapterNode.root,localZOrder)
        self.assignChapterNode = assignChapterNode

        DyActivity:checkAndLoadJson( active_id , function(act_json)
            local act_json = DyActivity:getJsonData( active_id )
            local jsonHeader = act_json.header
            local jsonBody = act_json.body

            if jsonHeader then
                if jsonHeader.iconID then
                    local iconID = tonumber(jsonHeader.iconID)
                    assignChapterNode.Image_aicon:loadTexture(IconPath.activityAssignChapterBgImg(iconID))
                end
            end

            assignChapterNode.Image_bg:setTouchEnabled(true)
            assignChapterNode.Image_bg:setSwallowTouches(true)
            assignChapterNode.Image_bg:onTouch(function(e)
                if e.name == "ended" then
                    local rewardTimes = DyActivity:isOnlyGetReward(active_id,jsonBody.activeday)
                    if rewardTimes > 0 then
                        local rankLayer = CTRankLayer.new("ept")
                        self:addChild(rankLayer,localZOrder)
                    else
                        local activityLayer = ActivityLayer.new(DyActivity.ASSIGN_CHAPTER)
                        self:addChild(activityLayer,localZOrder)
                    end
                end
            end)

            local last_time = jsonHeader.startTime + jsonHeader.duration * 60 * 60 * 24
            local down_time = DyActivity:getActivityTimeLeftTime(last_time)
            if down_time > 0 then
                self:createRemoveAssignChapterDownTime(assignChapterNode.root,down_time)
            end
        end)
    end
end

function HomeScene:createRemoveAssignChapterDownTime(node,down_time)
    performWithDelay(node, function()
        if node then
            node:removeSelf()
        end
        self.assignChapterNode = nil
    end, down_time)
end

function HomeScene:setAssignChapterNodeShowState(show_state)
    if self.assignChapterNode then
        self.assignChapterNode.root:setVisible(show_state)
    end
end

---------------------------------------------------------------------

function HomeScene:onEnter()
	print("进入格子餐厅")
    CTJianBaoData:initToHomeScene(self)
    FzEventCenter:RegisterEvent(FzEvent.resumeEventListener,self,self.resumeEventListener)
    FzEventCenter:RegisterEvent(FzEvent.pauseEventListener,self,self.pauseEventListener)
    FzEventCenter:RegisterEvent(FzEvent.showPreViewLayer,self,self.showPreView)
    FzEventCenter:RegisterEvent(FzEvent.hidePreViewLayer,self,self.hidePreView)
    FzEventCenter:RegisterEvent(FzEvent.closeFurnitureLayer,self,self.closeFurnitureLayer)
    FzEventCenter:RegisterEvent(FzEvent.OpenFurnitureForDressUpLayer,self,self.OpenFurnitureForDressUpLayer)
    FzEventCenter:RegisterEvent(FzEvent.OpenDressUpLayerForFurniture,self,self.OpenDressUpLayerForFurniture)
    FzEventCenter:RegisterEvent(FzEvent.updatePlayer,self,self.updatePlayer)
    FzEventCenter:RegisterEvent(FzEvent.updatePersonHot,self,self.updatePersonHot)
    FzEventCenter:RegisterEvent(FzEvent.MapEnterFinish,self,self.MapEnterFinish)
    FzEventCenter:RegisterEvent(FzEvent.CheckGuideOnHome,self,self.CheckGuideOnHome)
    FzEventCenter:RegisterEvent(FzEvent.UpdateMianSceneRedPoint,self,self.updateRedPoint)
    FzEventCenter:RegisterEvent(FzEvent.checkAutoActiveStory, self, self.checkStory)
    FzEventCenter:RegisterEvent(FzEvent.updateHomeMainMission, self, self.updateMainMissionCell)
    FzEventCenter:RegisterEvent(FzEvent.updataExpTx, self, self.updataExpTx)
    FzEventCenter:RegisterEvent(FzEvent.setFriendHomeView, self, self.setFriendHomeView)
    FzEventCenter:RegisterEvent(FzEvent.updateHomeFriendRedPoint, self, self.updateHomeFriendRedPoint)
    FzEventCenter:RegisterEvent(FzEvent.setMainMissionVisible, self, self.setMainMissionVisible)
    FzEventCenter:RegisterEvent(FzEvent.addChatRedPoint, self, self.addChatRedPoint)
    FzEventCenter:RegisterEvent(FzEvent.addGukeVipLayer, self, self.addGukeVipLayer)

    if SDKCenter and RoleData and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        local player=RoleData.player_info
        SDKCenter:setUserInfo( player.name, player.level, 8)
    end
    print("player_id :"..RoleData.player_info.player_id)
end
function HomeScene:onExit()
	print("退出格子餐厅")
    CTJianBaoData:initToHomeScene(nil)
    A_star.Change_Scene_Key = RoleData.player_info.ct_level
    CTSearchCenter:CloseSearchPath()
    CTWallData:CleanWallData()
    CTTileData:CleanAllMapProp()
    FzEventCenter:RemoveEvent(FzEvent.resumeEventListener,self)
    FzEventCenter:RemoveEvent(FzEvent.pauseEventListener,self)
    FzEventCenter:RemoveEvent(FzEvent.showPreViewLayer,self)
    FzEventCenter:RemoveEvent(FzEvent.hidePreViewLayer,self)
    FzEventCenter:RemoveEvent(FzEvent.closeFurnitureLayer,self)
    FzEventCenter:RemoveEvent(FzEvent.OpenFurnitureForDressUpLayer,self)
    FzEventCenter:RemoveEvent(FzEvent.OpenDressUpLayerForFurniture,self)
    FzEventCenter:RemoveEvent(FzEvent.updatePersonHot,self)
    FzEventCenter:RemoveEvent(FzEvent.updatePlayer,self)
    FzEventCenter:RemoveEvent(FzEvent.MapEnterFinish,self)
    FzEventCenter:RemoveEvent(FzEvent.CheckGuideOnHome,self)
    FzEventCenter:RemoveEvent(FzEvent.UpdateMianSceneRedPoint,self)
    FzEventCenter:RemoveEvent(FzEvent.checkAutoActiveStory,self)
    FzEventCenter:RemoveEvent(FzEvent.updateHomeMainMission,self)
    FzEventCenter:RemoveEvent(FzEvent.updataExpTx,self)
    FzEventCenter:RemoveEvent(FzEvent.setFriendHomeView,self)
    FzEventCenter:RemoveEvent(FzEvent.updateHomeFriendRedPoint,self)
    FzEventCenter:RemoveEvent(FzEvent.setMainMissionVisible,self)
    FzEventCenter:RemoveEvent(FzEvent.addChatRedPoint,self)
    FzEventCenter:RemoveEvent(FzEvent.addGukeVipLayer,self)

    if self.map then
        self.map:removeSelf()
    end
    MainMapListener:removeMoveMap()
    TileMapListener:removeEventListen()
end
return HomeScene
