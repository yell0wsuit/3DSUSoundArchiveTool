local luaExtend = require "LuaExtend.lua"
local filter=require("packages.filter")
local FZutil={}

local function setAllTextOutLine(node,LineKey)
    if node then
        local nodes=node:getChildren()
        local type_=tolua.type(node)
        local name=node:getName()
        local name_last = string.sub(name,-2)
        local fontStr = FZutil.getFontString()
        if FZ_COUNTRY and FZ_COUNTRY ~= "China" and FZ_COUNTRY ~= "Japan"then
            if type_ == "ccui.Text" or type_ == "ccui.TextField" then
                node:setFontName(fontStr)
            elseif type_ == "ccui.Button" then
                node:setTitleFontName(fontStr)
            end
        end
        if not LineKey then
            if ((type_ == "ccui.Text") or (type_ == "cc.Label"))
                and ((name_last=="_N") or (name_last =="_M")) then
                if not (name_last == "_M") then
                    node:enableOutline(cc.c4b(0,0,0,255),2)
                end
                if type_ == "ccui.Text" then
                    node:getVirtualRenderer():setAdditionalKerning(-4)
                else    
                    node:setAdditionalKerning(-4)
                end
            end
        end

        -- if type_ == "ccui.ImageView" then
        --     if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        --         -- local imgSz = node:getContentSize()
        --         -- if imgSz.width == 1200 and imgSz.height == 800 then
        --         local parent = node:getParent()
        --         while parent do
        --             if parent then
        --                 local parentScaleSz = parent:getScale()
        --                 if parentScaleSz ~= 1 then
        --                     node:setScale(parentScaleSz)
        --                 end
        --             end
        --             parent = parent:getParent()
        --         end
                
        --         local scaleSz = node:getScale()
        --         node:ignoreContentAdaptWithSize(true)    --忽略内容调整大小(背景底图)
        --         node:setScale(scaleSz)
        --         -- end
        --     end
        -- end

        -- if type_ == "ccui.Button" or type_ == "ccui.CheckBox" then
        --    FZutil.ignoreContentSizeImg(node,"Japan")
        -- elseif type_ == "ccui.ImageView" then
        --     -- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        --         local imgSz = node:getContentSize()
        --         if imgSz.width == 1200 and imgSz.height == 800 then
        --             node:ignoreContentAdaptWithSize(true)    --忽略内容调整大小(背景底图)
        --         end
        --     -- end
        -- end
        
        for _, sub in ipairs(nodes) do
            setAllTextOutLine(sub)
        end
    end
end

local vsize=cc.Director:getInstance():getVisibleSize()

---读取cocos导出的lua文件，并设置布局，把节点里所有的文本加描边
--用于读取scene
--@param nodeName string cocos导出的lua文件的名字（不要".lua"）
--@return #table 节点容器，根节点为["root"]。。。注意，返回对象本身不是node
function FZutil.getFontString()
    local fontStr = "SIMHEI.TTF"
    if FZ_COUNTRY and FZ_COUNTRY == "Korea" then
        fontStr = "MALGUN.TTF"
    end
    return fontStr
end
function FZutil.createSceneNode(nodeName)
--    local nd=cc.CSLoader:createNode(nodeName..".csb")
--    nd:setContentSize(vsize)
--    ccui.Helper:doLayout(nd)
--    setAllTextOutLine(nd)
--    local ret={root=nd}
--    setmetatable(ret, luaExtend)
--    return ret
---
    print("createSceneNode begin"..nodeName)
    local nd=require(nodeName).create()
    nd.root:setContentSize(vsize)
    ccui.Helper:doLayout(nd.root)
    setAllTextOutLine(nd.root)
    if nd.animation then
        nd.root.animation=nd.animation
    end
    if nd.Node_center ~= nil then
        nd.Node_center:setPosition(display.center)
    end
    --解决SPINE动作崩溃的问题
    if device.platform=="ios" then
        local hero_id = 1000000
        local filepath=string.format("battle/PET%d/PET%d.json",hero_id,hero_id)
        local filepath1=string.format("battle/PET%d/PET%d.atlas",hero_id,hero_id)
        local mode=sp.SkeletonAnimation:create(filepath, filepath1, 1.0)
        nd.root:addChild(mode)        
    end
    print("createSceneNode end"..nodeName)

    return nd
end

function FZutil.createCCNode()
    local node = cc.Node:create()
    --解决SPINE动作崩溃的问题
    if device.platform=="ios" then
        local hero_id = 1000000
        local filepath=string.format("battle/PET%d/PET%d.json",hero_id,hero_id)
        local filepath1=string.format("battle/PET%d/PET%d.atlas",hero_id,hero_id)
        local mode=sp.SkeletonAnimation:create(filepath, filepath1, 1.0)
        node:addChild(mode)        
    end
    return node
end

function FZutil.createCellNode(nodeName)
--    local nd=cc.CSLoader:createNode(nodeName..".csb")
--    setAllTextOutLine(nd)
--    local ret={root=nd}
--    setmetatable(ret, luaExtend)
--    FZutil.changeRootNodeToWidget(ret)
--    return ret
---
    local nd=require(nodeName).create()
    setAllTextOutLine(nd.root)
    FZutil.changeRootNodeToWidget(nd)
    if nd.animation then
        nd.root.animation=nd.animation
    end
    return nd
end

--创建一个不自动描边的节点(也不会自动布局)
function FZutil.createNoneOutLineNode( nodeName )
    local nd=require(nodeName).create()
    setAllTextOutLine(nd.root,true)
    if nd.animation then
        nd.root.animation=nd.animation
    end
    return nd
end

---把一个cellmap里面的Root转化ccui.Widget类型
--@param cellmap table 含有node为Root的uimap
function FZutil.changeRootNodeToWidget(cellmap)
    local new_root=FZutil.changeNodeToWidget(cellmap.root)
    cellmap.root=new_root
end

---把cc.Node转化成ccui.Widget
--@param node cc.Node 要转化的节点
--@return #ccui.Widget 转化后的Widget
function FZutil.changeNodeToWidget(node)
    local parent=node:getParent()
    local children=node:getChildren()
    local widget=ccui.Widget:create()
    for _, ch in pairs(children) do
        FZutil.changeParent(ch,widget)
    end
    if parent then
        parent:addChild(widget)
        node:removeSelf()
    end
    return widget
end

function FZutil.createMap(rootnode)
    local ret={root=rootnode}
    setmetatable(ret, luaExtend)
    return ret
end

function FZutil.changeParent(ch,new_parent)
    ch:retain()
    ch:removeSelf()
    new_parent:addChild(ch)
    ch:release()
end

---把组件树里的所有文件都设置描边
-- @param node cc.node ui组件树的根
FZutil.setAllTextOutLine=setAllTextOutLine

---创建一个可以不会穿透点击事件的Layer
--@return #ccui.Layout 一个于屏幕等大的ccui.Layout,并且可以响应点击
function FZutil.createUILayer()
    local lay=ccui.Layout:create()
    lay:setTouchEnabled(true)
    lay:setContentSize(display.width,display.height)
    lay:setBackGroundColor(cc.c3b(0,0,0))
    lay:setBackGroundColorOpacity(math.floor(0.7*0xff))
    lay:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    return lay
end

---窗口打开特效
--@param eff_node cc.Node 执行特效的节点
function FZutil.windowShowEff(eff_node)
    FZutil.disableTouch()
    eff_node:setScale(0)
    transition.scaleTo(eff_node,{scale=1,time=0.3,easing="BACKOUT",onComplete=function()
        FZutil.enableTouch()
    end})
end

---窗口关闭特效（特效结束后移除节点）
--@param eff_node cc.Node 执行特效的节点
--@param remove_node cc.Node 移除的节点
--@param onComplete function 动作完成时的回调方法，可以为nil
function FZutil.windowEffCloseToRemove(eff_node,remove_node,onComplete)
    FZutil.disableTouch()
    local parama={scale=0,time=0.3,easing="BACKIN"}
    parama.onComplete=function()
       FZutil.enableTouch()
        if remove_node then
            remove_node:removeSelf()
        end
        if onComplete then
            onComplete()
        end
    end
    transition.scaleTo(eff_node,parama)
end

---释放缓存
function FZutil.clearCache()
    if FzFixCocosBug then 
        FzFixCocosBug.clearArmatureCache()
    end
    if device.platform=="windows" then
        cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        cc.FileUtils:getInstance():purgeCachedEntries()
    else
        cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        -- cc.Director:getInstance():purgeCachedData()
    end
end

---检查点是否在矩形里面
--@param p cc.point(x,y)
--@param box cc.rect(x,y,width,height)
--@return #boolean 是否
function FZutil.checkAABB(p,box)
    if p.x<box.x or p.x>box.x+box.width or p.y<box.y or p.y > box.y+box.height then
        return false
    end
    return true
end

--检查是否touch是否位于按钮上<br>
--touch:cc.Touch<br>
--btn:按钮node
function FZutil.checkBtnHit(touch,btn)
    local box=btn:getBoundingBox()
    local p=btn:getParent():convertTouchToNodeSpace(touch)
    return FZutil.checkAABB(p,box)
end

local callCount = 0

function FZutil.disableTouch()
    callCount = callCount + 1
    if callCount == 1 then
       cc.Director:getInstance():getEventDispatcher():setEnabled(false)
    end
    print("disable touch",callCount)
end

function FZutil.enableTouch()
    callCount = callCount - 1
    if callCount == 0 then
        cc.Director:getInstance():getEventDispatcher():setEnabled(true)
    end
    print("enable touch",callCount)
end

function FZutil.printHex(buf) --@return string
    local len=string.len(buf)
    local ret=""
    for i=1,len do
        local char_code=string.byte(buf,i,i+1)
        local temp=string.format("%02X",char_code)
        ret=ret..temp
    end
    return ret
end

function FZutil.HexToString(buf)
    local len=string.len(buf)
    local ret=""
    for i=1,len,2 do
        local byte=tonumber(string.sub(buf,i,i+1),16)
        ret=ret..string.char(byte)
    end
    return ret
end

function FZutil.printCallStack(startLevel,maxLevel)
    local startLevel = startLevel or 3 --0表示getinfo本身,1表示调用getinfo的函数(printCallStack),2表示调用printCallStack的函数,可以想象一个getinfo(0级)在顶的栈.
    local maxLevel = maxLevel or 10 --最大递归10层
    local ret="\n"

    for level = startLevel, maxLevel do
        -- 打印堆栈每一层
        local info = debug.getinfo( level, "nSl") 
        if info == nil then break end
        ret=ret .. string.format('[string "%s"]:%d: function: %s\n',info.source or "",info.currentline,info.name or "")

        -- 打印该层的参数与局部变量
        local index = 1 --1表示第一个参数或局部变量, 依次类推
        while true do
            local name, value = debug.getlocal( level, index )
            if name == nil then break end

            local valueType = type( value )
            local valueStr
            if valueType == 'string' then
                -- valueStr = FZutil.printHex(value)
                valueStr=value
            elseif valueType == "number" then
                valueStr = string.format("%.2f", value)
            else 
                valueStr = tostring(value)
            end
            ret=ret .. string.format( "\t%s = %s\n", name, valueStr ) 
            index = index + 1
        end
    end
    print(ret)
    return  ret
end

local function pauseAll(node)
    node:pause()
    local children=node:getChildren()
    for _, child in pairs(children) do
        pauseAll(child)
    end
end
FZutil.pauseAll=pauseAll

local function resumeAll(node)
    node:resume()
    local children=node:getChildren()
    for _, child in pairs(children) do
        resumeAll(child)
    end
end
FZutil.resumeAll=resumeAll

---
--发送日志
--@param err string 错误消息
--@param type int {1(普通错误);2(战斗日志);3(缺少资源或资源命名不正确)}
--@param level int 堆栈起始级别
function FZutil.send_log(err,type,level)
    assert(not (type==3 and DEBUG>=2),err)
    if REMOTE_LOG==0 then return end
    local level_ =level or 2
    local dinfo = debug.getinfo( level_, "nSl") 
    if dinfo then
        local source=dinfo.source or ""
        local line=dinfo.currentline or 0
        local function_name=dinfo.name or ""
        local log=function_name .. "\n" ..err
        local type_=type or 1
        local server_id = (RoleData and RoleData.server_id) or 0
        local player_id = (RoleData and RoleData.player_info.player_id) or 0
        local info=require("info")
        local FzFileUtils=FzFileUtils or require("app.public.FzFileUtils")
        local oinfo=require(FzFileUtils.getOriginInfoPath())
        if type_==2 then 
            source="a.txt"
            log=err 
        end
        
        local httpStr=string.format("server_id=%s&player_id=%d&platform=%d&code_file=%s&code_line=%d&log=%s&type=%d",
            server_id, player_id,info.platform,source,line,log,type_)
            
        local xhr = cc.XMLHttpRequest:new() -- http请求  
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING -- 响应类型  
        xhr:open("POST", oinfo.log_server) -- 打开链接  
        -- 状态改变时调用  
        local function onReadyStateChange() 
            local statusString = "Http Status Code:"..xhr.statusText 
            release_print(statusString)
            release_print(xhr.response)
        end  
        -- 注册脚本回调方法  
        xhr:registerScriptHandler(onReadyStateChange)  
        xhr:send(httpStr) -- 发送请求 
        -- 事件记录
        local paramas = {errcode = err}
        SDKCenter:setEventInfo(paramas,107)
    end
end

---根据checkbox创建一个使用同一贴图的灰色的sprite
--@param checkbox ccui.Checkbox checkbox控件
--@return #cc.Sprite 灰色的Sprite
function FZutil.createCheckBoxGraySprite( checkbox )
    local frame=checkbox:getVirtualRenderer():getSpriteFrame()
    local graySp=filter.newFilteredSprite(frame,"GRAY")
    return graySp
end

---新类型按钮封装
---@param button buttonCover callback
function FZutil.onButtonTouch(btn, btnCover, callback)
    btnCover:setVisible(false)    
    btn:onTouch(function(event)
        if event.name == "began" then
            btnCover:setVisible(true)
        elseif event.name == "cancelled" or event.name == "ended" then
            btnCover:setVisible(false)
            if event.name == "ended" then
                callback()
            end
        end 
    end)
end

function FZutil.onButtonTwoImagTouch(btn,btnNormal,btnCover,callback,isReturn)
    local setImagVisible = function(isNormal)
        btnNormal:setVisible(isNormal)
        btnCover:setVisible(isNormal == false)
    end
    setImagVisible(true)
    btn:onTouch(function(e)
        if e.name == "began" then
            setImagVisible(false)
        elseif e.name == "cancelled" then
            setImagVisible(true)
        elseif e.name == "ended" then
            setImagVisible(true)
            if isReturn ~= true and callback then
                callback(e)
            end
        end
        if isReturn and callback then
            callback(e)
        end
    end)
end

--Normal图片 Image_word1
--Cover图片  Image_word2
function FZutil.onButtonTwoImagTouchNormal(btn,callback,isReturn,normalName,coverName)
    normalName = normalName or "Image_word1"
    coverName = coverName or "Image_word2"
    local btnNormal = btn:getChildByName(normalName)
    local btnCover = btn:getChildByName(coverName)
    btnNormal:ignoreContentAdaptWithSize(true)
    btnCover:ignoreContentAdaptWithSize(true)
    FZutil.onButtonTwoImagTouch(btn,btnNormal,btnCover,callback,isReturn)
end

--两张图片点击切换
--@param normal image 未点击图片
--@param choose image 点击后图片
--@param state bool   点击状态(false:未点击,true:点击)
--@param callbacks table normal是未点击的回调时间,choose是点击的回调时间
function FZutil.onTwoTextureClick(normal,choose,state,callbacks)
    if not state then
        state = false
    end
    if not callbacks then
        callbacks = {}
    end

    normal:setVisible(state==false)
    choose:setVisible(state==true)

    normal:onTouch(function(e)
        if e.name == "ended" then
            choose:setVisible(true)
            normal:setVisible(false)
            if callbacks.normalCallBack then
                callbacks.normalCallBack()
            end
        end
    end)

    choose:onTouch(function(e)
        if e.name == "ended" then
            normal:setVisible(true)
            choose:setVisible(false)
            if callbacks.chooseCallBack then
                callbacks.chooseCallBack()
            end
        end
    end)
end

--长按事件
--@param target object 点击的目标对象
--@param callback table 事件回调(longPressCallback:长按时间回调,callback:点击事件回调)
--@param isSpeed bool 是个是加速度(只有长按有效)
--@param maxNum int 加速度增加和减少的数量最大值(默认是10)
--@param moveClear bool 移动是否取消长按时间
function FZutil.onTouchLongPressAdd(target,callbacks,dt,oneCallTime,isSpeed,maxNum,moveClear)
    if not callbacks then
        callbacks = {}
    end
    local schedule = cc.Director:getInstance():getScheduler()
    local timer = nil
    local onTouchTime = 0
    dt = dt or 0.1
    maxNum = maxNum or 10
    local speed = dt            --加速度
    oneCallTime = oneCallTime or 0.5
    local oneTime = oneCallTime       --执行长按回调函数的时间(超过该时间就认为是长按事件)
    local isLongPress = false
    target:onTouch(function(e)
        if e.name == "began" then
            if timer == nil then
                timer = schedule:scheduleScriptFunc(function()
                    onTouchTime = onTouchTime+dt
                    if onTouchTime>oneTime then
                        isLongPress = true
                        oneTime = oneCallTime
                        if callbacks.longPressCallback then
                            local num = 1
                            if isSpeed then
                                speed = speed+dt
                                if speed>=1 then
                                    speed = 1
                                end
                                num = math.floor(speed*maxNum)
                            end
                            callbacks.longPressCallback(num)
                        end
                    end
                end, dt,false)
            end
            if callbacks.eventback then
                callbacks.eventback(e,isLongPress)
            end
        else
            if not moveClear and e.name == "moved" then
                return
            end
            if timer~=nil then
                schedule:unscheduleScriptEntry(timer)
                timer = nil
            end
            if e.name == "ended" and isLongPress == false then
                if callbacks.callback then
                    callbacks.callback()
                end
            end
            if callbacks.eventback then
                callbacks.eventback(e,isLongPress)
            end
            onTouchTime = 0
            oneTime = oneCallTime
            isLongPress = false
            speed = dt
        end
    end)
end
--RichText 获得宽度 需要延迟获取 焦点0.5,0.5
function FZutil.getColorTxt(text, colors, delimiters, fontsize, richW, ziti, callback)
    if not text then
        return
    end
    colors = colors or {cc.c3b(0, 0, 255), cc.c3b(255, 0, 0), cc.c3b(0, 255, 0)}
    delimiters = delimiters or {"#", "*", "$"}
    local type = 1
    local i = 1
    local list = {}
    if callback then
        list = callback(text)
    else
        local len = string.len(text)
        for j = 1, len do
            local s = string.sub(text, j, j)
            local index = table.indexof(delimiters, s) or 0 -- 从表格中查找指定值，返回其索引，如果没找到返回 false
            if index > 0 or j == len then
                if j > 1 then
                    if index > 0 then
                        table.insert(list, {color = colors[type], s = string.sub(text, i, j - 1)})
                    else
                        table.insert(list, {color = colors[type], s = string.sub(text, i, j)})
                    end
                end
                i = j + 1
                type = index
            end
        end 
    end

    if table.nums(list) == 0 then
        return
    end

    local richTxt = ccui.RichText:create()
    if richW then
        richTxt:ignoreContentAdaptWithSize(false)
        richTxt:setContentSize(cc.size(richW,0))
    end
    local size = fontsize or 24
    local ziType = ziti or Define.DEFAULT_FONT
    for key, p in pairs(list) do
        local textSize = size
        if p.scaleSz then
            textSize = textSize*p.scaleSz
        end
        local elem = ccui.RichElementText:create(-1, p.color, 255, p.s, ziti, textSize)
        richTxt:pushBackElement(elem)

        if p.newLine then
            local space=cc.Node:create()
            local sWidth = richW or display.width
            space:setContentSize(sWidth,1)
            richTxt:pushBackElement(ccui.RichElementCustomNode:create(-1,cc.c3b(255,255,255),0xff,space))
        end
    end

    richTxt:formatText()
    return richTxt
end
function FZutil.getNumString(num,_str) -- 千位逗号划分数字字符串
    if num == 0 then
        return "0"
    end
    local str = ""
    local biaodian = _str or ","
    local len = string.len(num)
    local index = 0
    for i=len,1,-3 do 
        local subStr = ""
        if i-2<0 then
            subStr = string.sub(num, 1,i)
        else
            subStr = string.sub(num, i-2,i)
        end
        if index == 0 then
            str = subStr
            index = index + 1
        else
            str = string.format("%s%s%s", subStr,biaodian,str)
        end
    end 
    return str
end

function FZutil.getComp(keys, sign,callback)
    local fun = function(a, b)
        if callback then
            callback({a,b})
        end
        if a == b then
            return false
        end
        for index, key in ipairs(keys) do
            if a[key] ~= b[key] then
                local val_a = a[key] or 0
                local val_b = b[key] or 0
                if sign and sign[index] == "desc" then
                    return val_a > val_b
                else
                    return val_a < val_b
                end
            end
        end
        return false
    end

    return fun
end

--固定目标UI在父节点的间距(上下左右)
function FZutil.setUIMargin(targetUI,topMargin,bottomMargin,leftMargin,rightMargin)
    local parent = targetUI:getParent()
    if not parent then
        return
    end

    local parentSize = parent:getContentSize()
    local targetAnchor = targetUI:getAnchorPoint()
    local targetSize = targetUI:getContentSize()
    local targetPositionX,targetPositionY = targetUI:getPosition()

    local percentWidth = targetSize.width/parentSize.width
    local percentHeight = targetSize.height/parentSize.height
    if topMargin then
        targetSize.height = parentSize.height * percentHeight
        targetPositionY = parentSize.height - (topMargin + (1 - targetAnchor.y) * targetSize.height)   
    elseif bottomMargin then
        targetSize.height = parentSize.height * percentHeight
        targetPositionY = bottomMargin + targetAnchor.y * targetSize.height
    end
    
    if leftMargin then
        targetSize.width = parentSize.width * percentWidth
        targetPositionX = leftMargin + targetAnchor.x * targetSize.width
    elseif rightMargin then
        targetSize.width = parentSize.width * percentWidth
        targetPositionX = parentSize.width - (rightMargin + (1 - targetAnchor.x) * targetSize.width)
    end

    targetUI:setPosition(targetPositionX,targetPositionY)
end

function FZutil.displayAdaptation(uiNode,moveDir)
    local moveTop = display.height - 800    
    if moveTop > 0 then
        moveDir = moveDir or 1  --1代表向上调   -1代表往下调
        local posy = uiNode:getPositionY()
        uiNode:setPositionY(posy+moveTop*moveDir)
    end
end

--忽略内容调整大小
function FZutil.ignoreContentSizeImg(node,county_name)
    if node then
        local nodes=node:getChildren()
        local type_=tolua.type(node)
        if type_ == "ccui.ImageView" then
            -- if FZ_COUNTRY and FZ_COUNTRY == county_name then
                local scaleSz = node:getScale()
                node:ignoreContentAdaptWithSize(true)    --忽略内容调整大小
                node:setScale(scaleSz)
            -- end
        end
        for _, sub in ipairs(nodes) do
            if sub.notIgnoreSize ~= true then
                FZutil.ignoreContentSizeImg(sub,county_name)
            end
        end
    end
end

return FZutil