local CTGuideString = nil
local CTGuideTwoString = require("app.CTGuide.CTGuideTwoString")
local CTGuideLayer = require("app.CTGuide.CTGuideLayer")
local CTGuideManage = {
	OpenCT_Guide = 100, 	-- 设置开店 引导值
	Preview_Guide = 110,-- 预览位置 引导值 
	Save_Guide = 120,	-- 保存装饰 引导值 (如果保存失败将中断后续引导值)
	SaveSuccess_Guide = 130, -- 保存成功 引导值
	Unlock_MenuGrid = 0, 	 -- 研发成功保存并解锁 菜格子 引导值
	UpLevel_Guide = 800, 	-- 升级后出发剧情 引导值
	Guide_MenuID = 20002, 	-- 二级引导菜谱20002
}

local pet_add_btn_size = {width = 100, height = 60} -- 管理界面格子加号Size
local pet_cell_size = {width = 190, height = 460} 	-- 宠物选择界面宠物格子Size
local zuoliao_Cell_size = {width = 111, height = 111} -- 研发界面 佐料Cell
local zuoliao_Text_Size = {width = 60, height = 60} 	-- 研发数字大小
local Mission_Box_Size = {width = 540, height = 40}  -- 主界面上面的任务进度框

local NPC_Talk_Zorder = 150
local Clipp_Node_Zorder = 100

local Close_On_Login = nil 	-- 是否开启预备引导
local Local_Guide = nil 	-- 预备引导下标
local Color_Opacity = 0.5 	-- 引导界面灰度
local Ruan_Guide = nil 		-- 软引导下标
local open_Guide = true 	-- 是否开启2级后引导开关

---------------------------------------------------------------------------------------
function CTGuideManage:initGuideOnHomeScene(MainUI,HomeScene_Self)
	self.MainUI = MainUI 			-- HomeScene UI Root
	self.HomeScene_Self = HomeScene_Self
end
function CTGuideManage:initGuideOnPetManage(ManageUI,PetManage_Self)
	self.ManageUI = ManageUI 		-- PetManageLayer UI Root
	self.PetManage_Self = PetManage_Self
end
function CTGuideManage:initGuideOnPetChoose(PetChooseUI,PetChoose_Self)
	self.PetChooseUI = PetChooseUI 	-- PetChooseLayer UI Root
	self.PetChoose_Self = PetChoose_Self
end
function CTGuideManage:initGuideOnMenuLayer(MenuLayerUI,MenuLayer_Self)
	self.MenuLayerUI = MenuLayerUI 	-- MenuLayer UI Root
	self.MenuLayer_Self = MenuLayer_Self
end
function CTGuideManage:initGuideOnDressLayer(DressLayerUI,DressLayer_Self)
	self.DressLayerUI = DressLayerUI 	-- DressLayer UI Root
	self.DressLayer_Self = DressLayer_Self
end
function CTGuideManage:initGuideOnFurnitureLayer(FurnitureLayerUI,FurnitureLayer_Self)
	self.FurnitureLayerUI = FurnitureLayerUI 	-- FurnitureLayer UI Root
	self.FurnitureLayer_Self = FurnitureLayer_Self
end
function CTGuideManage:initGuideOnChapterLayer(ChapterLayerUI,ChapterLayer_Self)
	self.ChapterLayerUI = ChapterLayerUI 	-- ChapterLayer UI Root
	self.ChapterLayer_Self = ChapterLayer_Self
end
function CTGuideManage:initGuideOnMissionLayer(MissionLayerUI,MissionLayer_Self)
	self.MissionLayerUI = MissionLayerUI 	-- MissionLayer UI Root
	self.MissionLayer_Self = MissionLayer_Self
end
function CTGuideManage:initGuideOnMenuSceneLayer(MenuSceneLayerUI,MenuSceneLayer_Self)
	self.MenuSceneLayerUI = MenuSceneLayerUI 	-- MenuSceneLayer UI Root
	self.MenuSceneLayer_Self = MenuSceneLayer_Self
end
function CTGuideManage:initGuideOnMenuProduceLayer(MenuProduceLayerUI,MenuProduceLayer_Self)
	self.MenuProduceLayerUI = MenuProduceLayerUI 	-- MenuProduceLayer UI Root
	self.MenuProduceLayer_Self = MenuProduceLayer_Self
end
function CTGuideManage:initGuideOnMenuProduceSetLayer(MenuProduceSetLayerUI,MenuProduceSetLayer_Self)
	self.MenuProduceSetLayerUI = MenuProduceSetLayerUI 	-- MenuProduceSetLayer UI Root
	self.MenuProduceSetLayer_Self = MenuProduceSetLayer_Self
end
function CTGuideManage:initGuideOnMenuProduceSaveLayer(MenuProduceSaveLayerUI,MenuProduceSaveLayer_Self)
	self.MenuProduceSaveLayerUI = MenuProduceSaveLayerUI 	-- MenuProduceSaveLayer UI Root
	self.MenuProduceSaveLayer_Self = MenuProduceSaveLayer_Self
end
---------------------------------------------------------------------------------------
function CTGuideManage:CheckSaveGuide(ret) 	-- 保存引导的回调方法
	local guide = RoleData.player_info.guide
	if guide ~= CTGuideManage.Save_Guide then
		return
	end
	if ret == 0 or ret == 1 then 	-- 保存成功 开启后续引导
		NetEngine:sendMessage(game_cmd.CSetGuide,{guide = CTGuideManage.SaveSuccess_Guide})
		RoleData.player_info.guide = CTGuideManage.SaveSuccess_Guide
		self:checkGuide()
	else 							-- 保存失败 中断后续引导
		NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 10000})
		RoleData.player_info.guide = 10000
	end
end
---------------------------------------------------------------------------------------
local function changeAction( modle,play_animation,is_loop )
    modle:clearTracks()
    modle:addAnimation(0,play_animation,is_loop)
end
function CTGuideManage:CheckGuideOpenAction() 	-- 开场动画
	local atlasPath = "battle/Piantou/Piantou.atlas"
    if IconPath.checkFile(atlasPath) then
        local jsonPath = "battle/Piantou/Piantou.json"
        local GuideOpenTX = sp.SkeletonAnimation:create(jsonPath, atlasPath)
        GuideOpenTX:setPosition(display.center)
        self.HomeScene_Self:addChild(GuideOpenTX)
        local function callfuncTX() 				-- 黑洞
        	NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1})
			RoleData.player_info.guide = 1
        	changeAction(GuideOpenTX,"3",false )
        	audio.playSound(FzSound.sounds.sound_guide2,false)
        	performWithDelay(GuideOpenTX,function ()
        		GuideOpenTX:removeSelf()
        		GuideOpenTX = nil
        		FzSound.PlayBgmForMain() 	-- 梦境走完 播放正常bgm音乐
        		self:checkGuide()
	        end,0.7)
        end
		FZutil.disableTouch()
        performWithDelay(GuideOpenTX,function () 	-- 跑动
        	changeAction(GuideOpenTX,"1",false )
            audio.playSound(FzSound.sounds.sound_guide,false)
        end,1/60)
        performWithDelay(GuideOpenTX,function () 	-- 打开信封
        	changeAction(GuideOpenTX,"2",false )
	        performWithDelay(GuideOpenTX,function ()
				FZutil.enableTouch()
	        	local story_id = 1000 --新手引导 剧情ID
	        	StoryNode:showStory(story_id,callfuncTX,1000)-- 检查引导
	        end,0.5)
        end,3.0)
    end
end
-------------------------------------------------------------------------------------
function CTGuideManage:checkGuide(Home_Close_On_Login)
	if not CTGuideString then -- 
		if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
			CTGuideString = require("app.CTGuide.CTGuideStringJapan")
		elseif FZ_COUNTRY and FZ_COUNTRY == "Korea" then
			CTGuideString = require("app.CTGuide.CTGuideStringKorea")
		else
 			CTGuideString = require("app.CTGuide.CTGuideString")
		end
	end
	if Home_Close_On_Login and not Close_On_Login then -- 断线重连后 开始部分假引导
		Local_Guide = 0
		Close_On_Login = true
	end
	local guide = RoleData.player_info.guide
	print("新手引导  guide ："..guide)
	if guide == 0 then 	-- 播放开场动画
		self:CheckGuideOpenAction()
	elseif guide == 1 then 	-- 动画完剧情
		local function SetGuideIDFunc()
			NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 2})
			RoleData.player_info.guide = 2
			self:checkGuide()
		end
        local story_id = 1001 --新手引导 剧情ID
        StoryNode:showStory(story_id,SetGuideIDFunc,1000)-- 检查引导
	elseif guide>=2 and guide<=17 then -- 引导 设置员工和菜品~
		if Close_On_Login and Local_Guide and guide>=5 then -- 开启前置预备引导
			if Local_Guide == 0 then
				local function callfunc()
					Local_Guide = 1
					self.HomeScene_Self:ManageBtnTouchFunc()
					self:checkGuide()
				end
				local ManageBtn = self.MainUI.Button_manadge
				self:CreateHandLayer(ManageBtn,callfunc)
			elseif Local_Guide == 1 then
				local function callfunc()
					if guide<15 then
						Close_On_Login = nil
						Local_Guide = nil -- 预备引导结束
					else
						Local_Guide = 15
					end
					self.HomeScene_Self:OpenPetManage() 	 -- 打开管理界面
					self:checkGuide()
				end
				local OperateBtn = self.MainUI.Button_operate
				self:CreateHandLayer(OperateBtn,callfunc,0.5)
			elseif Local_Guide == 15 then -- 预备引导点击左侧菜单切页
				local left_Menu_Btn = self.PetManage_Self:CheckGuide(12)
				local function callfunc()
					self.PetManage_Self:SetLeftGroupSelect(2)
					Close_On_Login = nil
					Local_Guide = nil -- 预备引导结束
					self:checkGuide()
				end
				self:CreateHandLayer(left_Menu_Btn,callfunc,0.5)
			end
			return
		else
			Close_On_Login = nil
			Local_Guide = nil -- 预备引导结束
		end
		if guide == 2 then 		-- NPC说话 引导 设置员工~
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 3
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[10],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 3 then 	-- 引导点击主界面 右下角管理按钮
			local function callfunc()
				RoleData.player_info.guide = 4
				self.HomeScene_Self:ManageBtnTouchFunc()
				self:checkGuide()
			end
			local ManageBtn = self.MainUI.Button_manadge
			self:CreateHandLayer(ManageBtn,callfunc)
		elseif guide == 4 then -- 引导点击下排按钮里的 管理按钮
			local function callfunc()
				RoleData.player_info.guide = 5
				self.HomeScene_Self:OpenPetManage() 	 -- 打开管理界面
				self:checkGuide()
			end
			local OperateBtn = self.MainUI.Button_operate
			self:CreateHandLayer(OperateBtn,callfunc,0.5)
		----------------------------------------------------------
		elseif guide == 5 then 	-- 引导点击第一个员工格子
			local Employee_Cell = self.PetManage_Self:CheckGuide(5)
			local function callfunc()
				Employee_Cell:openChoosePetLayer()
				RoleData.player_info.guide = 6
				self:checkGuide()
			end
			self:CreateHandLayer(Employee_Cell,callfunc,0.3)
		elseif guide == 6 then -- 引导 6001可可为经理
			-- 引导出现可可想当经理
			local layer = CTGuideLayer.new(CTGuideString[11])
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 引导裁剪 可可
			local Pet_Cell = self.PetChoose_Self:CheckGuide(1)
			local function callfunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 7})
				NetEngine:sendMessage(game_cmd.CSetPet,{pet_id = 6001, own_id = RoleData.player_info.player_id, gird_id = 1})
				layer:removeSelf()
				self.PetChoose_Self:removeSelf()
				self.PetChoose_Self = nil
				RoleData.player_info.guide = 7
				self:checkGuide()
			end
			self:CreateHandLayer(Pet_Cell,callfunc,0.3)
		elseif guide == 7 then 	-- 引导点击第二个员工格子
			local Employee_Cell = self.PetManage_Self:CheckGuide(7)
			local function callfunc()
				Employee_Cell:openChoosePetLayer()
				RoleData.player_info.guide = 8
				self:checkGuide()
			end
			self:CreateHandLayer(Employee_Cell,callfunc,0.5)
		elseif guide == 8 then -- 引导 6005毛毛熊为厨师
			-- 引导出现毛毛熊想当厨师
			local layer = CTGuideLayer.new(CTGuideString[12])
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 引导裁剪 毛毛熊
			local Pet_Cell = self.PetChoose_Self:CheckGuide(2)
			local function callfunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 9})
				NetEngine:sendMessage(game_cmd.CSetPet,{pet_id = 6005, own_id = RoleData.player_info.player_id, gird_id = 2})
				layer:removeSelf()
				self.PetChoose_Self:removeSelf()
				self.PetChoose_Self = nil
				RoleData.player_info.guide = 9
				self:checkGuide()
			end
			self:CreateHandLayer(Pet_Cell,callfunc,0.3)
		elseif guide == 9 then 	-- 引导点击第三个员工格子
			local Employee_Cell = self.PetManage_Self:CheckGuide(9)
			local function callfunc()
				Employee_Cell:openChoosePetLayer()
				RoleData.player_info.guide = 10
				self:checkGuide()
			end
			self:CreateHandLayer(Employee_Cell,callfunc,0.5)
		elseif guide == 10 then -- 引导 6007皮皮为服务员
			-- 引导出现皮皮想当服务员
			local layer = CTGuideLayer.new(CTGuideString[13])
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 引导裁剪 皮皮
			local Pet_Cell = self.PetChoose_Self:CheckGuide(3)
			local function callfunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 11})
				NetEngine:sendMessage(game_cmd.CSetPet,{pet_id = 6007, own_id = RoleData.player_info.player_id, gird_id = 3})
				layer:removeSelf()
				self.PetChoose_Self:removeSelf()
				self.PetChoose_Self = nil
				RoleData.player_info.guide = 11
				self:checkGuide()
			end
			self:CreateHandLayer(Pet_Cell,callfunc,0.3)
		---------------------------------------------------------- 引导 设置菜单~
		elseif guide == 11 then 	-- 引导NPC菜单说话
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 12
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[20],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 12 then -- 引导点击左菜单切页
			local left_Menu_Btn = self.PetManage_Self:CheckGuide(12)
			local function callfunc()
				RoleData.player_info.guide = 13
				self.PetManage_Self:SetLeftGroupSelect(2)
				self:checkGuide()
			end
			self:CreateHandLayer(left_Menu_Btn,callfunc)
		elseif guide == 13 then -- 引导点击第一个菜单格子
			local Menu_Cell = self.PetManage_Self:CheckGuide(13)
			local function callfunc()
				RoleData.player_info.guide = 14
				Menu_Cell:openMenuLayer(20002)
				self:checkGuide()
			end
			self:CreateHandLayer(Menu_Cell,callfunc)
		elseif guide == 14 then -- 引导 20002番茄炒蛋为第一个格子
			local menu_cell = self.MenuLayer_Self:checkGuide(1)
			local function callfunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 15})
				local menucfg = ConfigData.st_menu[20002]
				local _gridData = MenuData.unlockMenuData[20002][1]
				local getScoreType = MenuData:getMenuScore(_gridData.menu_id,_gridData.colour,_gridData.incense,_gridData.flavour,_gridData.quantity,_gridData.appearance)
				local saleGold = menucfg[MenuData.scoreType[getScoreType].."_price"]
				NetEngine:sendMessage(game_cmd.CAddMainMenu,{main_menu={menu_id=_gridData.menu_id,gird_id=_gridData.gird_id,sale_gold=saleGold}})
				self.MenuLayer_Self:removeSelf()
				self.MenuLayer_Self = nil
				RoleData.player_info.guide = 15
				self:checkGuide()
			end
			self:CreateHandLayer(menu_cell,callfunc,0.3)
		elseif guide == 15 then -- 引导点击第二个菜单格子
			local Menu_Cell = self.PetManage_Self:CheckGuide(15)
			local function callfunc()
				RoleData.player_info.guide = 16
				Menu_Cell:openMenuLayer(20005)
				self:checkGuide()
			end
			self:CreateHandLayer(Menu_Cell,callfunc,0.5)
		elseif guide == 16 then -- 引导 20005香菇青菜为第二个格子
			local menu_cell = self.MenuLayer_Self:checkGuide(2)
			local function callfunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 17})
				local menucfg = ConfigData.st_menu[20005]
				local _gridData = MenuData.unlockMenuData[20005][1]
				local getScoreType = MenuData:getMenuScore(_gridData.menu_id,_gridData.colour,_gridData.incense,_gridData.flavour,_gridData.quantity,_gridData.appearance)
				local saleGold = menucfg[MenuData.scoreType[getScoreType].."_price"]
				NetEngine:sendMessage(game_cmd.CAddMainMenu,{main_menu={menu_id=_gridData.menu_id,gird_id=_gridData.gird_id,sale_gold=saleGold}})
				self.MenuLayer_Self:removeSelf()
				self.MenuLayer_Self = nil
				RoleData.player_info.guide = 17
				self:checkGuide()
			end
			self:CreateHandLayer(menu_cell,callfunc,0.3)
		elseif guide == 17 then -- 引导 说明菜价格可调 和价格的影响人流量
			-- 添加需要裁剪的部位~
			local Menu_Cell = self.PetManage_Self:CheckGuideForMenu(20002) --self.PetManage_Self:CheckGuide(17)
			local MoneyTxt = Menu_Cell:GuideGetTxt()
			local HandLayer = self:CreateHandLayer(MoneyTxt,nil,0,true)
			-- 添加NPC对话界面
			local function SetGuideIDFunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 30})
				self.PetManage_Self:removeSelf()
				HandLayer:removeSelf()
				self.PetManage_Self = nil
				RoleData.player_info.guide = 30
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[30],SetGuideIDFunc)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		end
	elseif guide>=30 and guide<55 then 	-- 引导去 领任务 去菜谱 研发 。。
		local ShowManageBtn_Key = self.HomeScene_Self:getManageBtnPos()
		if Close_On_Login and Local_Guide and guide>=50 then -- 开启前置预备引导
			if Local_Guide == 0 then
				
			elseif Local_Guide == 1 then
				
			end
			return
		else
			Close_On_Login = nil
			Local_Guide = nil -- 预备引导结束
		end
		if guide == 30 then 		-- 引导点击任务按钮
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[31])
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.HomeScene_Self:TouchOpenMission()
				RoleData.player_info.guide = 31
				self:checkGuide()
			end
			local Mission_Btn = self.MainUI.Button_mission
			local UISize = nil
			if self.HomeScene_Self.mainMission then
				Mission_Btn = self.HomeScene_Self.mainMission.Image_bg1
				-- local bgImage = self.HomeScene_Self.achievementMission.Image_bg1
				-- UISize = {x=0,y=0,width=0,height=0}
				-- local size = bgImage:getContentSize()
				-- UISize.width, UISize.height = size.width, size.height
				-- local x,y = Mission_Btn:getPosition()
				-- UISize.x, UISize.y = x,y
			end
			self:CreateHandLayer(Mission_Btn,callfunc,nil,nil,UISize)
		elseif guide == 31 then 	-- 引导任务领取按钮
			print("引导任务领取按钮")
			local Mission_Cell = self.MissionLayer_Self:CheckGuide()
			local function callfunc1()
                NetEngine:sendMessage(game_cmd.CGiveMission,{mission_class=1,mission_id=10001}) -- 领取任务奖励
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 32})
				RoleData.player_info.guide = 32
				local function callfunc2()
	                self.MissionLayer_Self:onClose() -- 引导关闭任务界面
	                self.MissionLayer_Self = nil
	                self.MissionLayerUI = nil
					self:checkGuide()
				end
				local GuanbiBtn = self.MissionLayerUI.Button_guanbi
				self:CreateHandLayer(GuanbiBtn,callfunc2)
			end
			local MissionBtn = Mission_Cell.Button_get
			self:CreateHandLayer(MissionBtn,callfunc1)
		elseif guide == 32 then 	-- 引导点击 下排管理按钮
			RoleData.player_info.guide = 33
			if ShowManageBtn_Key then
				self:checkGuide()
				return
			end
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[32],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.HomeScene_Self:ManageBtnTouchFunc()
				self:checkGuide()
			end
			local ManageBtn = self.MainUI.Button_manadge
			self:CreateHandLayer(ManageBtn,callfunc)
		elseif guide == 33 then 	-- 引导点击下排按钮中 的菜谱按钮
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[32],nil,true) -- 因为与上一句话相同 所以不用开启打字机
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.HomeScene_Self:TouchOpenMenu(20002) -- 番茄炒蛋
				RoleData.player_info.guide = 34
				self:checkGuide()
			end
			local MenuBtn = self.MainUI.Button_menu
			self:CreateHandLayer(MenuBtn,callfunc,0.5)
		elseif guide == 34 then   -- 引导 点击番茄炒蛋 研发按钮
			local Menu_Cell = self.MenuSceneLayer_Self:CheckGuide()
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[3232],nil,true) -- 因为与上一句话相同 所以不用开启打字机
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				Menu_Cell.TouchOpenProduce()
				layer:removeSelf()
				RoleData.player_info.guide = 35
				self:checkGuide()
			end
			local Produce_Btn = Menu_Cell.Button_produce
			self:CreateHandLayer(Produce_Btn,callfunc,0.5)
		elseif guide == 35 then -- 引导 研发界面 框材料
			-- 添加需要裁剪的部位~
			local Cailiao_Node = self.MenuProduceLayerUI.ScrollView_cailiao
			local HandLayer = self:CreateHandLayer(Cailiao_Node,nil,0.2,true) -- 不需要手指特效
			-- 添加NPC对话界面
			local function SetGuideIDFunc()
				HandLayer:removeSelf()
				RoleData.player_info.guide = 37 --36
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[33],SetGuideIDFunc)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- elseif guide == 36 then 	-- 引导点击 佐料按钮
		-- 	-- 添加NPC对话界面
		-- 	local layer = CTGuideLayer.new(CTGuideString[33],nil,true)
		-- 	layer:setBackGroundColorOpacity(math.floor(0*0xff))
		-- 	layer:setTouchEnabled(false)
		-- 	display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 	-- 添加需要裁剪的部位~
		-- 	local function callfunc()
		-- 		self.MenuProduceLayer_Self:CheckGuide() -- 切换显示佐料
		-- 		layer:removeSelf()
		-- 		RoleData.player_info.guide = 37
		-- 		self:checkGuide()
		-- 	end
		-- 	local CheckBox_Btn = self.MenuProduceLayerUI.CheckBox_fuliao
		-- 	self:CreateHandLayer(CheckBox_Btn,callfunc)
		elseif guide == 37 then -- 引导点 佐料 糖
			print("850011*糖******850021*盐******850041*葱******850071*鸡精")
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[34],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			local Cell_index = self.MenuProduceLayer_Self:setGuideCell(850011)
			local Cell_UI = self.MenuProduceLayer_Self:getGuidezuoliaoCell(Cell_index)
			-- 添加需要裁剪的部位~
			local function callfunc()
				self.MenuProduceLayer_Self:setGuideSelect(Cell_index)
				layer:removeSelf()
				RoleData.player_info.guide = 38
				self:checkGuide()
			end
			self:CreateHandLayer(Cell_UI.CheckBox_cailiao1,callfunc)
		elseif guide == 38 then 	-- 引导点1 添加 糖
			local text_UI = self.MenuProduceLayer_Self.relishNode["Text_1"]
			-- local function callfunc()
				text_UI.TouchCallfunc()
				RoleData.player_info.guide = 39
				local Button_YES = self.MenuProduceLayer_Self.relishNode["Button_YES"]
				local function callfunc()
					Button_YES.TouchCallfunc()
					self:checkGuide()
				end
				self:CreateHandLayer(Button_YES,callfunc)
			-- end
			-- self:CreateHandLayer(text_UI,callfunc)
		elseif guide == 39 then -- 引导点 佐料 盐
			print("850021*盐")
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[35],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			local Cell_index = self.MenuProduceLayer_Self:setGuideCell(850021)
			local Cell_UI = self.MenuProduceLayer_Self:getGuidezuoliaoCell(Cell_index)
			-- 添加需要裁剪的部位~
			local function callfunc()
				self.MenuProduceLayer_Self:setGuideSelect(Cell_index)
				layer:removeSelf()
				RoleData.player_info.guide = 40
				self:checkGuide()
			end
			self:CreateHandLayer(Cell_UI.CheckBox_cailiao1,callfunc)
		elseif guide == 40 then 	-- 引导点1 添加 盐
			local text_UI = self.MenuProduceLayer_Self.relishNode["Text_1"]
			-- local function callfunc()
				text_UI.TouchCallfunc()
				RoleData.player_info.guide = 41
				local Button_YES = self.MenuProduceLayer_Self.relishNode["Button_YES"]
				local function callfunc()
					Button_YES.TouchCallfunc()
					self:checkGuide()
				end
				self:CreateHandLayer(Button_YES,callfunc)
			-- end
			-- self:CreateHandLayer(text_UI,callfunc)
		elseif guide == 41 then -- 引导点 佐料 葱
			print("850041*葱")
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[36],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			local Cell_index = self.MenuProduceLayer_Self:setGuideCell(850041)
			local Cell_UI = self.MenuProduceLayer_Self:getGuidezuoliaoCell(Cell_index)
			-- 添加需要裁剪的部位~
			local function callfunc()
				self.MenuProduceLayer_Self:setGuideSelect(Cell_index)
				layer:removeSelf()
				RoleData.player_info.guide = 42
				self:checkGuide()
			end
			self:CreateHandLayer(Cell_UI.CheckBox_cailiao1,callfunc)
		elseif guide == 42 then 	-- 引导点5 添加 葱
			local text_UI = self.MenuProduceLayer_Self.relishNode["Text_1"]
			-- local function callfunc()
				text_UI.TouchCallfunc()
				RoleData.player_info.guide = 43
				local Button_YES = self.MenuProduceLayer_Self.relishNode["Button_YES"]
				local function callfunc()
					Button_YES.TouchCallfunc()
					self:checkGuide()
				end
				self:CreateHandLayer(Button_YES,callfunc)
			-- end
			-- self:CreateHandLayer(text_UI,callfunc)
		elseif guide == 43 then -- 引导点 佐料 鸡精
			print("850071*鸡精")
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[37],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			local Cell_index = self.MenuProduceLayer_Self:setGuideCell(850071)
			local Cell_UI = self.MenuProduceLayer_Self:getGuidezuoliaoCell(Cell_index)
			-- 添加需要裁剪的部位~
			local function callfunc()
				self.MenuProduceLayer_Self:setGuideSelect(Cell_index)
				layer:removeSelf()
				RoleData.player_info.guide = 44
				self:checkGuide()
			end
			self:CreateHandLayer(Cell_UI.CheckBox_cailiao1,callfunc)
		elseif guide == 44 then 	-- 引导点5 添加 鸡精
			local text_UI = self.MenuProduceLayer_Self.relishNode["Text_1"]
			-- local function callfunc()
				text_UI.TouchCallfunc()
				RoleData.player_info.guide = 45
				local Button_YES = self.MenuProduceLayer_Self.relishNode["Button_YES"]
				local function callfunc()
					Button_YES.TouchCallfunc()
					self:checkGuide()
				end
				self:CreateHandLayer(Button_YES,callfunc)
			-- end
			-- self:CreateHandLayer(text_UI,callfunc)
		elseif guide == 45 then 	-- 佐料添加完毕 引导 点击确定
			local Sure_Btn = self.MenuProduceLayerUI["Button_sure"]
			local function callfunc()
				Sure_Btn.TouchCallfunc()
				RoleData.player_info.guide = 46
				-- self:checkGuide() -- 这里的检查引导 放入研发成功界面加载完后 调用了
			end
			self:CreateHandLayer(Sure_Btn,callfunc)
		elseif guide == 46 then 	-- S级番茄炒蛋 获得界面 引导添加进菜品格子
			-- 添加NPC对话界面 		-- 引导点击保存按钮
			local layer = CTGuideLayer.new(CTGuideString[38],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			layer:hide()
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			local Save_Btn = self.MenuProduceSetLayerUI.Button_save
			-- 添加需要裁剪的部位~
			local function callfunc()
				Save_Btn.TouchCallfunc()
				layer:removeSelf()
				RoleData.player_info.guide = 48 -- 47
				self:checkGuide()
			end
			local HandLayer = self:CreateHandLayer(Save_Btn,callfunc,6) -- 6-4 = 2秒的动作时间 添加裁剪点击框
			HandLayer:setOpacity(0)
			performWithDelay(layer, function ()
				layer:show()
				HandLayer:setOpacity(255)
			end,4) -- 4秒的特效播放时间 显示对话
		elseif guide == 47 then 	-- 引导点击菜品第一个格子
			-- CTGuideManage.Unlock_MenuGrid = guide
			-- local Cell_Btn = self.MenuProduceSetLayer_Self:CheckGuide()
			-- local function callfunc()
			-- 	Cell_Btn.TouchCallfunc(1)
				-- RoleData.player_info.guide = 48
				-- self:checkGuide()
			-- end
			-- self:CreateHandLayer(Cell_Btn.Image_chosen_bg,callfunc)
		elseif guide == 48 then
			local Cell_Btn = self.MenuProduceSaveLayer_Self:CheckGuide()
			local function callfunc()
				self.MenuProduceSaveLayer_Self:CheckGuideSaveMenu()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 55})
				local Close_Btn = self.MenuProduceLayerUI["Button_guanbi"]
				local function callfunc2()
					self.MenuProduceSaveLayerUI = nil
					self.MenuProduceSaveLayer_Self = nil
					self.MenuProduceLayer_Self:CloseLayer()
					self.MenuProduceLayer_Self = nil
					self.MenuProduceLayerUI = nil
					self.MenuProduceSetLayerUI = nil
					self.MenuProduceSetLayer_Self = nil
					self.MenuSceneLayerUI.Button_guanbi.TouchCallfunc()
					self.MenuSceneLayer_Self = nil
					self.MenuSceneLayerUI = nil
					RoleData.player_info.guide = 55
					FzSound.ChangeMusic(FzSound.music.main_name)
					self:checkGuide()
				end
				self:CreateHandLayer(Close_Btn,callfunc2,0.4)
			end
			self:CreateHandLayer(Cell_Btn.Image_bg,callfunc)
		end
	elseif guide>=55 and guide<100 then -- 引导去管理菜谱界面 更换新研发的菜品 
		-- print("引导去管理菜谱界面 更换新研发的菜品 ")
		local ShowManageBtn_Key = self.HomeScene_Self:getManageBtnPos()
		if Close_On_Login and Local_Guide and guide>=60 and guide<63 then -- 开启前置预备引导
			if Local_Guide == 0 then
				if ShowManageBtn_Key then
					Local_Guide = 1
					self:checkGuide()
				else
					local function callfunc()
						Local_Guide = 1
						self.HomeScene_Self:ManageBtnTouchFunc()
						self:checkGuide()
					end
					local ManageBtn = self.MainUI.Button_manadge
					self:CreateHandLayer(ManageBtn,callfunc)
				end
			elseif Local_Guide == 1 then
				local function callfunc()
					Local_Guide = 2
					self.HomeScene_Self:OpenPetManage() 	 -- 打开管理界面
					self:checkGuide()
				end
				local OperateBtn = self.MainUI.Button_operate
				self:CreateHandLayer(OperateBtn,callfunc,0.5)
			elseif Local_Guide == 2 then -- 预备引导点击左侧菜单切页
				local left_Menu_Btn = self.PetManage_Self:CheckGuide(12)
				local function callfunc()
					self.PetManage_Self:SetLeftGroupSelect(2)
					Close_On_Login = nil
					Local_Guide = nil -- 预备引导结束
					self:checkGuide()
				end
				self:CreateHandLayer(left_Menu_Btn,callfunc,0.5)
			end
			return
		else
			Close_On_Login = nil
			Local_Guide = nil -- 预备引导结束
		end
		if guide == 55 then 	-- 引导点击 下排管理按钮
			RoleData.player_info.guide = 56
			if ShowManageBtn_Key then
				self:checkGuide()
				return
			end
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[39],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.HomeScene_Self:ManageBtnTouchFunc()
				self:checkGuide()
			end
			local ManageBtn = self.MainUI.Button_manadge
			self:CreateHandLayer(ManageBtn,callfunc,0.5)
		elseif guide == 56 then 	-- 引导点击下排按钮中 的管理按钮
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[39],true)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.HomeScene_Self:OpenPetManage() 	 -- 打开管理界面
				RoleData.player_info.guide = 57
				self:checkGuide()
			end
			local OperateBtn = self.MainUI.Button_operate
			self:CreateHandLayer(OperateBtn,callfunc,0.5)
		elseif guide == 57 then 	-- 引导点击 左侧菜单切页
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[3939],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local function callfunc()
				layer:removeSelf()
				self.PetManage_Self:SetLeftGroupSelect(2)
				RoleData.player_info.guide = 58
				self:checkGuide()
			end
			local left_Menu_Btn = self.PetManage_Self:CheckGuide(12)
			self:CreateHandLayer(left_Menu_Btn,callfunc,0.5)
		elseif guide == 58 then 	-- 引导点击番茄炒蛋 更改按钮 
			-- 添加需要裁剪的部位~
			local Menu_Cell = self.PetManage_Self:CheckGuideForMenu(20002)
			local function callfunc()
				RoleData.player_info.guide = 59
				Menu_Cell:openMenuLayer(20002)
				self:checkGuide()
			end
			local Change_Btn = Menu_Cell:GuideChangeBtn()
			self:CreateHandLayer(Change_Btn,callfunc,0.1)
		elseif guide == 59 then 	-- 将新的S级的番茄炒蛋 替换老的番茄炒蛋
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[3939],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- 添加需要裁剪的部位~
			local menu_cell = self.MenuLayer_Self:checkGuide(3)
			local function callfunc()
				layer:removeSelf()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 60})
				local menucfg = ConfigData.st_menu[20002]
				local _gridData = MenuData.unlockMenuData[20002][2]
				if _gridData then
					local getScoreType = MenuData:getMenuScore(_gridData.menu_id,_gridData.colour,_gridData.incense,_gridData.flavour,_gridData.quantity,_gridData.appearance)
					local saleGold = menucfg[MenuData.scoreType[getScoreType].."_price"]
					NetEngine:sendMessage(game_cmd.CAddMainMenu,{main_menu={menu_id=_gridData.menu_id,gird_id=_gridData.gird_id,sale_gold=saleGold}})
					self.MenuLayer_Self:removeSelf()
					self.MenuLayer_Self = nil
					RoleData.player_info.guide = 60
					self:checkGuide()
				else
					MoveMessage.show("引导错误~"..RoleData.player_info.guide)
					RoleData.player_info.guide = 10000
					NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 10000})
					self:checkGuide()
				end
			end
			self:CreateHandLayer(menu_cell,callfunc,0.3)
		elseif guide == 60 then -- 引导点击 S番茄炒蛋 售价按钮
			-- 添加需要裁剪的部位~
			local Menu_Cell = self.PetManage_Self:CheckGuideForMenu(20002) --self.PetManage_Self:CheckGuide(17)
			local MoneyBtn = Menu_Cell:GuideGetMenuBg()
			local HandLayer = self:CreateHandLayer(MoneyBtn,nil,0,true) -- 不需要手指特效
			local function SetGuideIDFunc()
				HandLayer:removeSelf()
				RoleData.player_info.guide = 61
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[40],SetGuideIDFunc)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 61 then 	-- 引导点击 减号按钮 改变售价 220
			-- 添加NPC对话界面
			local layer = CTGuideLayer.new(CTGuideString[41],nil)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			layer:setTouchEnabled(false)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			layer:setTalkCallPos() -- 因为界面原因 位置需要下移
			-- 添加需要裁剪的部位~
			local Menu_Cell = self.PetManage_Self:CheckGuideForMenu(20002) --self.PetManage_Self:CheckGuide(17)
			local SubBtn = Menu_Cell:GuideGetSubBtn()
			local function callfunc()
				layer:removeSelf()
				Menu_Cell:GuideSubCallfun()
				RoleData.player_info.guide = 62
				self:checkGuide()
			end
			self:CreateHandLayer(SubBtn,callfunc)
		elseif guide == 62 then 	-- 引导点击 确定按钮 更改售价
			local function SetGuideIDFunc()
				self.PetManage_Self:CloseLayer()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 63})
				RoleData.player_info.guide = 63
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[42],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			-- end
		elseif guide == 63 then 	-- 引导点击 主界面任务进度框 开店
			-- 添加需要裁剪的部位~
			local Box_Mission = self.MainUI.Button_mission
			if self.HomeScene_Self.mainMission then
				Box_Mission = self.HomeScene_Self.mainMission.Image_bg1
			end
			local HandLayer = self:CreateHandLayer(Box_Mission,nil,0,true) -- 不需要手指特效
			local function SetGuideIDFunc()
				HandLayer:removeSelf()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 800})
				CTGuideManage.UpLevel_Guide = 800 -- HomeScene检查开始升级引导值 !!! 这里改了，上面初始化的时候也要改~~~~!!!
				RoleData.player_info.guide = 800
				CTSearchCenter:OpenSearchPath() -- 开店 CTGuideManage.OpenCT_Guide = 800
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[43],SetGuideIDFunc)
			layer:setBackGroundColorOpacity(math.floor(0*0xff))
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		end
	elseif guide>=800 and guide<2000 then -- 餐厅升级后引导
		local ct_level = RoleData.player_info.ct_level
		if ct_level<2 then
			print("等级不够 "..ct_level.." 引导无法触发~")
			if guide==800 then
			end
			return 
		end
		local ShowManageBtn_Key = self.HomeScene_Self:getManageBtnPos()
		-- 引导保存装饰 !! 后需预 备引导进入装扮界面升级各装饰
		-- CTGuideManage.SaveSuccess_Guide 这个值等于下面 的预备引导条件值 1090
		if Close_On_Login and Local_Guide and guide>=1090 then -- 开启前置预备引导
			if Local_Guide == 0 then
				if ShowManageBtn_Key then
					Local_Guide = 1
					self:checkGuide()
				else
					local function callfunc()
						Local_Guide = 1
						self.HomeScene_Self:ManageBtnTouchFunc()
						self:checkGuide()
					end
					local ManageBtn = self.MainUI.Button_manadge
					self:CreateHandLayer(ManageBtn,callfunc)
				end
			elseif Local_Guide == 1 then
				local function callfunc()
					local ct_level = RoleData.player_info.ct_level
					if ct_level>10 then
						MainMapListener:setMapPos(0,-230)
					else
						MainMapListener:setMapPos(0,220)
					end
					Close_On_Login = nil
					Local_Guide = nil -- 预备引导结束
					self.HomeScene_Self:TouchOpenAdorn()
					self:checkGuide()
				end
				local ArrangeBtn = self.MainUI.Button_arrange
				self:CreateHandLayer(ArrangeBtn,callfunc,0.5)
			end
			return
		else
			Close_On_Login = nil
			Local_Guide = nil -- 预备引导结束
		end
		--------------------------------------------------
		if guide == 800 then 		-- NPC说话 引导 摆放装饰~
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 810
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[60],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 810 then
			local function SetGuideIDFunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1000})
				RoleData.player_info.guide = 1000
            	RewardTip.addToShow(5,1,188888)
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[63],SetGuideIDFunc) -- 哇~ 得了好多一笔钱 可以好好进行一番装修了
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 1000 then 	-- 引导点击主界面 右下角管理按钮
			if ShowManageBtn_Key then
				RoleData.player_info.guide = 1010
				self:checkGuide()
			else
				local function callfunc()
					RoleData.player_info.guide = 1010
					self.HomeScene_Self:ManageBtnTouchFunc()
					self:checkGuide()
				end
				local ManageBtn = self.MainUI.Button_manadge
				self:CreateHandLayer(ManageBtn,callfunc)
			end
		elseif guide == 1010 then 		-- 引导点击下排按钮里的 布置按钮
			local function callfunc()
				RoleData.player_info.guide = 1020
				local ct_level = RoleData.player_info.ct_level
				if ct_level>10 then
					MainMapListener:setMapPos(0,-230)
				elseif ct_level>3 then
					MainMapListener:setMapPos(0,100)
				else
					MainMapListener:setMapPos(0,180)
				end
				self.HomeScene_Self:TouchOpenAdorn(1010202) -- 打开布置界面 提前打开【双人桌】切页
				self:checkGuide()
			end
			local ArrangeBtn = self.MainUI.Button_arrange
			self:CreateHandLayer(ArrangeBtn,callfunc,0.5)
		elseif guide == 1020 then 			-- 引导点击 地板
			local floor_node = CTTileData:getFloorNode(6,3) or CTTileData:getFloorNode(2,2)
			local function callfunc()
				RoleData.player_info.guide = 1030
				floor_node:addCircleNode() 	-- 添加圆圈选择框
				self:checkGuide()
			end
			self:CreateHandLayer(floor_node,callfunc)
		elseif guide == 1030 then 			-- 引导点击一键【铺满地板】按钮
			local Btn_UI = CTTileData.CircleNode:getButtonUI(1) -- 一键铺满按钮
			local function callfunc()
				RoleData.player_info.guide = 1040
				CTTileData.CircleNode:TouchOneForAll() 	-- 铺满回调
				self:checkGuide()
			end
			self:CreateHandLayer(Btn_UI,callfunc)
		elseif guide == 1040 then 			-- 引导点击 墙纸
			local wall_node = CTWallData:getWallNode(0,4)
			local function callfunc()
				RoleData.player_info.guide = 1050
				wall_node:addCircleNode() 	-- 添加圆圈选择框
				self:checkGuide()
			end
			self:CreateHandLayer(wall_node,callfunc)
		elseif guide == 1050 then 			-- 引导点击一键【铺满墙纸】按钮
			local Btn_UI = CTTileData.CircleNode:getButtonUI(1) -- 一键铺满按钮
			local function callfunc()
				RoleData.player_info.guide = 1060
				CTTileData.CircleNode:TouchOneForAll() 	-- 铺满回调
				-- 两次一键铺满后对话
				local function SetGuideIDFunc()
					self:checkGuide()
				end
				local layer = CTGuideLayer.new(CTGuideString[61],SetGuideIDFunc)
				display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			end
			self:CreateHandLayer(Btn_UI,callfunc)
		elseif guide == 1060 then 			-- 引导点击 布置界面内的装修按钮
			local function callfunc()
				RoleData.player_info.guide = 1070
				self.DressLayer_Self:TouchOpenZxLayer()
				self:checkGuide()
			end
			self:CreateHandLayer(self.DressLayerUI.Button_furniture,callfunc)
		elseif guide == 1070 then 			-- 引导点击双人桌 预览
			CTGuideManage.Preview_Guide = 1070
			local Cell_node = self.FurnitureLayer_Self:CheckGuide()
			local function callfunc()
				Cell_node.TouchLookFunc() 	-- 添加 双人桌 进地图
				CTTileData.CircleNode:Clean()
				-- 添加需要裁剪的部位~
				local table_node = CTTileData:CheckGuide(0) -- 框住双人桌
				local HandLayer = self:CreateHandLayer(table_node,nil,0.5,true)
				-- 添加NPC对话界面
				local function SetGuideIDFunc()
					HandLayer:removeSelf()
					RoleData.player_info.guide = 1080
					self:checkGuide()
				end
				local layer = CTGuideLayer.new(nil,SetGuideIDFunc)
				layer:setBackGroundColorOpacity(math.floor(0*0xff))
				display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
			end
			self:CreateHandLayer(Cell_node.Image_quality,callfunc,0.5)
		elseif guide == 1080 then 	-- 引导点击保存
			local function callfunc()
				CTGuideManage.Save_Guide = 1080 
				CTGuideManage.SaveSuccess_Guide = 1090
				self.DressLayer_Self:CheckGuide() 	-- 发送装饰保存消息 并 判断执行后续引导
				--//*
				-- NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1090})
				-- RoleData.player_info.guide = 1090
				-- self:checkGuide()
				--*// 将放到保存按钮回调中 进行一次判断 如果不能保存中断后续引导
			end
			self:CreateHandLayer(self.DressLayerUI.Button_3,callfunc)
		----------------------------------------------------------------------------
		elseif guide == 1090 then 	-- 将保存后 引导对话
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 1100
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[62],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 1100 then 	-- 引导点击 地板 （准备升级）
			local floor_node = CTTileData:getFloorNode(6,3) or CTTileData:getFloorNode(6,6)
			local function callfunc1()
				floor_node:addCircleNode() 	-- 添加圆圈选择框
				local Btn_UI = CTTileData.CircleNode:getButtonUI(2) -- 引导点击 升级装饰 按钮
				local function callfunc2()
					RoleData.player_info.guide = 1120
					CTTileData.CircleNode:TouchForUpLevel() 	-- 打开升级界面
					self:checkGuide()
				end
				self:CreateHandLayer(Btn_UI,callfunc2)
			end
			self:CreateHandLayer(floor_node,callfunc1)
		elseif guide == 1120 then 	-- 引导点确定升级 地板
			local UpLevel_UI = CTTileData.CircleNode:CheckGuide()
			local function callfunc()
				UpLevel_UI.TouchUpLevelForGuide() 	-- 地板 升级回调
				CTTileData.CircleNode:Clean()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1130})
				RoleData.player_info.guide = 1130
				self:checkGuide()
			end
			self:CreateHandLayer(UpLevel_UI.Button_buy,callfunc)
		elseif guide == 1130 then 	-- 引导点击 单人桌 （准备升级）
			local table_node = CTTileData:CheckGuide(1)
			local function callfunc1()
				table_node:addCircleNode() 	-- 添加圆圈选择框
				local Btn_UI = CTTileData.CircleNode:getButtonUI(2) -- 引导点击 升级装饰 按钮
				local function callfunc2()
					RoleData.player_info.guide = 1140
					CTTileData.CircleNode:TouchForUpLevel() 	-- 打开升级界面
					self:checkGuide()
				end
				self:CreateHandLayer(Btn_UI,callfunc2)
			end
			self:CreateHandLayer(table_node,callfunc1)
		elseif guide == 1140 then 	-- 引导点确定升级 单人桌
			local UpLevel_UI = CTTileData.CircleNode:CheckGuide()
			local function callfunc()
				UpLevel_UI.TouchUpLevelForGuide() 	-- 单人桌 升级回调
				CTTileData.CircleNode:Clean()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1150})
				RoleData.player_info.guide = 1150
				self:checkGuide()
			end
			self:CreateHandLayer(UpLevel_UI.Button_buy,callfunc)
		elseif guide == 1150 then 	-- 引导点击 双人桌 （准备升级）
			local table_node = CTTileData:CheckGuide(2)
			local function callfunc1()
				table_node:addCircleNode() 	-- 添加圆圈选择框
				local Btn_UI = CTTileData.CircleNode:getButtonUI(2) -- 引导点击 升级装饰 按钮
				local function callfunc2()
					RoleData.player_info.guide = 1160
					CTTileData.CircleNode:TouchForUpLevel() 	-- 打开升级界面
					self:checkGuide()
				end
				self:CreateHandLayer(Btn_UI,callfunc2)
			end
			self:CreateHandLayer(table_node,callfunc1)
		elseif guide == 1160 then 	-- 引导点确定升级 双人桌
			local UpLevel_UI = CTTileData.CircleNode:CheckGuide()
			local function callfunc()
				UpLevel_UI.TouchUpLevelForGuide() 	-- 双人桌 升级回调
				CTTileData.CircleNode:Clean()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 1170})
				RoleData.player_info.guide = 1170
				self:checkGuide()
			end
			self:CreateHandLayer(UpLevel_UI.Button_buy,callfunc)
		elseif guide == 1170 then 	-- 引导升级成功后NPC对话
			local function SetGuideIDFunc()
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 2000})
				RoleData.player_info.guide = 2000
				-- 引导点击关闭
				local function callfunc() 
					self.DressLayer_Self:CloseLayer()
					self.DressLayer_Self = nil
					self:checkGuide()
				end
				self:CreateHandLayer(self.DressLayerUI.Button_guanbi,callfunc)
			end
			local layer = CTGuideLayer.new(CTGuideString[70],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		end
	-----------------------引导从装扮界面出来-----------------------------
	elseif guide >= 2000 and guide<10000 then 	
		if guide == 2000 then -- 引导装扮保存并且推出装扮界面 后NPC 对话
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 2010
				self:checkGuide()
			end
			local layer = CTGuideLayer.new(CTGuideString[80],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		elseif guide == 2010 then 	-- 引导点击左下角经营按钮
			local function callfunc()
				RoleData.player_info.guide = 2020
				self.HomeScene_Self:TouchOpenChapter()
				self:checkGuide()
			end
			local ChapterBtn = self.MainUI.Button_run
			self:CreateHandLayer(ChapterBtn,callfunc)
		elseif guide == 2020 then 	-- 引导点击第二章节
			local Chapter_Cell = self.ChapterLayer_Self:CheckGuide()
			local function callfunc()
				Chapter_Cell.OpenChapterFunc(true) -- 发送第二章开店
				NetEngine:sendMessage(game_cmd.CSetGuide,{guide = 10000})
				RoleData.player_info.guide = 2030
				self.ChapterLayer_Self:CloseLayer()
				self.ChapterLayer_Self = nil
				self:checkGuide()
			end
			self:CreateHandLayer(Chapter_Cell.Image_chapter,callfunc,0.5)
		elseif guide == 2030 then
			local function SetGuideIDFunc()
				RoleData.player_info.guide = 10000
				CTSearchCenter:OpenSearchPath() -- 开店
				-- self:checkGuide()
				-- END GUIDE
				print("新手引导 全部执行完了！")
			end
			local layer = CTGuideLayer.new(CTGuideString[90],SetGuideIDFunc)
			display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		end
	end
end
function CTGuideManage:checkRuanGuide() -- 软引导
	local guide = RoleData.player_info.guide
	local ShowManageBtn_Key = self.HomeScene_Self:getManageBtnPos()
	if guide==10000 then --
		if not Ruan_Guide then
			if ShowManageBtn_Key then
				Ruan_Guide = 1
				self:checkRuanGuide()
			else
				local function callfunc()
					Ruan_Guide = 1
					self.HomeScene_Self:ManageBtnTouchFunc()
					self:checkRuanGuide()
				end
				local ManageBtn = self.MainUI.Button_manadge
				self:CreateRuanLayer(ManageBtn,callfunc)
			end
		elseif Ruan_Guide == 1 then
			local function callfunc()
				Ruan_Guide = nil
				self.HomeScene_Self:TouchOpenDecorate()
			end
			local DecorateBtn = self.MainUI.Button_decorate -- 装修按钮
			self:CreateRuanLayer(DecorateBtn,callfunc,0.5)
		end
		return
	end
end
-- 软引导界面
function CTGuideManage:CreateRuanLayer(node_tar,callfunc,delayTime) 
	local delay = delayTime or 0
	local HandLayer = FZutil.createUILayer()
	HandLayer:setTouchEnabled(true)
    HandLayer:setContentSize(display.width,display.height)
	HandLayer:setBackGroundColorOpacity(math.floor(0*0xff))
	self.HomeScene_Self:addChild(HandLayer,-1) -- 这样因为是软引导 所以层级设置最低
	performWithDelay(HandLayer, function ()
		local Point = cc.p(0,0)
		local Rect_Size = {width = 0, height = 0}
		if node_tar then
			local par=node_tar:getParent()
			if tolua.isnull(node_tar) then
				Alert:show("",Language.guideui.guide_fail..RoleData.player_info.guide)
		        MyApp:restart()
				return
			end
		    local tpx,tpy=node_tar:getPosition()
		    Point=par:convertToWorldSpace({x=tpx,y=tpy})
			Rect_Size = node_tar:getContentSize()
		end
		-------------------测试自制裁剪大小框---------------------- 
	    -- 添加手指特效
    	-- 设置触摸层~
		local TouchRect = FZutil.createUILayer()
	    TouchRect:setContentSize(Rect_Size)
	    TouchRect:setAnchorPoint(0.5,0.5)
	    TouchRect:setBackGroundColorOpacity(math.floor(0*0xff))
	    TouchRect:setPosition(Point)
	    HandLayer:addChild(TouchRect)
	    local hand = IconPath.otherSpineModle("Yindao")
		hand:setAnchorPoint(0.5,0.5)
		hand:addAnimation(0, "paiji",true)
	    hand:setPosition(Point)
	    HandLayer:addChild(hand,999)
	    -- 添加触摸回调
	    TouchRect:onTouch(function(event)
	        if event.name == "ended" then
	        	if callfunc then
	        		callfunc()
	        		callfunc = nil
	        	end
	        	HandLayer:removeSelf()
	        	HandLayer = nil
	        end
	    end)
	end,delay)
	HandLayer:onTouch(function(event)
        if event.name == "ended" and callfunc then
        	HandLayer:removeSelf()
        	HandLayer = nil
        end
    end)
end
-- 手指特效引导界面
function CTGuideManage:CreateHandLayer(node_tar,callfunc,delayTime,Has_Hand_key,UISize)
	local guide = RoleData.player_info.guide
	local delay = delayTime or 0
	local HandLayer = FZutil.createUILayer()
	HandLayer:setTouchEnabled(true)
    HandLayer:setContentSize(display.width,display.height)
    HandLayer:setBackGroundColorOpacity(math.floor(Color_Opacity*0xff))
	display.getRunningScene():addChild(HandLayer,Clipp_Node_Zorder)
	performWithDelay(HandLayer, function ()
		local Point = cc.p(0,0)
		local Rect_Size = {width = 0, height = 0}
		if node_tar then
			if tolua.isnull(node_tar) then
				Alert:show("","引导出现错误~"..RoleData.player_info.guide)
		        MyApp:restart()
				return
			end
			local par=node_tar:getParent()
		    local tpx,tpy=node_tar:getPosition()
		    if UISize then
		    	Point=par:convertToWorldSpace({x=UISize.x,y=UISize.y})
				Rect_Size = cc.size(UISize.width,UISize.height)
		    else
		    	Point=par:convertToWorldSpace({x=tpx,y=tpy})
				Rect_Size = node_tar:getContentSize()
		    end
		else
			Rect_Size = zuoliao_Cell_size
		end
		if Rect_Size.width == 0 and Rect_Size.width == Rect_Size.height then
    		HandLayer:setBackGroundColorOpacity(math.floor(Color_Opacity*0xff))
    		if guide == 5 or guide == 7 or guide == 9 or guide == 13 or guide == 15 then -- 引导5、7、9、13、15点击管理格子
    			Rect_Size = pet_add_btn_size
    		elseif guide == 6 or guide == 8 or guide == 10 then 	-- 引导6、8、10点击宠物格子
    			Rect_Size = pet_cell_size
    		-- elseif guide == 30 or guide == 63 then
    		-- 	Rect_Size = Mission_Box_Size
    		-- 	Point = cc.p(Point.x-320,Point.y)
    		elseif guide == 1020 or guide == 1100 then -- 地板
    			local scale = MainMapListener:getMapScale()
    			Rect_Size.width ,Rect_Size.height = CTTileData.TileSize.width*scale , CTTileData.TileSize.height*scale
    			Point = cc.p(Point.x+scale*(Rect_Size.width/2),Point.y+scale*(Rect_Size.height/2))
    		elseif guide == 1040 then -- 墙纸
    			local scale = MainMapListener:getMapScale()
    			Rect_Size.width ,Rect_Size.height = CTWallData.WallSize.width*scale , CTWallData.WallSize.height*scale
    			Point = cc.p(Point.x+scale*(Rect_Size.width/2),Point.y+scale*(Rect_Size.height/2-CTTileData.TileSize.height/2))
    		elseif guide == 1130 then -- 单人桌
    			Rect_Size.width ,Rect_Size.height = 220,170
    		elseif guide == 1070 or guide == 1150 then -- 双人桌
    			local scale = MainMapListener:getMapScale()
    			Rect_Size.width ,Rect_Size.height = 265,170
    			Point = cc.p(Point.x+scale*(Rect_Size.width/4),Point.y-scale*(Rect_Size.height/5))
    		end
    	elseif guide == 17 then 	-- 菜价框框大小
    		Rect_Size.width ,Rect_Size.height = 160,40
		elseif guide == 2020 then
			Rect_Size.width ,Rect_Size.height = 240,485 -- 章节框框
    		Point = cc.p(Point.x,Point.y-100)
		elseif guide == 35 then
			-- Rect_Size.width ,Rect_Size.height = 111,222
			Point = cc.p(111/2,display.height/2)
		elseif guide == 38 or guide == 40 or guide == 42 or guide == 44 then
			Rect_Size = zuoliao_Text_Size
		end
		-- 设置裁剪框~
		-- HandLayer:setBackGroundColorOpacity(math.floor(0*0xff))
		-- local clippingNode,node,lay = self:get_guan_node(Rect_Size)
		-- HandLayer:addChild(clippingNode,Clipp_Node_Zorder)
		-- clippingNode:setPosition(0,0)
		-- lay:setPosition(Point)
		-------------------测试自制裁剪大小框---------------------- 
		-- 设置裁剪框~
		HandLayer:setBackGroundColorOpacity(math.floor(0*0xff))
	    local clippingNode,GuideBox,lay = self:get_guan_node(Rect_Size)
		HandLayer:addChild(clippingNode,Clipp_Node_Zorder)
		clippingNode:setPosition(0,0)
		HandLayer:addChild(GuideBox,Clipp_Node_Zorder)
		GuideBox:setPosition(Point)
		lay:setPosition(Point)
		-------------------测试自制裁剪大小框---------------------- 
	    -- 添加手指特效
	    if not Has_Hand_key then
	    	-- 设置触摸层~
			local TouchRect = FZutil.createUILayer()
		    TouchRect:setContentSize(Rect_Size)
		    TouchRect:setAnchorPoint(0.5,0.5)
		    TouchRect:setBackGroundColorOpacity(math.floor(0*0xff))
		    TouchRect:setPosition(Point)
		    HandLayer:addChild(TouchRect)
		    local hand = IconPath.otherSpineModle("Yindao")
			hand:setAnchorPoint(0.5,0.5)
			hand:addAnimation(0, "paiji",true)
		    hand:setPosition(Point)
		    HandLayer:addChild(hand,999)
		    -- 添加触摸回调
		    TouchRect:onTouch(function(event)
		        if event.name == "ended" then
		        	HandLayer:removeSelf()
		        	if callfunc then
		        		callfunc()
		        		callfunc = nil
		        	end
		        end
		    end)
	    end
	end,delay)
	return HandLayer
end
-- 裁剪界面（添加在带手指的引导界面）
function CTGuideManage:get_guan_node(size)
	local clipp_size = {width = 0,height = 0}
    clipp_size.width = size.width * 1.05
    clipp_size.height = size.height * 1.05
    local clippingNode = cc.ClippingNode:create()       --1:创建clippingNode
    local GuideBox = FZutil.createSceneNode("GonggongUI.Node_guidebox")
    GuideBox.Image_kuang:setContentSize(clipp_size.width+23,clipp_size.height+23)
    --[[draw 代码段注释放在后面
    // ** //
    -- addcChile(draw)]]
    local Stencil = cc.Node:create()
    clippingNode:setStencil(Stencil)   --2:设置模板Stencil
    --local content=ccui.ImageView:create("UI/PvpUI/ctjjcui_beijing.jpg")
    local content = ccui.Layout:create()
    content:setContentSize(display.width,display.height)
    content:setOpacity(0.35*0xff)
    content:setBackGroundColor(cc.c3b(0,0,0))
    content:setBackGroundColorOpacity(math.floor(Color_Opacity*0xff))
    content:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    
    clippingNode:addChild(content)      --3:设置底板
    clippingNode:setInverted(true)     --4:倒置显示（Inverted）,false显示被模板裁剪下来的底板内容。默认为false。 true显示剩余部分。
    --5:alpha阈值（表示像素的透明度值。）只有模板（stencil）中像素的alpha值大于alpha阈值时，内容才会被绘制。
    --取值范围 [0,1] 。默认为 1  ，表示alpha测试默认关闭，即全部绘制。若不是1  ，表示只绘制模板中，alpha像素大于alphaThreshold的内容。
    clippingNode:setAlphaThreshold(0.05)
    local lay = ccui.Layout:create()
    lay:setContentSize(clipp_size)
    lay:setOpacity(0)
    lay:setBackGroundColor(cc.c3b(0,0,0))
    lay:setBackGroundColorOpacity(math.floor(0.5*0xff))
    lay:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    Stencil:addChild(lay)
    lay:setAnchorPoint(0.5,0.5)
    lay:setContentSize(clipp_size)
    Stencil:addChild(lay)
    return clippingNode,GuideBox.root,lay
end
-- **********************************下面是 新手引导后的 界面引导******************************************
function CTGuideManage:initGuideOnPetSceneLayer(PetSceneUI,PetScene_Self)
	self.PetSceneUI = PetSceneUI 
	self.PetScene_Self = PetScene_Self
end
function CTGuideManage:initGuideOnPetDetailLayer(PetDetailUI,PetDetail_Self)
	self.PetDetailUI = PetDetailUI 
	self.PetDetail_Self = PetDetail_Self
end
function CTGuideManage:initGuideOnPetfavourLayer(PetfavourUI,Petfavour_Self)
	self.PetfavourUI = PetfavourUI 
	self.Petfavour_Self = Petfavour_Self
end
function CTGuideManage:initGuideOnCTRankLayer(RankLayerUI,RankLayer_Self)
	self.RankLayerUI = RankLayerUI 
	self.RankLayer_Self = RankLayer_Self
end
function CTGuideManage:initGuideOnPresentLayer(PresentUI,Present_Self)
	self.PresentUI = PresentUI 
	self.Present_Self = Present_Self
end
function CTGuideManage:initGuideOnPresentSceneLayer(PresentSceneUI,PresentScene_Self)
	self.PresentSceneUI = PresentSceneUI 
	self.PresentScene_Self = PresentScene_Self
end
function CTGuideManage:initGuideOnMissionLayer(MissionLayerUI,MissionLayer_Self)
	self.MissionLayerUI = MissionLayerUI 
	self.MissionLayer_Self = MissionLayer_Self
end
-------------------------宠物引导--------------------------------
function CTGuideManage:petCheckGuide(guide_index)
	local player_guide = RoleData.player_info.guide
	local close_key = false
	if player_guide<10000 or not open_Guide or close_key then -- 需要新手引导完才触发
		return
	end
	local On_Guide = cc.UserDefault:getInstance():getIntegerForKey("petGuide")
	if not On_Guide or On_Guide<=0 then -- 一次没有执行
		On_Guide = 1
		cc.UserDefault:getInstance():setIntegerForKey("petGuide",1)
	elseif On_Guide>=10000 then -- 已经执行过啦
		return
	end
	-- 初始化引导值
	local guide = guide_index-- or On_Guide
	-- if guide>On_Guide then
	-- 	print("出现 跨触发界面 触发引导~ 给予屏蔽~")
	-- 	return 
	-- end
	print("开始引导宠物界面 guide："..guide)
	if guide == 1 then -- 引导点击宠物可可
		local petCell,UISize = self.PetScene_Self:getGuideNeed()
		if not petCell then
			cc.UserDefault:getInstance():setIntegerForKey("petGuide",10000)
			return
		end
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[100],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local Image_pet = petCell.Image_kuang1
		local function callfunc()
			petCell.TouchCallfunc(true)
			layer:removeSelf()
		end
		self:CreateHandLayer(Image_pet,callfunc,nil,nil,UISize)
	elseif guide == 2 then -- 宠物详情界面说话
		local function SetGuideIDFunc()
			self:petCheckGuide(3)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[101],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 3 then -- 引导点击耳朵
		local Image_pet = self.PetDetailUI.Image_pet
		-- 添加需要裁剪的部位~
		local UISize = self.PetDetail_Self:getGuideNeed(1)
		local function callfunc()
			self.PetDetail_Self:getGuideNeed()
			self:petCheckGuide(4)
		end
		UISize.width, UISize.height = UISize.width*3, UISize.height*3
		self:CreateHandLayer(Image_pet,callfunc,nil,nil,UISize)
	elseif guide == 4 then -- 点击完耳朵说话
		local function SetGuideIDFunc()
			self:petCheckGuide(5)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[102],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 5 then -- 引导点击脸部
		local Image_pet = self.PetDetailUI.Image_pet
		-- 添加需要裁剪的部位~
		local UISize = self.PetDetail_Self:getGuideNeed(2)
		local function callfunc()
			self.PetDetail_Self:getGuideNeed()
			self:petCheckGuide(6)
		end
		UISize.width, UISize.height = UISize.width*3, UISize.height*3
		self:CreateHandLayer(Image_pet,callfunc,nil,nil,UISize)
	elseif guide == 6 then -- BB
		local function SetGuideIDFunc()
			self:petCheckGuide(7)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[103],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 7 then -- 引导点击增加好感度按钮
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[104],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local Button_add = self.PetDetailUI.Button_add
		local UISize = {x=0,y=0,width=0,height=0}
		local size = Button_add:getContentSize()
		UISize.width, UISize.height = size.width*2, size.height*2
		local x,y = Button_add:getPosition()
		UISize.x, UISize.y = x,y
		local function callfunc()
			layer:removeSelf()
			self.PetDetail_Self:getGuideNeed(99)
			self:petCheckGuide(8)
		end
		self:CreateHandLayer(Button_add,callfunc,nil,nil,UISize)
	elseif guide == 8 then -- 好感度道具界面说话
		local function SetGuideIDFunc()
			self:petCheckGuide(9)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[105],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 9 then -- 引导点击好感度道具使用
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[106],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local Button_prop = nil
		if self.Petfavour_Self:getGuideNeed(1) then
			Button_prop = self.Petfavour_Self:getGuideNeed(1).Image_di
		else
			layer:removeSelf()
			cc.UserDefault:getInstance():setIntegerForKey("petGuide",10000)
			return
		end
		local function callfunc()
			layer:removeSelf()
			self.Petfavour_Self:getGuideNeed(2)
			cc.UserDefault:getInstance():setIntegerForKey("petGuide",10000)
		end
		self:CreateHandLayer(Button_prop,callfunc,nil,nil,UISize)
	end
end
-------------------------排行榜引导------------------------------
function CTGuideManage:rankCheckGuide(guide_index)
	local player_guide = RoleData.player_info.guide
	if player_guide<10000 or not open_Guide then -- 需要新手引导完才触发
		return
	end
	local On_Guide = cc.UserDefault:getInstance():getIntegerForKey("rankGuide")
	if not On_Guide or On_Guide<=0 then -- 一次没有执行
		On_Guide = 1
		cc.UserDefault:getInstance():setIntegerForKey("rankGuide",1)
	elseif On_Guide>=10000 then -- 已经执行过啦
		return
	end
	-- 初始化引导值
	local guide = guide_index
	print("开始引导排行榜界面 guide："..guide)
	if guide == 1 then -- 在排行界面说话
		local function SetGuideIDFunc()
			self:rankCheckGuide(2)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[200],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 2 then -- 框住人气排行按钮说话
		-- 添加需要裁剪的部位~
		local CheckBox_popularity = self.RankLayerUI.CheckBox_popularity
		local HandLayer = self:CreateHandLayer(CheckBox_popularity,nil,0,true) -- 不需要手指特效
		-- 添加NPC对话界面
		local function SetGuideIDFunc()
			HandLayer:removeSelf()
			self:rankCheckGuide(3)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[201],SetGuideIDFunc)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 3 then -- 框住联赛排行左边切页按钮说话
		-- 添加需要裁剪的部位~
		local Button_fanye2 = self.RankLayerUI.Button_fanye2
		local UISize = {x=0,y=0,width=0,height=0}
		local size = Button_fanye2:getContentSize()
		UISize.width, UISize.height = size.width*3, size.height*2
		UISize.x, UISize.y = Button_fanye2:getPosition()
		local HandLayer = self:CreateHandLayer(Button_fanye2,nil,0,true,UISize) -- 不需要手指特效
		-- 添加NPC对话界面
		local function SetGuideIDFunc()
			HandLayer:removeSelf()
			self:rankCheckGuide(4)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[202],SetGuideIDFunc)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 4 then -- 引导点击左边切页说话
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[203],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local Button_fanye2 = self.RankLayerUI.Button_fanye2
		local UISize = {x=0,y=0,width=0,height=0}
		local size = Button_fanye2:getContentSize()
		UISize.width, UISize.height = size.width*3, size.height*2
		UISize.x, UISize.y = Button_fanye2:getPosition()
		local function callfunc()
			layer:removeSelf()
			self.RankLayer_Self:getGuideNeed(99)
			self:rankCheckGuide(5)
		end
		self:CreateHandLayer(Button_fanye2,callfunc,nil,nil,UISize)
	elseif guide == 5 then -- 
		local function SetGuideIDFunc()
			cc.UserDefault:getInstance():setIntegerForKey("rankGuide",10000)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[204],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	end
end
-------------------------礼包界面引导----------------------------
function CTGuideManage:presentCheckGuide(guide_index)
	local player_guide = RoleData.player_info.guide
	if player_guide<10000 or not open_Guide then -- 需要新手引导完才触发
		return
	end
	local On_Guide = cc.UserDefault:getInstance():getIntegerForKey("presentGuide")
	if not On_Guide or On_Guide<=0 then -- 一次没有执行
		On_Guide = 1
		cc.UserDefault:getInstance():setIntegerForKey("presentGuide",1)
	elseif On_Guide>=10000 then -- 已经执行过啦
		return
	end
	-- 初始化引导值
	local guide = guide_index
	print("开始引导礼包界面 guide："..guide)
	if guide == 1 then -- 在礼包界面说话
		local function SetGuideIDFunc()
			self:presentCheckGuide(2)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[300],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 2 then -- 引导点击柯基币切页
		local Button_kejibi = self.PresentUI.CheckBox_kejibi
		-- 添加需要裁剪的部位~
		local function callfunc()
			self.Present_Self:getGuideNeed(2)
			self:presentCheckGuide(3)
		end
		self:CreateHandLayer(Button_kejibi,callfunc)
	elseif guide == 3 then -- 引导点击金币切页
		local Button_jinbi = self.PresentUI.CheckBox_jinbi
		-- 添加需要裁剪的部位~
		local function callfunc()
			self.Present_Self:getGuideNeed(3)
			self:presentCheckGuide(4)
		end
		self:CreateHandLayer(Button_jinbi,callfunc)
	elseif guide == 4 then -- 引导点击友情点切页
		local Button_youqingdian = self.PresentUI.CheckBox_youqingdian
		-- 添加需要裁剪的部位~
		local function callfunc()
			self.Present_Self:getGuideNeed(4)
			self:presentCheckGuide(5)
		end
		self:CreateHandLayer(Button_youqingdian,callfunc)
	elseif guide == 5 then -- 友情点界面说话
		local function SetGuideIDFunc()
			self:presentCheckGuide(6)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[301],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 6 then -- 友情点界面说话 并引导点击左边厂库切页
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[302],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local CheckBox_ck = self.PresentSceneUI.CheckBox_ck
		local function callfunc()
			self.PresentScene_Self:getGuideNeed()
			layer:removeSelf()
			cc.UserDefault:getInstance():setIntegerForKey("presentGuide",10000)
		end
		self:CreateHandLayer(CheckBox_ck,callfunc)
	end
end
-------------------------任务界面引导----------------------------
function CTGuideManage:missionCheckGuide(guide_index)
	local player_guide = RoleData.player_info.guide
	if player_guide<10000 or not open_Guide then -- 需要新手引导完才触发
		return
	end
	local On_Guide = cc.UserDefault:getInstance():getIntegerForKey("missionGuide")
	if not On_Guide or On_Guide<=0 then -- 一次没有执行
		On_Guide = 1
		cc.UserDefault:getInstance():setIntegerForKey("missionGuide",1)
	elseif On_Guide>=10000 then -- 已经执行过啦
		return
	end
	-- 初始化引导值
	local guide = guide_index
	print("开始引导任务界面 guide："..guide)
	if guide == 1 then -- 在任务界面说话
		local function SetGuideIDFunc()
			self:missionCheckGuide(2)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[400],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 2 then -- 引导点击支线任务（限时任务）
		local Button_sideline = self.MissionLayerUI.CheckBox_sideline
		-- 添加需要裁剪的部位~
		local function callfunc()
			self.MissionLayer_Self:getGuideNeed(2)
			self:missionCheckGuide(3)
		end
		self:CreateHandLayer(Button_sideline,callfunc)
	elseif guide == 3 then -- 支线任务切页说话
		local function SetGuideIDFunc()
			self:missionCheckGuide(4)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[401],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 4 then -- 引导点击每日任务切页
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[402],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local CheckBox_daily = self.MissionLayerUI.CheckBox_daily
		local function callfunc()
			self.MissionLayer_Self:getGuideNeed(3)
			layer:removeSelf()
			self:missionCheckGuide(5)
		end
		self:CreateHandLayer(CheckBox_daily,callfunc)
	elseif guide == 5 then -- 每日任务界面说话
		local function SetGuideIDFunc()
			self:missionCheckGuide(6)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[403],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 6 then -- 引导点击每周任务切页
		local Button_weekly = self.MissionLayerUI.CheckBox_weekly
		-- 添加需要裁剪的部位~
		local function callfunc()
			self.MissionLayer_Self:getGuideNeed(4)
			self:missionCheckGuide(7)
		end
		self:CreateHandLayer(Button_weekly,callfunc)
	elseif guide == 7 then -- 每周任务界面说话
		local function SetGuideIDFunc()
			cc.UserDefault:getInstance():setIntegerForKey("missionGuide",10000)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[404],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	end
end
-------------------------菜谱界面引导----------------------------
function CTGuideManage:menuCheckGuide(guide_index)
	local player_guide = RoleData.player_info.guide
	if player_guide<10000 or not open_Guide then -- 需要新手引导完才触发
		return
	end
	local On_Guide = cc.UserDefault:getInstance():getIntegerForKey("menuGuide")
	if not On_Guide or On_Guide<=0 then -- 一次没有执行
		On_Guide = 1
		cc.UserDefault:getInstance():setIntegerForKey("menuGuide",1)
	elseif On_Guide>=10000 then -- 已经执行过啦
		return
	end
	-- 初始化引导值
	local guide = guide_index
	print("开始引导任务界面 guide："..guide)
	if guide == 1 then -- 在菜谱界面说话
		local function SetGuideIDFunc()
			self:menuCheckGuide(2)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[500],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 2 then -- 框住解锁按钮 说话
		-- 添加需要裁剪的部位~
		local Menu_Cell = self.MenuSceneLayer_Self:CheckGuide()
		Menu_Cell.Button_produce:hide()
		Menu_Cell.Button_unlock:show()
		local Unlock_Btn = Menu_Cell.Button_unlock
		local HandLayer = self:CreateHandLayer(Unlock_Btn,nil,0.5,true) -- 不需要手指特效
		-- 添加NPC对话界面
		local function SetGuideIDFunc()
			HandLayer:removeSelf()
			self:menuCheckGuide(3)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[501],SetGuideIDFunc)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 3 then -- 菜谱界面说话
		local function SetGuideIDFunc()
			self:menuCheckGuide(4)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[502],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 4 then -- 引导点击研发按钮
		-- 添加NPC对话界面
		local layer = CTGuideLayer.new(CTGuideTwoString[503],nil)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		layer:setTouchEnabled(false)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
		-- 添加需要裁剪的部位~
		local Menu_Cell = self.MenuSceneLayer_Self:CheckGuide()
		Menu_Cell.Button_produce:show()
		Menu_Cell.Button_unlock:hide()
		local function callfunc()
			Menu_Cell.TouchOpenProduce()
			layer:removeSelf()
			self:menuCheckGuide(5)
		end
		local Produce_Btn = Menu_Cell.Button_produce
		self:CreateHandLayer(Produce_Btn,callfunc,0.5)
	elseif guide == 5 then -- 框住调味料说话
		-- 添加需要裁剪的部位~
		local Cailiao_Node = self.MenuProduceLayerUI.ScrollView_cailiao
		local UISize = {x=0,y=0,width=0,height=0}
		local size = Cailiao_Node:getContentSize()
		UISize.width, UISize.height = size.width, size.height
		local x,y = Cailiao_Node:getPosition()
		UISize.x, UISize.y = x+size.width/2,y+size.height/2
		local HandLayer = self:CreateHandLayer(Cailiao_Node,nil,0,true,UISize) -- 不需要手指特效
		-- 添加NPC对话界面
		local function SetGuideIDFunc()
			HandLayer:removeSelf()
			self:menuCheckGuide(6)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[504],SetGuideIDFunc)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 6 then -- 框住食材说话
		-- 添加需要裁剪的部位~
		local Cailiao_Node = self.MenuProduceLayerUI.Image_di1
		local UISize = {x=0,y=0,width=0,height=0}
		local size = Cailiao_Node:getContentSize()
		UISize.width, UISize.height = size.width, size.height+80
		local x,y = Cailiao_Node:getPosition()
		UISize.x, UISize.y = x,y+40
		local HandLayer = self:CreateHandLayer(Cailiao_Node,nil,0,true,UISize) -- 不需要手指特效
		-- 添加NPC对话界面
		local function SetGuideIDFunc()
			HandLayer:removeSelf()
			self:menuCheckGuide(7)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[505],SetGuideIDFunc)
		layer:setBackGroundColorOpacity(math.floor(0*0xff))
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	elseif guide == 7 then -- 说话
		local function SetGuideIDFunc()
			cc.UserDefault:getInstance():setIntegerForKey("menuGuide",10000)
		end
		local layer = CTGuideLayer.new(CTGuideTwoString[506],SetGuideIDFunc)
		display.getRunningScene():addChild(layer,NPC_Talk_Zorder)
	end
end
return CTGuideManage
--[[draw 注释代码
    local draw = cc.DrawNode:create()
    local filledVertices = {cc.p(-size.width/2,-size.height/2), cc.p(size.width/2, -size.height/2), cc.p(size.width/2, size.height/2), cc.p(-size.width/2, size.height/2)}  
    draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 1))
    local delay = cc.DelayTime:create(0.2)
    local Change_set1 = cc.CallFunc:create(function()
        draw:clear()
        draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 1))
    end)
    local Change_set2 = cc.CallFunc:create(function()
        draw:clear()
        draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 0.8))
    end)
    local Change_set3 = cc.CallFunc:create(function()
        draw:clear()
        draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 0.6))
    end)
    local Change_set4 = cc.CallFunc:create(function()
        draw:clear()
        draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 0.4))
    end)
    local Change_set5 = cc.CallFunc:create(function()
        draw:clear()
        draw:drawPolygon(filledVertices,4,cc.c4f(0, 0, 0, 0),1.0,cc.c4f(0.35, 0.97, 1, 0.2))
    end)
    local seq = cc.Sequence:create(delay,Change_set1,delay,Change_set2,delay,Change_set3,delay,Change_set4,delay,Change_set5,delay,Change_set4,delay,Change_set3,delay,Change_set2,delay,Change_set1)
    local ForeverSeq = cc.RepeatForever:create(seq)
    node:addChild(draw)
    draw:runAction(ForeverSeq) 
    ]]