local FZutil = require("app.FZutil")
-- local scheduler = require("src.cocos.framework.scheduler")
local FzCheckBoxGroup = require("app.FzWidget.FzCheckBoxGroup")
local CTRankCell = require("app.CTRank.CTRankCell")
local CTSelfRankLevel = require("app.CTRank.CTSelfRankLevel")
local CTAssignChapterRankRewardLayer = require("app.CTRank.CTAssignChapterRankRewardLayer")
local CTRankLayer = class("CTRankLayer", FZutil.createUILayer)
local Bg1_Path = {
    "UI/rankUI/bg/PH_01.png",
    "UI/rankUI/bg/PH_02.png",
    "UI/rankUI/bg/PH_03.png"
}
local leftName={
	"ranklevel",	-- 餐厅评级
	"popularity", 	-- 最具人气
	"income", 		-- 餐饮大亨
	"profit", 		-- 营销大师
	"pet", 			-- 宠物收集
	"cookbook",		-- 菜谱大全
	"favor", 		-- 宠物亲密
	"story", 		-- 见多识广
	"league", 		-- 美食联赛
	"ept",			-- 指定章節活動
}
-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	table.remove(leftName,1)
-- end
local TypeIndex = {
	1100, 	--餐厅评级
	101, 	--最高人气值排行榜（最具人气）
	102, 	--今日收入排行（餐饮大亨）
	103, 	--今日净利润排行（营销大师）
	104, 	--宠物拥有数量排名（宠物收集）
	105, 	--菜谱拥有数量排名（食谱大全）
	106, 	--宠物总好感等级排名（宠物亲密）
	107, 	--触发不同剧情数量排名（见多识广）
	108, 	--当日美食联赛排名（美食联赛）
	100, 	--指定章节活动排名
}

-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	table.remove(TypeIndex,1)
-- end

local rankImgName = {
	"Image_popularity",
	"Image_income",
	"Image_profit",
	"Image_pet",
	"Image_cookbook",
	"Image_favor",
	"Image_story",
	"Image_league",
	-- "Image_ranklevel",
	"Image_ept"
}

-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	-- table.remove(rankImgName,1)
-- end

local japanRankTypeId = {}
-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	japanRankTypeId = {
		[101] = 101,
		[102] = 102,
		[103] = 103
	}
-- end

local cell_size = {width = 240,height = 485}

local CELL_TOP = 10

local function getTypeId(type_id,curr_dan)
	local isRank = false
	if japanRankTypeId[type_id] then
		isRank = true
		if curr_dan then
			if type_id == 101 then
				type_id = 1100 + 16
			elseif type_id == 102 then
				type_id = 1100
			elseif type_id == 103 then
				type_id = 1100+32
			end

			type_id = type_id+curr_dan
		end
	end
	
	return type_id,isRank
end

function CTRankLayer:ctor(left_name)
	self:enableNodeEvents()
	FzEventCenter:DispichEvent(FzEvent.pauseEventListener)

	local RankUI = FZutil.createSceneNode("RankUI/RankUI")
	-- FZutil.windowShowEff(RankUI.root)
	self.RankUI = RankUI
	self:addChild(RankUI.root)

	self:initRankNameType()

	TopCurrencyNode:initCurrencyNode(RankUI.FileNode_currency)  -- 顶部金币等数据刷新
	CTGuideManage:initGuideOnCTRankLayer(RankUI,self)
	-- 1
	-- RankUI.root:setPosition(display.center)
	-- RankUI.Node_top:setPosition(0,display.height)
	-- RankUI.Node_bottom:setPosition(display.cx,20)
	-- 2
	RankUI.root:setPosition(display.center)
	RankUI.Image_background:setPosition(0,0)
	RankUI.Node_top:setPosition(-display.cx,display.cy)
	RankUI.Node_bottom:setPosition(0,-display.cy+12)
	--关闭
	RankUI.Button_guanbi:onTouch(function(e)
		if e.name == "ended" then
			self:CloseLayer()
			-- MyApp:popTopCloseLayer()
		end
	end)
	-- 设置左侧滚动层大小
	local scrollViewSize = RankUI.ScrollView_yeqian:getContentSize()
    local nCellH = 80
    local nStartY = scrollViewSize.height - nCellH/2
    local nCount = #leftName
    if nCellH * nCount > scrollViewSize.height then
        nStartY = nCellH * nCount - nCellH/2
    end
	if nCellH * nCount > scrollViewSize.height then
        RankUI.ScrollView_yeqian:setInnerContainerSize(cc.size(scrollViewSize.width, nStartY + nCellH/2))
    end
	for i,v in ipairs(leftName) do
		local checkBox = RankUI["CheckBox_"..v]
		checkBox:setPositionY(nStartY - (i - 1)*nCellH)
	end

	-- 定义数据表
	self.CellAlls = {}
	for k,TypeName in pairs(leftName) do
		self.CellAlls[TypeName] = {}
	end
	self.RankData = {}
	self.RankAllNum = {}
	--
	self:initTopCheckBox()

	local open_index = nil
	if left_name then
		for _i,_name in ipairs(leftName) do
			if _name == left_name then
				open_index = _i
			end
		end
	end
	
	self:initLeftCheckBox(open_index)

	self:sendCTLevel()
	-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		self:initJapanRankUI()
	-- end

	self:initRewardUI()

	MyApp:pushTopCloseLayer("CTRankLayer",function()
		self:CloseLayer()
	end)

	FZutil.displayAdaptation(RankUI.Node_bottom)
	-- 排行引导
	CTGuideManage:rankCheckGuide(1)
end

function CTRankLayer:initRankNameType()
	self.leftNameTemp = clone(leftName)
	self.TypeIndexTemp = clone(TypeIndex)
	self.rankImgNameTemp = clone(rankImgName)

	local isOpen = DyActivity:isActivityOpen( DyActivity.ASSIGN_CHAPTER )

	if isOpen==false then
		local bottom = self.RankUI.Node_bottom
		local img_di = bottom:getChildByName("Image_di")
		for i,v in ipairs(leftName) do
			if v == "ept" then
				table.remove(leftName,i)
				table.remove(TypeIndex,i)
				local childNode = img_di:getChildByName(rankImgName[i])
				if childNode then
					childNode:hide()
				end
				table.remove(rankImgName,i)
				break
			end
		end
	end
end

function CTRankLayer:sendCTLevel()
	--1100作废
	-- NetEngine:sendMessage(game_cmd.CGetSelfRank, {rank_type = 1100})
	NetEngine:sendMessage(game_cmd.CGetSelfDan)
end

function CTRankLayer:Button_rule_Callfunc()
	local sendRank_type = nil
	if self.dan then
		sendRank_type = 1100+self.dan
		local Data = self.RankSelfData and self.RankSelfData[sendRank_type] or nil
		if Data then
			sendRank_type = nil
		end
	end

	if sendRank_type then
		NetEngine:sendMessage(game_cmd.CGetSelfRank, {rank_type = sendRank_type})
	end
	self:setRankScroll(false)
end
function CTRankLayer:initTopCheckBox()
	-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		if self and self.RankUI then
			self.RankUI.Button_rule:onTouch(function(e)
				if e.name == "ended" then
					self:Button_rule_Callfunc() -- 提出来写方便引导调用
				end
			end)
			self.RankUI.Button_backrank:onTouch(function(e)
				if e.name == "ended" then
					self:setRankScroll(true)
				end
			end)
		end
		-- return
	-- end

	--旧cocos
	-- local RankUI = self.RankUI
	-- local ScrollView = RankUI.ScrollView_3
	-- self.TopCheckBox = {RankUI.CheckBox_zpaihang, RankUI.CheckBox_guize}
	-- local textImage1 = self.TopCheckBox[1]:getChildByName("Image_normal1s")
	-- local textImage2 = self.TopCheckBox[1]:getChildByName("Image_chosen1s")

	-- local textImage3 = self.TopCheckBox[2]:getChildByName("Image_normal2s")
	-- local textImage4 = self.TopCheckBox[2]:getChildByName("Image_chosen2s")
	-- for k,v in pairs(self.TopCheckBox) do
	-- 	v:ignoreContentAdaptWithSize(true)
	-- 	v:setBright(true)
 --   		v:setEnabled(true)
	-- 	v:onEvent(function(event)
	--         if event.name == "selected" then
	--             if k == 1 then					
	-- 				self:setRankScroll(true)
	-- 				self.TopCheckBox[1]:setEnabled(false)
	-- 				textImage1:hide()
	-- 				textImage2:show()
	-- 				textImage3:show()
	-- 				textImage4:hide()
	-- 				self.TopCheckBox[2]:setEnabled(true)
	-- 				self.TopCheckBox[2]:setSelected(false)
	--             else	            	            	
	-- 				self:setRankScroll(false)
	--             	self.TopCheckBox[1]:setSelected(false)
	--             	textImage1:show()
	-- 				textImage2:hide()
	-- 				textImage3:hide()
	-- 				textImage4:show()
	--             	self.TopCheckBox[1]:setEnabled(true)
	-- 				self.TopCheckBox[2]:setEnabled(false)
	--             end
	--         end
	--     end) 
	-- end
end
function CTRankLayer:checkBoxCallFunc(index)
	local RankUI = self.RankUI
	print("选中的切页ID "..index.." name:"..leftName[index])
	self:SetTitleVisible(index)
	-- 隐藏上一个切页Cell
	local TypeName = leftName[self.saveLeftIndex] or leftName[1] -- 重0开始的下标 对应左侧按钮的 下标
	for k,v in pairs(self.CellAlls[TypeName]) do
		if v then
			v.root:hide()
		end
	end
	self.saveLeftIndex = index
	self.curr_dan = self.dan

	self:setRewardSelect(1,index)

	-- 进入排行榜第一次获取得数据将会进行保存，如果想要比较新的数据
	-- 只要将保存的数据置为空表，将会从服务器获取最新的数据
	-- self.RankData = {}
	-- self.RankSelfData = {}

	self:UpdataCheckView()
	RankUI.FileNode_rankrule:hide()			
	self:setRankScroll(true)
	if self.saveLeftIndex == 1 then
		self:setTopBtnSee(true)
	else
		self:setTopBtnSee(false)
	end
end
function CTRankLayer:initLeftCheckBox(open_index)
	local RankUI = self.RankUI
	self.saveLeftIndex = open_index or 0
	local tipCheckBox = {}
	for i,v in ipairs(leftName) do
		local name = "CheckBox_"..v
		tipCheckBox[i] = RankUI[name]
	end
	local leftGroup = FzCheckBoxGroup.new(tipCheckBox)
	local fonts = {
		{RankUI.Image_normal1,RankUI.Image_chosen1},
		{RankUI.Image_normal2,RankUI.Image_chosen2},
		{RankUI.Image_normal3,RankUI.Image_chosen3},
		{RankUI.Image_normal4,RankUI.Image_chosen4},
		{RankUI.Image_normal5,RankUI.Image_chosen5},
		{RankUI.Image_normal6,RankUI.Image_chosen6},
		{RankUI.Image_normal7,RankUI.Image_chosen7},
		{RankUI.Image_normal8,RankUI.Image_chosen8},
		{RankUI.Image_normal9,RankUI.Image_chosen9},
	}

	-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		-- table.remove(fonts,1)
	-- end

	leftGroup:initFonts(fonts)
	leftGroup:addTo(RankUI.root)
	leftGroup:addSubChangeCallback(function(index)
		if self.saveLeftIndex ~= index then
			self:checkBoxCallFunc(index)
		end
	end)
	self.leftGroup = leftGroup
	self:SetLeftGroupSelect(open_index or 1) -- 初始选中1
	if self.saveLeftIndex == 1 then
		self:setTopBtnSee(true)
	else
		self:setTopBtnSee(false)
	end
end
function CTRankLayer:setRankScroll(see)
	local RankUI = self.RankUI

	local Type_index = self.saveLeftIndex

	print("******************")
	print(Type_index,see)
	print("******************")
	if see then
		RankUI.ScrollView_3:show()
		RankUI.FileNode_me:show()
		RankUI.Image_di:show()
		RankUI.FileNode_rankrule:hide()
		RankUI.Button_backrank:hide()
		RankUI.Button_rule:setVisible(Type_index == 1)
	else
		RankUI.ScrollView_3:hide()
		RankUI.FileNode_me:hide()
		RankUI.Image_di:hide()
		RankUI.FileNode_rankrule:show()
		RankUI.Button_rule:hide()
		RankUI.Button_backrank:setVisible(Type_index == 1)
	end
end
function CTRankLayer:setTopBtnSee(see)
	-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		if self and self.RankUI then
			self.RankUI.Button_rule:setVisible(see)
		end
		-- return
	-- end

	--旧cocos
	-- for k,v in pairs(self.TopCheckBox) do
	-- 	if see then
	-- 		v:show()
	-- 	else
	-- 		v:hide()
	-- 	end
	-- end
	-- if see then
	-- 	local textImage1 = self.TopCheckBox[1]:getChildByName("Image_normal1s")
	-- 	local textImage2 = self.TopCheckBox[1]:getChildByName("Image_chosen1s")
	-- 	local textImage3 = self.TopCheckBox[2]:getChildByName("Image_normal2s")
	-- 	local textImage4 = self.TopCheckBox[2]:getChildByName("Image_chosen2s")
	-- 	textImage1:hide()
	-- 	textImage2:show()
	-- 	textImage3:show()
	-- 	textImage4:hide()
	-- 	self.TopCheckBox[1]:setSelected(true)
	-- 	self.TopCheckBox[2]:setSelected(false)
	--     self.TopCheckBox[1]:setEnabled(false)
	--     self.TopCheckBox[2]:setEnabled(true)
	-- end
end
function CTRankLayer:SetLeftGroupSelect(index)
	self.leftGroup:setSelect(index) -- 初始选中1
end
function CTRankLayer:SetTitleVisible(index)
	local RankUI = self.RankUI
	for i,v in ipairs(leftName) do
		if index == i then
			RankUI["Image_"..v]:show()
		else
			RankUI["Image_"..v]:hide()
		end
	end
end

function CTRankLayer:UpdataCheckView()
	local index = self.saveLeftIndex -- 重0开始的下标 对应左侧按钮的 下标 
	local Type_index = TypeIndex[index]
	local TF_InitMe = true

	if japanRankTypeId[Type_index] then
		-- TF_InitMe = false
		if not self.curr_dan then
			-- 不需要获取单个排行类型的段位，段位会单独获取
			-- NetEngine:sendMessage(game_cmd.CGetSelfRank, {rank_type = Type_index})
			return
		end
	end

	scheduler.unscheduleGlobal(self.Sch_Cell)
	self.Sch_Cell = nil
	--
	local RankUI = self.RankUI
	local TypeName = leftName[index]
	local callTab =	self.CellAlls[TypeName]
	local rankData = self:getRankData(Type_index,self.curr_dan)
	if not rankData then
		local sendType_index = getTypeId(Type_index,self.curr_dan)
		NetEngine:sendMessage(game_cmd.CGetRankList, {type = sendType_index})
		return -- 请求完数据后 在刷新
	end
	print("index:"..index.." TypeName "..TypeName.." callTab num:"..#callTab)
    -- 加载前五十名
    local player_id = RoleData.player_info.player_id --自己ID
	local cellSize = {width = 847, height = 63}
	local MsgData = self:getRankData(Type_index,self.curr_dan)
	local ScrollView = RankUI.ScrollView_3
	ScrollView:setScale(1.0)
	ScrollView:jumpToTop()
	if MsgData and #MsgData>0 then
        local scrollContentSize = ScrollView:getContentSize()
        local max_num = #MsgData
        local cellH = cellSize.height
        local cellCountH = max_num*cellH+(max_num-1)*CELL_TOP
        if cellCountH>scrollContentSize.height then
            scrollContentSize.height = cellCountH
        end
        ScrollView:setInnerContainerSize(scrollContentSize)
        local k = 1
	    self.Sch_Cell = scheduler.scheduleGlobal(function()
	    	if k<= max_num then
	    		local Data = MsgData[k]
	    		local cellmap = self.CellAlls[TypeName][k]
				if not cellmap then
					cellmap = CTRankCell.create(index,Data)
					self.CellAlls[TypeName][k] = cellmap
					ScrollView:addChild(cellmap.root)
				else
					CTRankCell.create(index,Data,cellmap)
				end
				cellmap.root:show()
	            cellmap.root:setPosition(cellSize.width/2,scrollContentSize.height - k*cellH + cellH/2-5-(k-1)*CELL_TOP)
	    		k = k + 1
	        else
				scheduler.unscheduleGlobal(self.Sch_Cell)
				self.Sch_Cell = nil
	    	end
		end,1/30)
    end

    local msgCount = #MsgData
    local tabCount = #callTab
    for i = msgCount+1,tabCount do
    	local cellmap = callTab[i]
    	if cellmap then
    		cellmap.root:hide()
    	end
    end

    if TF_InitMe then -- 没上榜 只能自己请求自己的数据咯
    	self:initMeData(Type_index)
    end

    -- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		self:japanTopDanUI( self.curr_dan )
	-- end
end

--请求自己的数据
function CTRankLayer:initMeData(type_index,curr_dan)
	curr_dan = curr_dan or self.curr_dan
	local sendRank_type = getTypeId(type_index,curr_dan)
	-- if self.requireRankType and self.requireRankType == sendRank_type then
	-- else
	if self.dan and self.dan == curr_dan then
		local Data = self.RankSelfData and self.RankSelfData[sendRank_type] or nil
		if Data then
			self:UpdataSelfView(Data)
		else
			NetEngine:sendMessage(game_cmd.CGetSelfRank, {rank_type = sendRank_type})
		end
	else
		local Data = {rank = 0, score = 0, count = 0, dan = 0}
		self:UpdataSelfView(Data)
	end
	-- end
end

function CTRankLayer:UpdataSelfView(Data)
	local MeRankUI = self.RankUI.FileNode_me
	local index = self.saveLeftIndex -- 重0开始的下标 对应左侧按钮的 下标
	local Type_index = TypeIndex[index]
	if Data then
		MeRankUI:show()
		local headkuang = MeRankUI:getChildByName("Image_headkuang")
		headkuang:getChildByName("Image_head"):loadTexture(IconPath.PetHeadIcon( RoleData.player_info.icon_id ))
		MeRankUI:getChildByName("Text_playerlvl_M"):setString(RoleData.player_info.level)
		MeRankUI:getChildByName("Text_name1_M"):setString(RoleData.player_info.name)
		MeRankUI:getChildByName("Text_name2_M"):setString("-")
		MeRankUI:getChildByName("Image_percentme"):hide() -- “%”
		MeRankUI:getChildByName("Image_pre"):hide() -- 前
		MeRankUI:getChildByName("Image_rankpic")
		local rankTxt = MeRankUI:getChildByName("AtlasLabel_rank")
		local rankBg = MeRankUI:getChildByName("Image_rankpic")-- 排名底图
		rankBg:hide() 
		rankBg:ignoreContentAdaptWithSize(true)
		local rank = Data.rank
		rankTxt:setString(rank)
		rankTxt:show()
		if rank>100 and self.RankAllNum[Type_index] then
			MeRankUI:getChildByName("Image_percentme"):show() -- “%”
			MeRankUI:getChildByName("Image_pre"):show() -- 前
			local rank_tan = (rank/self.RankAllNum[Type_index])*100
			if rank_tan>=100 then
				rankTxt:setString(99)
			else
				for i=1,10 do
					if rank_tan/(i*10)<=1 then
						if i*10>=100 then
							rankTxt:setString(99)
						else
							rankTxt:setString(i*10)
						end
						break
					end
				end
			end
		elseif rank<4 then
			rankTxt:hide()
			rankBg:show() -- 排名底图
			rankBg:loadTexture(Bg1_Path[rank])
		elseif rank>3 then
			rankBg:loadTexture("UI/rankUI/bg/PH_diban05.png")
			rankBg:show() -- 排名底图
		end
		--
		local score = Data.score
		local baifen_hao = MeRankUI:getChildByName("Image_percent1")
		local scoreTxt1 = MeRankUI:getChildByName("AtlasLabel_collection1")
		local scoreTxt2 = MeRankUI:getChildByName("AtlasLabel_collection2")
		local scoreTxt3 = MeRankUI:getChildByName("Text_rankName_M")
		scoreTxt1:hide()
		scoreTxt2:hide()
		scoreTxt3:hide()
		baifen_hao:hide()
	    -- 选择切页的index
	    -- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        	if index == 1 then
        		index = index+1
        	end
    	-- end
	    if index == 4 then  -- 宠物拥有数量
	        baifen_hao:show()
	        scoreTxt1:show()
	        local petAllPetData = PetData:getOwnData( 1 )
	        local petAllNums = table.maxn(petAllPetData)
	        local petCollectRate = math.floor((score/petAllNums)*100)
	        MeRankUI:getChildByName("Image_percent1")
	        scoreTxt1:setString(petCollectRate)
	    elseif index == 5 then -- 菜谱拥有数量
	        baifen_hao:show()
	        scoreTxt1:show()
	        local menuAllNums = MenuData:getMenuNums(1)
	        local menuCollectRate = math.floor((score/menuAllNums)*100)
	        scoreTxt1:setString(menuCollectRate)
	    elseif index == 1 then -- 段位排行榜显示段位名称
	    	scoreTxt3:show()
        	score = Data.dan
	    	local st_data = ConfigData.st_league_rank[score]
        	scoreTxt3:setString(st_data.grade_name)
	    else
	        scoreTxt2:show()
	        scoreTxt2:setString(score)
	    end

	    -- -- 玩家等级这里的底 是一个奖牌  奖牌的资源对应餐厅评级的段位
	    self:setPlayerLvImg( Data )
	    
	else
		MeRankUI:hide()
	end
end

--奖牌的资源对应餐厅评级的段位
function CTRankLayer:setPlayerLvImg( rankData )
	local MeRankUI = self.RankUI.FileNode_me
    rankData = rankData or {}
    MeRankUI:getChildByName("Image_playerlvl"):loadTexture(IconPath.PlayerCTRankLevel( rankData.dan ))    
end

function CTRankLayer:CloseLayer()
	self:removeSelf()
	-- FZutil.windowEffCloseToRemove(self.RankUI.root,self)
end
function CTRankLayer:CheckGuide()
	return self.cellData[2] -- 第二章Cell
end

function CTRankLayer:GetRankList(msg)
	if self then
		local type_id = nil
		local isUpdate = false
		for _index,_RANK_ID in pairs(TypeIndex) do
			type_id = getTypeId(_RANK_ID,self.curr_dan)
			if msg.type == type_id then
				isUpdate = true
				type_id = _RANK_ID
				break
			end
		end
		if isUpdate then
			-- local type_id = msg.type
	    	local rank_data = msg.rank_data
	    	local count = msg.count -- 这个排行榜的总人数
	    	self:setRankData(rank_data,type_id,self.curr_dan)
	    	-- self.RankData[type_id] = rank_data
	    	self.RankAllNum[msg.type] = count
	    	self:UpdataCheckView()
		end
	end
end

function CTRankLayer:GetSelfRank(msg)
	if self then
		local isUpdate = false
		local rank_id = nil
		for _index,_RANK_ID in pairs(TypeIndex) do
			local type_id = _RANK_ID
			if self.curr_dan then
				type_id = getTypeId(_RANK_ID,self.curr_dan)
			end
			if msg.rank_type == type_id then
				rank_id = _RANK_ID
				isUpdate = true
				break
			end
		end
		if isUpdate then
			local type_id = msg.rank_type
	    	local rank = msg.rank		 -- 排名
			local score = msg.score		 -- 流水
			local count = msg.count		 -- 这个排行榜的总人数
			local dan = msg.dan 		 -- 段位
			local Data = {rank = msg.rank, score = msg.score, count = msg.count, dan = msg.dan}
			
			self:UpdataSelfView(Data)
			-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
				if self.dan and self.dan == msg.dan then
					if not self.RankSelfData then
						self.RankSelfData = {}
					end
					self.RankSelfData[msg.rank_type] = Data
				end
				-- self.requireRankType = msg.rank_type

				self:japanUpdataCheckView(msg.dan,true,true)
			-- end
		end

		local rankType = self.dan and 1100+self.dan or nil
		if rankType and msg.rank_type == rankType then
			-- dan_rank dan_count
			local Datas = {rank = msg.rank, score = msg.score, count = msg.count, dan = msg.dan}
			self:initRankRuleNode(Datas)
		end
	end
end

function CTRankLayer:initRankRuleNode(Datas)
	self.selfRankLevel = nil
	local selfRankLevel = CTSelfRankLevel:initNode(self.RankUI.FileNode_rankrule, Datas)
	self.selfRankLevel = selfRankLevel
end

function CTRankLayer:RankUpdataTip(Datas)
	-- Alert:show("","rank"..Datas.rank.." score:"..Datas.score.." count:"..Datas.count.." dan:"..Datas.dan)
	local onDuan = Datas.dan or 0 	-- 当前段位 越大越好
	local onRank = Datas.rank or 0 	-- 当前排名 越小越好
	local myDuan = cc.UserDefault:getInstance():getIntegerForKey("myDuan") --以前的段位
	local myRank = cc.UserDefault:getInstance():getIntegerForKey("myRank") --以前的段位

	if myRank and myDuan then
		local titlemsg = nil
		if onDuan>myDuan or (onDuan==myDuan and onRank<myRank) then -- 提升
			titlemsg = Language.rank.on_rank_up
			-- MoveMessage.show(Language.rank.on_rank_up)
		elseif onDuan<myDuan or (onDuan==myDuan and onRank>myRank) then -- 降低
			-- MoveMessage.show(Language.rank.on_rank_down)
			titlemsg = Language.rank.on_rank_down
		end
		if titlemsg then
			Alert:show("",titlemsg,Alert.TYPE_OK)
		end
	else
		-- MoveMessage.show(Language.rank.on_rank_up)
	end

	-- 当前排名覆盖本地排名
	cc.UserDefault:getInstance():setIntegerForKey("myDuan",onDuan)
	cc.UserDefault:getInstance():setIntegerForKey("myRank",onRank)
end
--刷新赛季奖励
function CTRankLayer:UpdateSeasonMission(SMissionData)
	if self and self.RankUI and self.selfRankLevel then
		CTSelfRankLevel:UpdateSeasonMission(self.selfRankLevel,SMissionData)
	end
end

function CTRankLayer:GetSelfDan(dan)
	if self then
		if dan then
			self.dan = dan
			local Datas = {dan = dan}
			self:RankUpdataTip(Datas) -- 打开排行榜 提示段位提升 情况~
			if not self.curr_dan then
				local index = self.saveLeftIndex
				local Type_index = index and TypeIndex[index] or nil
				if Type_index and japanRankTypeId[Type_index] then
					self.curr_dan = dan
					self:UpdataCheckView()
				end
			end
		end
	end
end

function CTRankLayer:onEnter()
	-- 获取前50名排行
	FzEventCenter:RegisterEvent(FzEvent.GetRankList,self,self.GetRankList)
	FzEventCenter:RegisterEvent(FzEvent.GetSelfRank,self,self.GetSelfRank)
	FzEventCenter:RegisterEvent(FzEvent.UpdateSeasonMission,self,self.UpdateSeasonMission)
	FzEventCenter:RegisterEvent(FzEvent.GetSelfDan,self,self.GetSelfDan)
	if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		local petId = PetManagerData:getCashID()
    	if petId then
    	    FzSound.PlayJapanPetSound(petId, "rank")
    	end
	end
    -- NetEngine:registerCallback(game_cmd.SGetRankList,function(msg)
    		-- local type_id = msg.type
	    	-- local rank_data = msg.rank_data
	    	-- local count = msg.count -- 这个排行榜的总人数
	    	-- self.RankData[type_id] = rank_data
	    	-- self.RankAllNum[type_id] = count
	    	-- self:UpdataCheckView()
    -- end)
    -- 获取自身排行
  --   NetEngine:registerCallback(game_cmd.SGetSelfRank,function(msg)
		-- local type_id = msg.rank_type
  --   	local rank = msg.rank		 -- 排名
		-- local score = msg.score		 -- 流水
		-- local count = msg.count		 -- 这个排行榜的总人数
		-- local Data = {rank = msg.rank, score = msg.score, count = msg.count}
		-- self:UpdataSelfView(Data)
  --   end)
  	if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        SDKCenter:setUserInfo( "", "", 16)
    end
end

function CTRankLayer:onExit()
	scheduler.unscheduleGlobal(self.Sch_Cell)
	self.Sch_Cell = nil
	FzEventCenter:DispichEvent(FzEvent.resumeEventListener)
	self.CellAlls = nil
	self.RankData = nil
	self.RankAllNum = nil
	if self.selfRankLevel then
		self.selfRankLevel.root:removeSelf()
	end
	self.selfRankLevel = nil

	FzEventCenter:RemoveEvent(FzEvent.GetRankList,self)
	FzEventCenter:RemoveEvent(FzEvent.GetSelfRank,self)
	FzEventCenter:RemoveEvent(FzEvent.UpdateSeasonMission,self)
	FzEventCenter:RemoveEvent(FzEvent.GetSelfDan,self)
	-- NetEngine:unregisterCallback(game_cmd.SGetRankList)
	-- NetEngine:unregisterCallback(game_cmd.SGetSelfRank)

	if self.leftNameTemp then
		leftName = self.leftNameTemp
	end

	if self.TypeIndexTemp then
		TypeIndex = self.TypeIndexTemp
	end

	if self.rankImgNameTemp then
		rankImgName = self.rankImgNameTemp
	end

	MyApp:popTopCloseLayer("CTRankLayer")
end

function CTRankLayer:getRankData( type_id,curr_dan )
	local isRank = false
	type_id,isRank = getTypeId(type_id,curr_dan)

	if isRank and self.RankData[type_id] then
		return self.RankData[type_id][curr_dan]
	end

	return self.RankData[type_id]
end

function CTRankLayer:setRankData(rank_data,type_id,curr_dan)
	local isRank = false
	type_id,isRank = getTypeId(type_id,curr_dan)
	if not self.RankData[type_id] then
		self.RankData[type_id] = {}
	end

	if isRank then
		if not self.RankData[type_id][curr_dan] then
			self.RankData[type_id][curr_dan] = {}
		end
		self.RankData[type_id][curr_dan] = rank_data
		return
	end

	self.RankData[type_id] = rank_data
end

------------------------------Japan------------------------------------
local function getTopRank(rank)
	local filepath = string.format("UI/rankUI/word/PHword_rank%d.png",rank)
	if IconPath.checkFile(filepath) then
		return filepath
	end
	return ""
end

function CTRankLayer:initJapanRankUI()
	local RankUI = self.RankUI
	local league_rankcfg = ConfigData.st_league_rank
	local maxDan = table.maxn(league_rankcfg)
	self.cfg_max_rank_lv = maxDan

	RankUI.Image_ranklevelname:ignoreContentAdaptWithSize(true)
	RankUI.Image_commerce1:ignoreContentAdaptWithSize(true)
	RankUI.Image_popularity:ignoreContentAdaptWithSize(true)

	--左切换
	RankUI.Button_fanye1:onTouch(function(e)
		if e.name == "ended" then
			if self.curr_dan then
				if self.curr_dan > 1 then
					self.curr_dan = self.curr_dan - 1
					self:openPageTX(RankUI.ScrollView_3,function()
						self:japanUpdataCheckView(self.curr_dan,true)
					end)
				end
			end
		end
	end)

	--右切换
	RankUI.Button_fanye2:onTouch(function(e)
		if e.name == "ended" then
			if self.curr_dan then
				if self.curr_dan < maxDan then
					self.curr_dan = self.curr_dan+1
					self:openPageTX(RankUI.ScrollView_3,function()
						self:japanUpdataCheckView(self.curr_dan,true)
					end)					
				end
			end
		end
	end)
end

function CTRankLayer:japanTopDanUI( curr_dan )
	local RankUI = self.RankUI

	local Type_index = self.saveLeftIndex
	local type_id = TypeIndex[Type_index]

	local bottom = RankUI.Node_bottom
	local img_di = bottom:getChildByName("Image_di")
	img_di:getChildByName("Image_ranklevel"):hide()
	for _i,_img_name in pairs(rankImgName) do
		img_di:getChildByName(_img_name):setVisible(_i == Type_index)
	end

	local isShow = japanRankTypeId[type_id] and true or false
	
	RankUI.Node_bottom:getChildByName("Image_ranklevel"):setVisible(isShow)
	RankUI.Image_rankleveldi:setVisible(isShow)
	RankUI.Image_ranklevelname:setVisible(isShow)

	if isShow and curr_dan then
		RankUI.Node_bottom:getChildByName("Image_ranklevel"):loadTexture(IconPath.RankIcon( curr_dan ))
		RankUI.Image_ranklevelname:loadTexture(getTopRank(curr_dan))

		RankUI.Button_fanye1:setVisible(curr_dan~=1)
		RankUI.Button_fanye2:setVisible(curr_dan~=self.cfg_max_rank_lv)
		self.curr_dan = curr_dan
	else
		RankUI.Button_fanye1:setVisible(isShow)
		RankUI.Button_fanye2:setVisible(isShow)
	end
end

function CTRankLayer:japanUpdataCheckView( curr_dan,is_send_msg,is_self_update )
	if is_send_msg then
		local Type_index = self.saveLeftIndex
		local type_id = TypeIndex[Type_index]
		if japanRankTypeId[type_id] then
			self:UpdataCheckView()
		end
	end
	
end

function CTRankLayer:openPageTX(pageNode,func)
	-- if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
	--     local delayAction = cc.DelayTime:create(1.0)
	--     local scaleToAction = cc.ScaleTo:create(0.3,0,pageNode:getScaleY())
	--     local callFuncAction = cc.CallFunc:create(function()
	--     	if func then
	--     		func()
	--     	end
	--     end)
	--     local scaleToAction1 = cc.ScaleTo:create(0.3,pageNode:getScaleX(),pageNode:getScaleY())
	-- 	local sequence = cc.Sequence:create(delayAction,scaleToAction,callFuncAction,scaleToAction1)
	-- 	pageNode:runAction(sequence)	
	-- else
		if func then
			func()
		end
	-- end
end 

------------------------------------------------------------------------


---------------------------指定章節活動排行------------------------------
function CTRankLayer:initRewardUI()
	local RankUI = self.RankUI

	local checkBoxs = {RankUI.CheckBox_rank,RankUI.CheckBox_reward}
	local group = FzCheckBoxGroup.new(checkBoxs)
	local fonts = {}
	for _i,_check_box in ipairs(checkBoxs) do
		table.insert(fonts,{
			_check_box:getChildByName("Image_word1"),
			_check_box:getChildByName("Image_word2")
		})
	end

	group:initFonts(fonts)
	group:addTo(RankUI.root)
	group:addSubChangeCallback(function(index)
		self:setRewardSelect(index)
	end)
	self.group = group

	self:initRewardRankUI()
end

function CTRankLayer:initRewardRankUI()
	local RankUI = self.RankUI
	CTAssignChapterRankRewardLayer:initRankUI(RankUI.Image_EPTreward)
end

function CTRankLayer:setRewardSelect(index,leftGroupIndex)
	local RankUI = self.RankUI
	if not leftGroupIndex or (leftName[leftGroupIndex] == "ept") then
		RankUI.Node_ept:setVisible(true)
		local isShowReward = index == 2 and true or false
		RankUI.Image_di:setVisible(isShowReward==false)
		RankUI.FileNode_me:setVisible(isShowReward==false)
		RankUI.ScrollView_3:setVisible(isShowReward==false)
		RankUI.Image_EPTreward:setVisible(isShowReward)

		if not leftGroupIndex then
			self:japanTopDanUI()
		end
	else
		RankUI.Node_ept:setVisible(false)
	end
end
------------------------------------------------------------------------
function CTRankLayer:getGuideNeed(index)
	if index and index == 99 then
		if self.curr_dan then
			local league_rankcfg = ConfigData.st_league_rank
			local maxDan = table.maxn(league_rankcfg)
			if self.curr_dan < maxDan then
				self.curr_dan = self.curr_dan+1
				self:openPageTX(self.RankUI.ScrollView_3,function()
					self:japanUpdataCheckView(self.curr_dan,true)
				end)					
			end
		end
		return
	end
	self:checkBoxCallFunc(index)
	self:SetLeftGroupSelect(index)
end
return CTRankLayer