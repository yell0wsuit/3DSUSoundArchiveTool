
local PetQuickBuyLayer = require("app.Pet.PetQuickBuyLayer")

local audioPlayCountdown = 10			--连续升级会出现10秒内不能重复播放
local shopId = 2     --商店 猫狗玩具测试

local PetfavourLayer = class("PetfavourLayer",FZutil.createUILayer)

function PetfavourLayer:ctor(_petId)
	self:enableNodeEvents()

	self.audioTime = 0
	self.propCells = {}
	local favourUI = FZutil.createSceneNode("PetUI/Node_favor")
	favourUI.root:setPosition(display.center)
	self:addChild(favourUI.root)
	self.favourUI = favourUI

	favourUI.Text_favor_num1_M:getVirtualRenderer():setAdditionalKerning(-2)
	favourUI.Text_favor_num2_M:getVirtualRenderer():setAdditionalKerning(-2)

	favourUI.Image_bg1:setTouchEnabled(true)
	favourUI.Image_bg1:setSwallowTouches(true)
	self:onTouch(function(e)
		if e.name == "ended" then
			if self.clickUpdateBtn ~= true then
				FZutil.windowEffCloseToRemove(favourUI.root,self)
			end
		end
	end)

	self.isUpdateDetialLayer = false
	self.petId = _petId
	self:initfavourUI()

	FZutil.windowShowEff(favourUI.root)
	-- 引导
	CTGuideManage:initGuideOnPetfavourLayer(favourUI,self)
end

function PetfavourLayer:initfavourUI()
	local favourUI = self.favourUI
	local petData = PetData:getOwnPetData(self.petId)
	self.oldLevel = petData.level or 1
	self:updatefavourLevel(petData)
	self:updateLoading(petData)
	self:updateProp()
end

function PetfavourLayer:updatefavourLevel(pet_data)
	local petData = pet_data or PetData:getOwnPetData(self.petId)
	if not self.currLevel then
		self.currLevel = petData.level
	end
	local petcfg = ConfigData.st_pet[petData.pet_id]
	local currpetexpcfg = ConfigData.st_pet_exp[petData.level]
	local nextpetexpcfg = ConfigData.st_pet_exp[petData.level+1] or currpetexpcfg
	---------------------------------------当前等级-------------------------------
	local currLevelNode = self.favourUI.Image_lvl1
	currLevelNode:getChildByName("AtlasLabel_level"):setString(petData.level)
	local currGuid = PetData:getGuide(petData.pet_id,petData.level)
	local currAbility = PetData:getAbility(petData.pet_id,petData.level)
	currLevelNode:getChildByName("Text_pet_guidenum_M"):setString(currGuid)
	currLevelNode:getChildByName("Text_pet_attrinum_M"):setString(currAbility)

	local currCharmGuid = PetData:getCharm(currGuid)
	currLevelNode:getChildByName("Text_pet_charm_M"):setString(currCharmGuid)

	----------------------------------------下一等级-------------------------------
	local nextLevelNode = self.favourUI.Image_lvl2
	nextLevelNode:getChildByName("AtlasLabel_level"):setString(nextpetexpcfg.favour_level)
	local nextGuid = PetData:getGuide(petData.pet_id,nextpetexpcfg.favour_level)
	local nextAbility = PetData:getAbility(petData.pet_id,nextpetexpcfg.favour_level)
	nextLevelNode:getChildByName("Text_pet_guidenum_M"):setString(nextGuid)
	nextLevelNode:getChildByName("Text_pet_attrinum_M"):setString(nextAbility)

	local nextCharmGuid = PetData:getCharm(nextGuid)
	nextLevelNode:getChildByName("Text_pet_charm_M"):setString(nextCharmGuid)
end

function PetfavourLayer:updateLoading(pet_data)
	local petData = pet_data or PetData:getOwnPetData(self.petId)
	local currpetexpcfg = ConfigData.st_pet_exp[petData.level]
	local currLevel = petData.level
	local nextpetexpcfg = ConfigData.st_pet_exp[currLevel+1] or ConfigData.st_pet_exp[currLevel]
	if self.currLevel and currLevel>self.currLevel then
		self.currLevel = currLevel
		self.favourUI.LoadingBar_favor:setPercent(100)
	end
	-----------------------------------------LoadingBar------------------------------
	self.favourUI.AtlasLabel_favor:setString(currLevel)
	local currfavourNum = _currNums
	local nextfavourNum = nextpetexpcfg.favour_exp
	local exp = petData.exp
	if currLevel == self.currLevel and currLevel == #ConfigData.st_pet_exp then--and exp > nextfavourNum then
		exp = nextfavourNum
	end
	self.favourUI.Text_favor_num1_M:setString(exp)
	self.favourUI.Text_favor_num2_M:setString(nextfavourNum)
	self.favourUI.LoadingBar_favor:setPercent((exp/nextfavourNum)*100)

end

function PetfavourLayer:updateProp()
	---------------------------------------propNode------------------------------------
	for i=1,5 do
		local cellMap = self.propCells[i]
		if not cellMap then
			cellMap = FZutil.createMap(self.favourUI["FileNode_prop"..i])
			table.insert(self.propCells,cellMap)
		end
		self:updatePropCellData(cellMap,i)
	end
end

function PetfavourLayer:updatePropCellData(_cellMap,_index)
	local petData = PetData:getOwnPetData(self.petId)
	local maxLevel = #ConfigData.st_pet_exp
	local maxFavourExp = ConfigData.st_pet_exp[maxLevel].favour_exp
	local petcfg = ConfigData.st_pet[self.petId]
	---------------------------------------propNode------------------------------------
	local propData = PetData:getFavourProp(petcfg.species_type)
	local favourPropData = propData[_index]
	if not favourPropData then
		_cellMap.root:hide()
		return
	end
	_cellMap._index = _index -- 引导用到
	_cellMap.Image_icon:loadTexture(IconPath.getPropIcon(favourPropData.pic_id))
	_cellMap.Image_bg:loadTexture(IconPath.getPropQuality(favourPropData.quality))
	_cellMap.Image_icon:setTouchEnabled(true)
	local propNums = PropData:getPropNums(favourPropData.prop_id)
	local propNumbers = propNums
	local addFavour = favourPropData.add_favour
	_cellMap.Text_num:setString(propNums)
	_cellMap.Text_favor_num:setString("+"..addFavour)
	local currPropNums = propNums
	local currExp = petData.exp
	local currLevel = petData.level
	self.currLevel = currLevel
	local tempCurrLevel = currLevel
	local isCanBuy = false

	local shopcfg = nil
	for _goods_id,_shop_data in pairs(ConfigData.st_shop[shopId]) do
		if _shop_data.item_id == favourPropData.prop_id then
			shopcfg = _shop_data
			break
		end
	end
	local playerInfoData = RoleData.player_info

	local isWhile = false
	local showTimes = 0
	local longPressTimes = 0
	--添加属性
	FZutil.onTouchLongPressAdd(_cellMap.Image_icon,{
		longPressCallback = function()
			if favourPropData.is_use == 0 then
				if showTimes == 0 then
					showTimes = 1
					MoveMessage.show(Language.petui.prop_not_use)
				end
			elseif propNums == 0 then
				if showTimes == 0 then
					showTimes = 1
					MoveMessage.show(Language.petui.not_enought_prop)
				end
			elseif petData.level == maxLevel and petData.exp>=maxFavourExp then
				if showTimes == 0 then
					showTimes = 1
					MoveMessage.show(Language.petui.pet_favour_max)
				end
			else
				if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
    			else
    				longPressTimes = 0
				end
				if isWhile == false and longPressTimes == 0 then
					longPressTimes = longPressTimes+1
					isWhile = true
					petData.exp = petData.exp + addFavour
					local nextpetexpcfg = ConfigData.st_pet_exp[tempCurrLevel+1]
					if nextpetexpcfg then
						propNums = propNums-1
						if petData.exp >= nextpetexpcfg.favour_exp then
							if petData.level == maxLevel and petData.exp >= maxFavourExp then
								petData.exp = maxFavourExp
							else
								while true do
									nextpetexpcfg = ConfigData.st_pet_exp[tempCurrLevel+1]
									if nextpetexpcfg and petData.exp >= nextpetexpcfg.favour_exp then
										petData.exp = petData.exp-nextpetexpcfg.favour_exp
										tempCurrLevel = tempCurrLevel+1
									else
									 	break
									end
								end
								tempCurrLevel = tempCurrLevel>=maxLevel and maxLevel or tempCurrLevel
								petData.level = tempCurrLevel
							end
						end
					else
						petData.level = maxLevel
						petData.exp = maxFavourExp
					end
					_cellMap.Text_num:setString(propNums)
					self:updatefavourLevel(petData)
					self:updateLoading(petData)
					isCanBuy = true
					isWhile = false
				end
			end
		end,
		callback = function()

			if favourPropData.is_use == 0 then
				MoveMessage.show(Language.petui.prop_not_use)
			elseif propNums == 0 then
				if playerInfoData.ct_level < shopcfg.res_level then
					MoveMessage.show(string.format(Language.ctlevel_less_than, shopcfg.res_level))
				elseif playerInfoData.level < shopcfg.player_level then
					MoveMessage.show(string.format(Language.playlevel_less_than, shopcfg.player_level))
				else
					self.propIndex = _index
					local petQuickBuyLayer = PetQuickBuyLayer.new(favourPropData.prop_id,shopcfg)
					self:addChild(petQuickBuyLayer)
				end
			elseif petData.exp>=maxFavourExp then
				MoveMessage.show(Language.petui.pet_favour_max)
			else
				self.isUpdateDetialLayer = true
				NetEngine:sendMessage(game_cmd.CUseProp,{prop_id=favourPropData.prop_id,param=petData.pet_id,num=1})
			end
		end,
		eventback = function(e,isLongPress)
			if e.name == "began" then
				self.clickUpdateBtn = true	
			elseif e.name == "ended" then
				longPressTimes = 0
				isWhile = true 					--isWhile设置为true不然会出现长按功能多执行一遍的情况
				showTimes = 0
				if isCanBuy then
					isCanBuy = false
					self.isUpdateDetialLayer = true
					if not (FZ_COUNTRY and FZ_COUNTRY == "Japan") then
						if petData.level > currLevel then
							audio.playSound(FzSound.sounds.pet_favour_level,false)
						end
					end
					
					local propNumbers = PropData:getPropNums(favourPropData.prop_id)
					NetEngine:sendMessage(game_cmd.CUseProp,{prop_id=favourPropData.prop_id,param=petData.pet_id,num=propNumbers-propNums})
					isWhile = false
				end
				self.clickUpdateBtn = false
			elseif e.name == "cancelled" then
				longPressTimes = 0
				isCanBuy = false
				showTimes = 0
				propNums = currPropNums
				petData.exp = currExp
				tempCurrLevel = currLevel
				petData.level = currLevel
				self.currLevel = currLevel
				_cellMap.Text_num:setString(propNums)
				self:updatefavourLevel(petData)
				self:updateLoading(petData)
				self.clickUpdateBtn = false
			end
		end
	})

	--prop购买
	_cellMap.Button_add:onTouch(function(e)
		if e.name == "ended" then
			if playerInfoData.ct_level < shopcfg.res_level then
				MoveMessage.show(string.format(Language.petui.not_reach_ct_level,shopcfg.res_level))
			elseif playerInfoData.level < shopcfg.player_level then
				MoveMessage.show(string.format(Language.petui.not_reach_level,shopcfg.player_level))
			else
				self.propIndex = _index
				local petQuickBuyLayer = PetQuickBuyLayer.new(favourPropData.prop_id,shopcfg)
				self:addChild(petQuickBuyLayer)
			end
		end
	end)
end

--设置音效
function PetfavourLayer:setAudioPlaySound(oldLv,newLv)
	if self.petId and self.audioTime <= 0 then
		print("newLv: oldLv : ",newLv,oldLv)
		if newLv > oldLv then
			FzSound.PlayJapanPetSound(self.petId, "favor", true)
			if newLv - oldLv >= 2 then 					--连续升级需要有10秒的时间不会重复播放
				self:setAudioPlayCountdown()
			end
		else
			FzSound.PlayJapanPetSound(self.petId, "favor", false)
		end
	end
end

--设置音效倒计时
function PetfavourLayer:setAudioPlayCountdown()
	self.audioTime = audioPlayCountdown
	local favourUIRoot = self.favourUI.root
	schedule(self.favourUI.root, function()
		self.audioTime = self.audioTime-1
		if self.audioTime <= 0 then
			self.audioTime = 0
			favourUIRoot:getActionManager():removeAllActionsFromTarget(favourUIRoot)
		end
	end, 1.0)
end
function PetfavourLayer:buySuccessUpdate()
	if self and self.propIndex then
		self:updatePropCellData(self.propCells[self.propIndex],self.propIndex)
		self.propIndex = nil
	end
end

function PetfavourLayer:petUpdateExp()
	if self then
		local petData = nil
		if self.petId then
			petData = PetData:getOwnPetData(self.petId)
		end
		--日版
		if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
			if petData then
				self:setAudioPlaySound(self.oldLevel,petData.level)
				if petData.level > self.oldLevel then
					local parent = self:getParent()
					if parent and parent.setPetStroy then
						parent:setPetStroy(self.petId,petData.level,self.oldLevel)
					end
				end
			end
		end

		self:initfavourUI()
		local parent = self:getParent()
		if parent then
			parent:initPetUI()
		end
	end
end

function PetfavourLayer:getGuideNeed(_type)
	if _type == 1 then
		return self.propCells[2]
	end
	if _type == 2 then -- 引导使用好感度道具
		local _cellMap = self.propCells[2]
		local _index = _cellMap._index
		local petData = PetData:getOwnPetData(self.petId)
		local petcfg = ConfigData.st_pet[self.petId]
		---------------------------------------propNode------------------------------------
		local propData = PetData:getFavourProp(petcfg.species_type)
		local favourPropData = propData[_index]
		if not favourPropData then
			return
		end
		local use_num = 11
		local propNums = PropData:getPropNums(favourPropData.prop_id)
		if propNums == 0 then
			MoveMessage.show(Language.petui.not_enought_prop)
			return
		elseif propNums<11 then
			use_num = propNums
		end
		NetEngine:sendMessage(game_cmd.CUseProp,{prop_id=favourPropData.prop_id,param=petData.pet_id,num=use_num})
	end
end

function PetfavourLayer:onEnter()
	FzEventCenter:RegisterEvent(FzEvent.petUpdateExp,self,self.petUpdateExp)
end

function PetfavourLayer:onExit()
	FzEventCenter:RemoveEvent(FzEvent.petUpdateExp,self)
end

return PetfavourLayer