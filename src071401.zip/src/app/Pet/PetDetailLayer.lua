
local PetSkillResetLayer = require("app.Pet.PetSkillResetLayer")
local PetfavourLayer = require("app.Pet.PetfavourLayer")
local PetAloneSkillLayer = require("app.Pet.PetAloneSkillLayer")
local UTF8String = require("app.public.UTF8String")
local SkillGetLayer = require("app.Pet.SkillGetLayer")
local PetSubSkinLayer = nil
local isOpen = true
if isOpen then
	PetSubSkinLayer = require("app.Pet.PetSubSkinLayer")
end


local cellOrigin={
	x = -355,
	y = -132
}

local cellSize = {
	width = 64,
	height = 64
}

local petTouchBox={
	ear1 = {width = 30+5,height = 35+5},
	ear2 = {width = 30+5,height = 35+5},
	face = {width = 35+5,height = 40+5},
	chest = {width = 35+5,height = 35+5},
	bottom = {width = 70+5,height = 70+5},
	tail = {width = 20+5,height = 20+5},
}

local spaceW = 10
local spaceH = 3

local maxCol = 5
local radius = 20
local delayTime = 2

local rightNodeWidth = 545
local moveTime = 0.5
local modleMoveSpace = 400

local function getCellPos(_idx)
	--列
	local col = _idx%maxCol==0 and maxCol or _idx%maxCol
	--行
	local row = math.ceil(_idx/maxCol)
	return cellOrigin.x + (cellSize.width+spaceW)*(col-1),cellOrigin.y+(-cellSize.height-spaceH)*(row-1)
end

local function setStringVertical(_str)
	local verStr = ""
	local strLen = UTF8String.len(_str)
	for _charIdx=1,strLen do
		local strChar = UTF8String.sub(_str, _charIdx, 1)
		if strChar == "ー" then
			strChar = "|"
		end
		verStr = verStr..strChar
		if _charIdx<strLen then
			verStr = verStr.."\n"
		end
	end
	return verStr
end

local function redPetSpineJsonFile(pet_id)
	local filePath = string.format("battle/lihui/SP_%d/SP_%d.json", pet_id,pet_id)
	if IconPath.checkFile(filePath) then
		return FzFileUtils.readFile(filePath)
	end

	MoveMessage.show("not font path file:" .. filePath)
	return nil
end


local PetDetailLayer = class("PetDetailLayer",FZutil.createUILayer)
--详情/皮肤
PetDetailLayer.DETAIL = 1
PetDetailLayer.SKIN = 2

function PetDetailLayer:ctor(_petId,_petOwnData,isGuide) -- isGuide 从宠物引导打开此界面，区分跳转到此界面
	self:enableNodeEvents()

	DyPetStory.readData()
	local detailUI = FZutil.createSceneNode("PetUI/petUI_detail")

	local skinLayer = {}
	if isOpen then
	 	skinLayer = PetSubSkinLayer.new(self)
		detailUI.Node_center:addChild(skinLayer,1)
		self.skinLayer = skinLayer
	end 
	
	detailUI.skinUI = skinLayer.skinUI and skinLayer.skinUI.Node_right or cc.Node:create()

	self:addChild(detailUI.root)
	self.detailUI = detailUI
	detailUI.Node_right:setLocalZOrder(1)

	detailUI.FileNode_skill1:removeSelf()
	local petAttributebg = detailUI.Image_petAttributebg
	petAttributebg:setLocalZOrder(10)
	petAttributebg:hide()
	local HelpView_Show = false
	detailUI.Button_petAttributeTip:onTouch(function(e)
		if e.name == "ended" or e.name == "cancelled" then
			HelpView_Show = not HelpView_Show
			petAttributebg:setVisible(HelpView_Show)
		end
	end)

	local rightNodePosx,rightNodePosy = detailUI.Node_right:getPosition()
	detailUI.Node_right:setPositionX(rightNodePosx+rightNodeWidth)
	local guanbiBtnPosx,guanbiBtnPosy = detailUI.Button_guanbi:getPosition()
	detailUI.Button_guanbi:setPositionX(guanbiBtnPosx+rightNodeWidth)
	detailUI.Node_bottom:setPositionY(-display.cy)
	local bottomNodePosx,bottomNodePosy = detailUI.Node_bottom:getPosition()
	self.bottomNodePosx = bottomNodePosx
	self.bottomNodePosy = bottomNodePosy

	detailUI.Text_favor_num1_M:getVirtualRenderer():setAdditionalKerning(-2)
	detailUI.Text_favor_num2_M:getVirtualRenderer():setAdditionalKerning(-2)

	detailUI.Image_sxbg:setTouchEnabled(true)
	detailUI.Image_sxbg:setSwallowTouches(false)

	detailUI.Text_pet_desc_M:getVirtualRenderer():setAdditionalKerning(-1)
	--关闭
	detailUI.Button_guanbi:setLocalZOrder(10)

	local closeSelf = function()
		FZutil.windowEffCloseToRemove(detailUI.root,self)
    end
    MyApp:pushTopCloseLayer("PetDetailLayer",closeSelf)

	detailUI.Button_guanbi:onTouch(function(e)
		if e.name == "ended" then
			FZutil.windowEffCloseToRemove(detailUI.root,self)
			--
		end
	end)
	-- 专属技能按钮
	detailUI.Node_left:setPosition(-display.cx,-display.cy)
	detailUI.Button_uniqueskill:onTouch(function(e)
		if e.name == "ended" then
			print("专属技能~")
			if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		        SDKCenter:setUserInfo( "", "", 33)
		    end
			local aloneLayer = PetAloneSkillLayer.new(self.petId)
			self:addChild(aloneLayer)
		end
	end)
	--右移
	detailUI.Button_youyi:onTouch(function(e)
		if e.name == "ended" then
			detailUI.Button_youyi:hide()
			self:rightMove(PetDetailLayer.DETAIL,rightNodePosx,rightNodePosy,function()
				detailUI.Button_zuoyi:show()
				local zuoyiPosx = detailUI.Button_zuoyi:getPositionX()
				detailUI.Button_zuoyi:setPositionX(zuoyiPosx-rightNodeWidth)
			end)
		end
	end)

	--左移
	detailUI.Button_zuoyi:onTouch(function(e)
		if e.name == "ended" then
			local zuoyiPosx = detailUI.Button_zuoyi:getPositionX()
			detailUI.Button_zuoyi:setPositionX(zuoyiPosx+rightNodeWidth)
			detailUI.Button_zuoyi:hide()
			self:leftMove(PetDetailLayer.DETAIL,rightNodePosx,rightNodePosy,function()
				detailUI.Button_youyi:show()
			end)
		end
	end)

	if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		detailUI.Image_pet_bg_0:hide()
	else
		detailUI.Image_pet_bgJP:hide()
	end


	self.petId = _petId
	self:updatePetDesc()
	self:initPetUI()
	self:initSkillUI()

	if _petOwnData == nil then
		_petOwnData = {}
		local petOwnData = PetData:getOwnData( 2 ) 		--	拥有的pet数据
		for _index,_pet_data in ipairs(petOwnData) do
			if _pet_data.level and _pet_data.level > 0 then
				table.insert(_petOwnData,{
					petId = _pet_data.pet_id,
					cellIndex = _index
				})
			end
		end
	end
	self.petOwnData = _petOwnData
	self.currPetIdIndex = self:getIndexPetOwnDataById(_petId)

	detailUI.Button_youyi:hide()
	detailUI.Button_zuoyi:hide()
	transition.moveTo(detailUI.Node_right,{x=rightNodePosx,y=rightNodePosy,time=moveTime,onComplete=function()
		detailUI.Button_youyi:show()
	end})
	transition.moveTo(detailUI.Button_guanbi,{x=guanbiBtnPosx,y=guanbiBtnPosy,time=moveTime})

	FzSound.ChangeMusic(FzSound.music.bgm_pet)
	FZutil.windowShowEff(detailUI.root)

	self:setTouchEvent()

	self:switchLayer(PetDetailLayer.DETAIL)

	if isGuide then
		CTGuideManage:initGuideOnPetDetailLayer(detailUI,self)
		CTGuideManage:petCheckGuide(2)
	end
end

function PetDetailLayer:getIndexPetOwnDataById(_petId)
	if self.petOwnData then
		for _idx,_pet_own_data in ipairs(self.petOwnData) do
			if _petId == _pet_own_data.petId then
				return _idx
			end
		end
	end
	return nil
end

function PetDetailLayer:setTouchEvent()
	local touchLayer=cc.Layer:create()
    touchLayer:setTouchEnabled(true)
    touchLayer:setContentSize(display.width,display.height)
	self.detailUI.Node_center:addChild(touchLayer)

	local beganPosx,beganPosy = 0,0
	touchLayer:registerScriptTouchHandler(function(eventType, x , y)
        if eventType == "began" then
        	beganPosx,beganPosy = x,y
        	local isTouch = self.currPetIdIndex and true or false
        	return isTouch
        elseif eventType == "ended" then
        	local nextIndex = self.currPetIdIndex
        	if x - beganPosx > 100 then
        		nextIndex = nextIndex-1
        	elseif beganPosx - x > 100 then
        		nextIndex = nextIndex+1
        	end

        	if nextIndex == self.currPetIdIndex then  		--没有触发切换宠物
        		return
        	end

        	if self.petOwnData[nextIndex] then
        		local moveDirection = 1
        		modleMoveSpace =  display.width/4-10
				if nextIndex > self.currPetIdIndex then
					modleMoveSpace = display.width/2
					moveDirection = -1
				end

				local oldPetId = self.petId
        		self.petId = self.petOwnData[nextIndex].petId
        		DyPetStory.saveDataCache(oldPetId)

        		self.currPetIdIndex = nextIndex
        		if not self.parentNode then
					self.parentNode = self:getParent()
				end
				if self.parentNode and self.parentNode.changePetIdAndCellMap then
					self.parentNode:changePetIdAndCellMap(self.currPetIdIndex)
				end

				local modlePosx = self.model:getPositionX()
        		transition.moveTo(self.model,{x=modlePosx+moveDirection*modleMoveSpace,time=0.1,onComplete=function()
        			self.model:hide()
        			self:updatePetDesc()
					self:initPetUI(moveDirection)
					self:initSkillUI()
        		end})
			else
				if nextIndex > self.currPetIdIndex then
					MoveMessage.show(Language.petui.not_last)
				else
					MoveMessage.show(Language.petui.not_last)
				end
    	 	end
        end
    end, false, 0, false)
end

function PetDetailLayer:initPetUI(moveDirection)
	local detailUI = self.detailUI

	self.delayTouch = 0.0 						--延迟触摸时间
	self.isInitSuccess = false 					--是否初始化PetUI成功
	local _petData = PetData:getOwnPetData(self.petId)
	local petcfg = ConfigData.st_pet[self.petId]
	local level = _petData.level

	--品质背景图 _petData.quality
	-- detailUI.Image_qualitybg1:loadTexture(IconPath.getPetQualityImage(petcfg.quality))
	local bgp = ""
	if petcfg then
		if petcfg.sex == 1 then
			bgp = "UI/gonggong/background_boy.png"
		elseif petcfg.sex == 2 then
			bgp = "UI/gonggong/background_girl.png"
		end
	end
	detailUI.Image_qualitybg1:loadTexture(bgp)

	----------------------------------Node_top--------------------------------
	--品质图片
	detailUI.Image_pet_quality:loadTexture(IconPath.getPetTypeImage(petcfg.quality))
	
	if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		detailUI.Text_pet_nameJP_M:setString(petcfg.pet_name)
	else
		detailUI.Text_pet_name_M_0:setString(setStringVertical(petcfg.pet_name))
	end

	----------------------------------Node_right------------------------------
	detailUI.Node_petd_cn:hide()
	detailUI.Node_petd_jp:hide()

	if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		detailUI.Node_petd_jp:show()
		detailUI.Text_pet_varietyjp_M:setPositionX(-320)
		detailUI.Text_pet_varietyjp_M:setString(string.format("%s / %s / %s", petcfg.pet_species, petcfg.height, petcfg.weight))
	else
		detailUI.Node_petd_cn:show()
		detailUI.Text_pet_variety_M:setString(petcfg.pet_species)
		detailUI.Text_pet_height_M:setString(petcfg.height)
		detailUI.Text_pet_weight_M:setString(petcfg.weight)
	end
	
	detailUI.Text_desc:setString(petcfg.hobby)

	detailUI.AtlasLabel_level:setString(level)
	local currpetexpcfg = ConfigData.st_pet_exp[level]
	local nextpetexpcfg = ConfigData.st_pet_exp[level+1] or currpetexpcfg
	--属性进度条
	local exp = _petData.exp
	if level == nextpetexpcfg.favour_level then--exp > nextpetexpcfg.favour_exp then
		exp = nextpetexpcfg.favour_exp
	end

	detailUI.Text_favor_num1_M:setString(exp)
	detailUI.Text_favor_num2_M:setString(nextpetexpcfg.favour_exp)
	detailUI.LoadingBar_favor:setPercent((exp/nextpetexpcfg.favour_exp)*100)
	local initial = PetData:getGuide(self.petId,level)
	local ability = PetData:getAbility(self.petId,level)
	detailUI.Text_pet_guidenum_M:setString(initial)
	detailUI.Text_pet_attrinum_M:setString(ability)
	detailUI.Text_pet_professionnum_M:setString(Language.petui.career[petcfg.career])

	local charmInitial = PetData:getCharm(initial)
	detailUI.Text_pet_charmnum_M:setString(charmInitial)

	--add exp
	detailUI.Button_add:onTouch(function(e)
		if e.name == "ended" then
			if nextpetexpcfg.favour_exp > currpetexpcfg.favour_exp then
				local petfavourLayer = PetfavourLayer.new(self.petId,function()
					self:initPetUI()
				end)
				self:addChild(petfavourLayer)
			end
		end
	end)

	--更换皮肤
	if detailUI.Image_word_cskin then
		if isOpen == false then
			detailUI.Image_word_cskin:hide()
		end
		detailUI.Image_word_cskin:setTouchEnabled(true)
		detailUI.Image_word_cskin:onTouch(function(e)
			if e.name == "ended" then
				if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
		        	SDKCenter:setUserInfo( "", "", 32)
		    	end
				self:switchLayer(PetDetailLayer.SKIN)
			end
		end)
	end

	----------------------------------Node_bottom------------------------------
	self:updateModel(moveDirection)
	-- local bondData = self.model:findBone("bone")
	----------------------------------------------------------------------------

	self.isInitSuccess= true
	if self.skinLayer then
		self.skinLayer:updateUI(self.petId)
	end

	self:showBreak(self.petId)
end

function PetDetailLayer:showBreak(pet_id)
	if not pet_id then
		pet_id = self.petId
	end
	local detailUI = self.detailUI
	--突破
	local breakLevel = PetData:getPetBreak(pet_id)
	local breakNumStr = string.format("+%d/%d",breakLevel,Define.Max_Break_level)

	detailUI.Text_pet_break_M:setVisible(breakLevel ~= Define.Max_Break_level)
	detailUI.Text_pet_breakfull_M:setVisible(breakLevel == Define.Max_Break_level)

	if breakNumStr == Define.Max_Break_level then
		detailUI.Text_pet_breakfull_M:setString(breakNumStr)
	else
		detailUI.Text_pet_break_M:setString(breakNumStr)
	end
	
end

function PetDetailLayer:updateModel(moveDirection,skinPetId)
	moveDirection = moveDirection or 0
	skinPetId = skinPetId or PetData:getPetSkin(self.petId)
	local petcfg = ConfigData.st_pet[self.petId]
	local _petData = PetData:getOwnPetData(self.petId)
	local level = _petData.level
	local detailUI = self.detailUI
	--宠物立绘
	if not self.model then
		local touchLayer = cc.Layer:create()
    	touchLayer:setPosition(display.cx,display.cy)
    	touchLayer:setContentSize(display.width,display.height)
    	self:addChild(touchLayer)

		local listener = cc.EventListenerTouchOneByOne:create()

		listener:registerScriptHandler(function(touch,event)
			if self.isInitSuccess and self.delayTouch ==0 and self.model then
				return FZutil.checkBtnHit(touch,self.model)
			end
			return false
		end,cc.Handler.EVENT_TOUCH_BEGAN)

    	listener:registerScriptHandler(function(touch,event)
    		if self.isInitSuccess and self.model then
    			local pos= self.model:convertTouchToNodeSpace(touch)
    			local boneLocation = self:getTouchBoneLocation(self.spineBone,pos)
    			if boneLocation ~= false then
    				local petFaceData = PetData:getPetFaceData(self.petId,boneLocation,level)
    				if petFaceData==nil then
    					print("好感度等级不足于触发表情")
    					return
    				end
    				self:updatePetDesc(petFaceData.word)
    				
					if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
						FzSound.PlayJapanPetSound(self.petId, "touch", petFaceData.music)
					else
						local audioFile = string.format(FzSound.sounds.pet_music,petFaceData.music)
    					if IconPath.checkFile(audioFile) then
    						audio.playSound(audioFile,false)
    					end
					end
    				self:playSpineAnimation(self.model,petFaceData.express)
    			end
    		end
    	end,cc.Handler.EVENT_TOUCH_ENDED)

  		local eventDispatcher = touchLayer:getEventDispatcher()
  		eventDispatcher:addEventListenerWithSceneGraphPriority(listener, touchLayer)
  		self.listener = listener
  	else
  		self.model:removeSelf()
  		self.model = nil
	end

	detailUI.Image_pet:hide()
	local modelPosx,modelPosy = detailUI.Image_pet:getPosition()
	local modelZOreder = detailUI.Image_pet:getLocalZOrder()
	local modelParent = detailUI.Image_pet:getParent()

	local model = IconPath.PetIconBig( skinPetId )
	-- model:retain()
	-- FZutil.setUIMargin(model,nil,0,nil,nil)
	if moveDirection then
		model:setPosition(modelPosx+moveDirection*modleMoveSpace,modelPosy)
		transition.moveTo(model,{x=modelPosx,time=0.1})
	else
		model:setPosition(modelPosx,modelPosy)
	end
	model:setLocalZOrder(modelZOreder)
	modelParent:addChild(model)
	self.model = model
	detailUI.Image_pet_desckuang:setLocalZOrder(modelZOreder+1)
	detailUI.Text_pet_desc_M:setLocalZOrder(modelZOreder+1)

	local spineBone = {}
	local spineJsonFile = redPetSpineJsonFile(petcfg.pet_id)
	if spineJsonFile then
		local spineJson = json.decode(spineJsonFile)
		for _idx,_bone_data in pairs(spineJson.bones) do
			if PetData.petTouchPosition[_bone_data.name] then
				spineBone[PetData.petTouchPosition[_bone_data.name]] = {
					name = _bone_data.name,
					x = _bone_data.x,
					y = _bone_data.y,
					width = petTouchBox[_bone_data.name].width,
					height = petTouchBox[_bone_data.name].height
				}
			end
		end
	end
	self.spineBone = spineBone

	-- model:setDebugBonesEnabled(true)

	IconPath.changeAction(self.model)

	self:initPetStroy(self.petId)
end

function PetDetailLayer:updatePetDesc(desc)
	local isShow = true
	if desc == nil then
		isShow = false
	else
		self.detailUI.Text_pet_desc_M:setString(desc)
	end
	self.detailUI.Image_pet_desckuang:setVisible(isShow)
	self.detailUI.Text_pet_desc_M:setVisible(isShow)
end

function PetDetailLayer:playSpineAnimation(spModel,boneLocation)
	local animation = PetData.petTouchAnimation[boneLocation]
	IconPath.changeAction( spModel,animation,true )
	self.delayTouch = delayTime
	self:updateDelayTime(spModel)
end

function PetDetailLayer:updateDelayTime(spModel)
	performWithDelay(spModel, function()
		self.delayTouch = self.delayTouch-1
		if self.delayTouch>0 then
			return self:updateDelayTime(spModel)
		end
	end, 1.0)
end

function PetDetailLayer:getTouchBoneLocation(_bones,_touchPos)
	for _index,_bone_data in pairs(_bones) do
		if _touchPos.x<_bone_data.x-_bone_data.width or _touchPos.x>_bone_data.x+_bone_data.width or _touchPos.y<_bone_data.y-_bone_data.height or _touchPos.y > _bone_data.y+_bone_data.height then
        else
        	if _index==1 then
				return _index
			end
			return _index-1
    	end
	end
	return 6
end

function PetDetailLayer:initSkillUI()
	local skillData = PetData:getSkillData(self.petId)
	local detailUI = self.detailUI
	if not self.skillCells then
		self.skillCells = {}
	end

	local skillcfg = ConfigData.st_skill
	local cellIndex = 1
	local rightNode = detailUI.Node_right
	
	for _idx=1,10 do
		local isUnknownSkill = skillData[_idx] and true or false
		local cell = self.skillCells[cellIndex]
		if cell then
			cell.root:show()
		else
			cell = FZutil.createCellNode("PetUI/Node_pet_skill")
			table.insert(self.skillCells,cell)
		end
		local posx,posy = getCellPos(cellIndex)
		cell.root:setPosition(posx,posy)
		self:updateSkillData(cell,skillData[_idx],cellIndex,isUnknownSkill)

		rightNode:addChild(cell.root)
		cellIndex = cellIndex+1
	end

	local skillCount = table.maxn(self.skillCells)
	for _cell_idx=cellIndex+1,skillCount do
		self.skillCells[_cell_idx]:hide()
	end
end

function PetDetailLayer:updateSkillData(_skillCell,_skillData,_skillNum,_isUnknown)
	if not _skillCell then
		_skillCell = self.skillCells[_skillNum]
	end
	local unknownLevelTxt = _skillCell.root:getChildByTag(960)
	unknownLevelTxt:setVisible(_isUnknown~=true)
	_skillCell.root:getChildByTag(961):setVisible(_isUnknown~=true)
	_skillCell.Image_skill:setVisible(_isUnknown)
	_skillCell.Image_kuang:setVisible(_isUnknown)
	_skillCell.Image_skill_lock:setVisible(_isUnknown~=true)
	local imageTarget = nil
	if _isUnknown ~= true then
		--解锁等级
		local unKnownLevel = PetData:getFavourLevelForNum(_skillNum)
		unknownLevelTxt:setString(unKnownLevel)

		imageTarget = _skillCell.Image_skill_lock
	else
		imageTarget = _skillCell.Image_skill
		--技能图标
		local skillcfg = ConfigData.st_skill[_skillData.skill_id]
		_skillCell.Image_skill:loadTexture(IconPath.skillIcon(skillcfg.skill_id))
		_skillCell.Image_kuang:loadTexture(IconPath.skillCircle(skillcfg.career_limit))
	end

	imageTarget:setTouchEnabled(true)
	imageTarget:setSwallowTouches(true)
	local isTitle = true
	FZutil.onTouchLongPressAdd(imageTarget,{
		longPressCallback = function()
			if _skillData and _skillData.skill_id then
				if isTitle then
					isTitle = false
					local skillcfg = ConfigData.st_skill[_skillData.skill_id]
					MoveMessage.show(skillcfg.skill_desc)
				end
			else
				if isTitle then
					isTitle = false
					MoveMessage.show(Language.petui.not_find_skill)
				end
			end
		end,
		callback = function()
			if _isUnknown ~= true then
				if isTitle then
					isTitle = false
					MoveMessage.show(Language.petui.not_open_skill)
				end
			else
				local petSkillResetLayer = PetSkillResetLayer.new(self.petId,function()
					self:initSkillUI()
				end,_skillData.skill_id)
				self:addChild(petSkillResetLayer)
			end
		end,
		eventback = function(e,isLongPress)
			if e.name == "ended" or e.name == "cancelled" then
				isTitle = true
			end
		end,
	},nil,nil,nil,nil,true)
end

function PetDetailLayer:switchLayer(switchType)
	self.detailUI.Node_right:setVisible(switchType == PetDetailLayer.DETAIL)
	self.detailUI.skinUI:setVisible(switchType == PetDetailLayer.SKIN)
end

--右移
function PetDetailLayer:rightMove(switchType,rightNodePosx,rightNodePosy,moveCallFunc)
	local moveLayer = switchType==PetDetailLayer.DETAIL and self.detailUI.Node_right or self.detailUI.skinUI
	transition.moveTo(moveLayer,{x=rightNodePosx+rightNodeWidth,y=rightNodePosy,time=moveTime,onComplete=function()
		if moveCallFunc then
			moveCallFunc()
		end
	end})
	transition.moveTo(self.detailUI.Node_bottom,{x=0,y=self.bottomNodePosy,time=moveTime})
end

--左移
function PetDetailLayer:leftMove(switchType,leftNodePosx,leftNodePosy,moveCallFunc)
	local moveLayer = switchType==PetDetailLayer.DETAIL and self.detailUI.Node_right or self.detailUI.skinUI
	transition.moveTo(moveLayer,{x=leftNodePosx,y=leftNodePosy,time=moveTime,onComplete=function()
		if moveCallFunc then
			moveCallFunc()
		end
	end})
	transition.moveTo(self.detailUI.Node_bottom,{x=self.bottomNodePosx,y=self.bottomNodePosy,time=moveTime})
end

function PetDetailLayer:updatePetLevelUpSkill(petSkillData)
	if self then
		self:initSkillUI()
	end
	if petSkillData.skills then
		local skillGetLayer = SkillGetLayer.new(petSkillData.skills,petSkillData.pet_id)
		display.getRunningScene():addChild(skillGetLayer)
	end
end

function PetDetailLayer:onEnter()
	FzEventCenter:RegisterEvent(FzEvent.updatePetLevelUpSkill,self,self.updatePetLevelUpSkill)
	if SDKCenter and FZ_COUNTRY and FZ_COUNTRY == "Japan" then
        SDKCenter:setUserInfo( "", "", 31)
    end
end

function PetDetailLayer:onExit()
	FzEventCenter:RemoveEvent(FzEvent.updatePetLevelUpSkill,self)
	-- FzSound.ChangeMusic(FzSound.music.main_name)
	FzSound.PlayBgmForMain()
	if self.listener then
		self:getEventDispatcher():removeEventListener(self.listener)
		self.listener = nil
	end
    
	StoryNode:clearStory()
    DyPetStory.saveDataCache(self.petId)

	MyApp:popTopCloseLayer("PetDetailLayer")
end

-----------------------------------------Japan--------------------------------------
function PetDetailLayer:initPetStroy(petId)
	self:joinStory(petId)
end

--好感度升级时剧情
function PetDetailLayer:setPetStroy(petId,favourLv,oldFavourLv)
	if petId and favourLv and oldFavourLv then
		DyPetStory.saveDataCache(petId,oldFavourLv,favourLv)
		local petStorys = DyPetStory:getPetStory(petId,favourLv,oldFavourLv)
		DyPetStory.petStorys[petId] = petStorys
		self:joinStory(petId)
	end
end

function PetDetailLayer:joinStory(petId,is_delay)
	if self and self.detailUI and petId then
		local petStorys = DyPetStory.petStorys[petId] or {}
		if #petStorys > 0 then
			StoryNode:clearStory()
			local delay_time = is_delay and 2 or 0
			local petStory = petStorys[1]
			performWithDelay(self.detailUI.root, function()
				if self.petId == petId then
					StoryNode:showStory(petStory.story_id,function()
						table.remove(DyPetStory.petStorys[petId],1)
						is_delay = true
						if self.petId and self.petId ~= petId then
							petId = self.petId
							is_delay = nil
						end
						self:joinStory(petId,is_delay)
					end,10000)
				end
			end, delay_time)
		end
	end
end
-------------------------引导------------------------------------------------------------
function PetDetailLayer:getGuideNeed(_type)
	if _type and _type == 99 then -- 打开好感度道具界面 
		local _petData = PetData:getOwnPetData(self.petId)
		local level = _petData.level
		if level>=10 then
			return
		else
			local currpetexpcfg = ConfigData.st_pet_exp[level]
			local nextpetexpcfg = ConfigData.st_pet_exp[level+1] or currpetexpcfg
			if nextpetexpcfg.favour_exp > currpetexpcfg.favour_exp then
				local petfavourLayer = PetfavourLayer.new(self.petId,function()
					self:initPetUI()
				end)
				self:addChild(petfavourLayer)
				return true
			end
		end
		return -- 返回false时说明条件不够 则关闭引导
	end
	local need_name = "ear1"
	if _type and _type == 2 then
		need_name = "face"
	end
	local boneLocation = 6
	local data = nil
	for _index,v in pairs(self.spineBone) do
		local name = v.name
		print(v.name)
		if name == need_name then
			data = v
        	if _index==1 then
        		boneLocation = 1
        	else
        		boneLocation = _index-1
			end
        	break
		end
	end
	if _type and (_type == 1 or _type == 2) then
		return data
	end
	print("引导触摸耳朵了!",boneLocation)
	if boneLocation ~= false then
		local _petData = PetData:getOwnPetData(self.petId)
		local level = _petData.level
		local petFaceData = PetData:getPetFaceData(self.petId,boneLocation,level)
		if petFaceData==nil then
			print("好感度等级不足于触发表情")
			return
		end
		self:updatePetDesc(petFaceData.word)
		if FZ_COUNTRY and FZ_COUNTRY == "Japan" then
			FzSound.PlayJapanPetSound(self.petId, "touch", petFaceData.music)
		else
			local audioFile = string.format(FzSound.sounds.pet_music,petFaceData.music)
			if IconPath.checkFile(audioFile) then
				audio.playSound(audioFile,false)
			end
		end
		self:playSpineAnimation(self.model,petFaceData.express)
	end
end
-------------------------------------------------------------------------------------
return PetDetailLayer
